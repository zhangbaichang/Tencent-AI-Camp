/**
 * 像素沙盒 · 服务器版 V3.7（核心合并版 · 服务端权威世界 + 差量存档）
 *
 * 启动：
 *   cd server/
 *   npm install        （已随附 node_modules/ws，可跳过）
 *   node server.js
 * 访问：http://<本机IP>:8080   （静态页面与 WebSocket 同端口）
 *
 * V3.7 合并说明（本版核心改动）：
 *   把 V3.1~V3.6 的独立模块真正合并进主服务器，全部功能在此文件内生效：
 *     1. 权限系统   —— player / admin / developer 三级身份，按昵称持久化（data/roles.json）
 *     2. Kick       —— 踢出并限制 5 分钟内不得重进（data/kicklist.json，重启不丢）
 *     3. Ban        —— 封禁直到管理员解除（data/banlist.json，重启不丢）
 *     4. 创造模式   —— developer 默认创造；管理员可下发模式，实时同步客户端
 *     5. 聊天       —— WS /api/chat 双通道，带身份前缀，支持管理员公告，限速防刷
 *     6. PVP        —— 服务端总开关（data/config.json），关闭时攻击直接被拒
 *     7. 管理 API   —— /api/op/* 全部要求 opToken 鉴权（修复旧版任何人可踢人/重置的漏洞）
 *     8. 管理日志   —— 所有管理操作落盘 data/admin-log.json
 *     9. 玩家列表   —— player_list_update 广播（含身份前缀/模式），加入/离开/变更实时推送
 *
 * 保留的原有设计（未改动行为）：
 *   - 静态托管 index.html / css / js，一个 node 进程跑完整联机版
 *   - WebSocket 联机 + HTTP 轮询兜底（微信小程序）
 *   - 服务端权威世界差量：worldTiles Map 只记录玩家改动，叠加在种子地形之上
 *   - 200ms 增量同步 + 60s 全量兜底 + 定时落盘 world/ + 自动清理旧存档
 *
 * 运行环境：Node.js 16+（不依赖任何 Node 18+ 专属 API）。
 *
 * 注意：WORLD_W / WORLD_H 必须与 js/data.js 保持一致；服务端不引入前端模块，
 *       用常量同步以避免耦合（这是有 rationale 的显式约定，非 magic number）。
 */
const http = require('http');
const fs = require('fs');
const crypto = require('crypto');
const path = require('path');
const WebSocket = require('ws');
const { startSakuraFrpWatcher, getPublicAddressInfo } = require('./sakura-frp');

const PORT = process.env.PORT || 8080;
const DATA_DIR = path.join(__dirname, 'data');
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
function loadJson(file, fallback) { try { return JSON.parse(fs.readFileSync(file,'utf8')); } catch(e) { return fallback; } }
function saveJson(file,obj) { try { fs.writeFileSync(file, JSON.stringify(obj,null,2)); } catch(e) { console.error('[data]',e.message); } }
const WORLD_SEED_FILE = path.join(DATA_DIR,'world-seed.json');
const seedData = loadJson(WORLD_SEED_FILE,null);
const WORLD_SEED = seedData && Number.isFinite(seedData.seed) ? Math.floor(seedData.seed) : Math.floor(Math.random()*0x7fffffff);
if (!seedData) saveJson(WORLD_SEED_FILE,{seed:WORLD_SEED,createdAt:new Date().toISOString()});
// 与 js/data.js 的 WORLD_W / WORLD_H 同步（服务端权威世界差量的 key 计算依赖此值）
const WORLD_W = 600;
const WORLD_H = 300;
const IDLE_TIMEOUT = 60000;
const ROOT = path.join(__dirname, '..'); // 静态根 = 项目根（index.html/css/js 在 server/ 上一级）
const WORLD_DIR = path.join(__dirname, 'world'); // 世界存档目录（服务初始化时创建）
const SAVE_INTERVAL_MS = 5000;   // 世界数据落盘间隔（毫秒，可调；默认 5 秒一份）
const MAX_SAVE_FILES = 20;       // world/ 中最多保留的存档份数，超出自动删除最旧的
const OP_PASSWORD = process.env.OP_PASSWORD || 'admin123';
const OP_TOKENS = new Set();
const ACCOUNT_TOKENS = new Map(); // sessionToken -> accountId
const ACCOUNT_FILE = path.join(DATA_DIR, 'accounts.json');

// ==================== V3.7 数据持久化层（server/data/） ====================
// 所有管理类数据落盘在 server/data/，重启不丢。写文件采用同步写 +  try/catch：
// 数据量极小（几十条记录），同步写简单可靠，不会成为性能瓶颈。
const ROLES_FILE = path.join(DATA_DIR, 'roles.json');       // { 昵称: "admin"|"developer" }
const MODES_FILE = path.join(DATA_DIR, 'player-modes.json'); // { 昵称: "survival"|"creative" }
const BANLIST_FILE = path.join(DATA_DIR, 'banlist.json');   // [ { nickname, reason, by, at } ]
const KICKLIST_FILE = path.join(DATA_DIR, 'kicklist.json'); // { 昵称: 解封时间戳ms }
const ADMINLOG_FILE = path.join(DATA_DIR, 'admin-log.json');// [ { at, action, by, target, detail } ]
const CONFIG_FILE = path.join(DATA_DIR, 'config.json');     // 世界开关配置

function loadJson(file, fallback) {
  try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch (e) { return fallback; }
}
function saveJson(file, obj) {
  try { fs.writeFileSync(file, JSON.stringify(obj, null, 2)); } catch (e) {
    console.error('[data] 写入失败:', path.basename(file), e.message);
  }
}

// ==================== 游戏账户系统 ====================
// 游戏ID全局唯一；密码只保存 scrypt 哈希，不保存明文。
let accounts = loadJson(ACCOUNT_FILE, {});
if (!accounts || typeof accounts !== 'object' || Array.isArray(accounts)) accounts = {};
function normalizeAccountId(v) { return String(v || '').trim().toLowerCase(); }
function validAccountId(id) { return /^[a-z0-9_]+$/i.test(id) && id.length > 0; }
function passwordHash(password, salt) { return crypto.scryptSync(String(password), salt, 64).toString('hex'); }
function makePasswordRecord(password) { const salt = crypto.randomBytes(16).toString('hex'); return { salt, hash: passwordHash(password, salt) }; }
function checkPassword(account, password) { if (!account || !account.salt || !account.passwordHash) return false; return crypto.timingSafeEqual(Buffer.from(account.passwordHash,'hex'), Buffer.from(passwordHash(password, account.salt),'hex')); }
function newAccountSession(accountId) { const token = crypto.randomBytes(32).toString('hex'); ACCOUNT_TOKENS.set(token, accountId); return token; }
function accountFromToken(token) { const id = ACCOUNT_TOKENS.get(String(token || '')); return id ? accounts[id] : null; }
function accountIdFromToken(token) { const id = ACCOUNT_TOKENS.get(String(token || '')); return id || null; }
function accountPublic(a) { return { id:a.id, nickname:a.nickname, createdAt:a.createdAt, lastLogin:a.lastLogin || null }; }

// 身份表：昵称 -> role。普通玩家不记录（默认 player），只存提升过权限的。
let roles = loadJson(ROLES_FILE, {});
let playerModes = loadJson(MODES_FILE, {});
if (!playerModes || typeof playerModes !== 'object' || Array.isArray(playerModes)) playerModes = {};
// 封禁列表：数组，封禁直到管理员解除
let banlist = loadJson(BANLIST_FILE, []);
// 踢出限制：昵称 -> 解除时间戳（5 分钟临时限制）
let kicklist = loadJson(KICKLIST_FILE, {});
// 管理日志：最多保留 500 条，超出裁掉最旧
let adminLog = loadJson(ADMINLOG_FILE, []);
// 世界配置：PVP 总开关、创造模式管控、聊天开关、玩家列表显示
let config = Object.assign({
  pvp: false,
  creativeModeControl: true,
  chatEnabled: true,
  playerListDisplay: true,
  deathDrop: true,
  hungerEnabled: true,
  nuclearEnabled: true,
  mobilePerformance: true,
}, loadJson(CONFIG_FILE, {}));

const KICK_DURATION_MS = 5 * 60 * 1000; // Kick 限制时长：5 分钟
const CHAT_MAX_LEN = 120;               // 聊天单条最大长度
const CHAT_MIN_INTERVAL = 500;          // 聊天最小间隔（毫秒），防刷屏
const PVP_MAX_DAMAGE = 20;              // PVP 单次伤害上限（防伪造高伤害）
const PVP_MAX_RANGE = 400;
const MAX_HUNGER=20, HUNGER_TICK_MS=30000, STARVATION_DAMAGE=2;
const FOOD_VALUES={90:5,91:8,92:12,93:20};
const ARMOR_VALUES={94:5,95:12,96:20};
function xpNeed(l){return 100+Math.max(0,(Number(l)||1)-1)*50;}
function armorReduction(p){return Math.min(80,Math.max(0,Number(p.armor)||0));}
function applyDamage(p,raw){const d=Math.max(0,Number(raw)||0)*(1-armorReduction(p)/100);p.health=Math.max(0,p.health-d);return d;}
function gainXp(p,a){p.xp=Math.max(0,(p.xp||0)+Math.max(0,a||0));p.level=Math.max(1,p.level||1);while(p.xp>=xpNeed(p.level)){p.xp-=xpNeed(p.level);p.level++;p.health=Math.min(100,p.health+10);p.hunger=Math.min(MAX_HUNGER,(p.hunger||0)+2);}}
function savePlayerData(p){return{x:p.x,y:p.y,health:p.health,inventory:p.inventory||{},inventorySlots:Array.isArray(p.inventorySlots)?p.inventorySlots:[],hotbar:p.hotbar||[],hunger:p.hunger??20,xp:p.xp||0,level:p.level||1,armor:p.armor||0,equipment:p.equipment||{}};}
function syncStats(p,includeInventory=false){sendTo(p.id,{type:'player_stats',...(includeInventory?{inventory:p.inventory||{}}:{}),health:p.health,maxHealth:100,hunger:p.hunger??20,maxHunger:MAX_HUNGER,armor:armorReduction(p),xp:p.xp||0,level:p.level||1,xpNext:xpNeed(p.level||1),equipment:p.equipment||{}});}
function dropOnDeath(p){if(!config.deathDrop||p.mode==='creative'||Math.random()>0.4)return[];const ids=Object.keys(p.inventory||{}).filter(k=>(p.inventory[k]||0)>0).sort(()=>Math.random()-0.5).slice(0,2),out=[];for(const k of ids){p.inventory[k]--;if(p.inventory[k]<=0)delete p.inventory[k];out.push({id:Number(k),count:1});}return out;}
function handlePlayerDeath(p,cause){if(!p||p.deathHandled)return;p.deathHandled=true;const dropped=dropOnDeath(p);p.health=100;p.hunger=Math.max(8,p.hunger||20);p.invulnerableUntil=Date.now()+3000;savePlayers();syncStats(p);sendTo(p.id,{type:'player_respawn',health:p.health,hunger:p.hunger,armor:armorReduction(p),inventory:p.inventory||{},inventorySlots:p.inventorySlots||[],hotbar:p.hotbar||[],xp:p.xp||0,level:p.level||1,xpNext:xpNeed(p.level||1),deathX:p.x,deathY:p.y,dropped,cause});broadcast({type:'player_death',id:p.id,nickname:p.nickname,x:p.x,y:p.y,dropped,cause});setTimeout(()=>p.deathHandled=false,3000);}
function useFood(p,id){
  id=Number(id);
  if(!p || p.mode==='creative' || !config.hungerEnabled || !FOOD_VALUES[id] || (p.inventory?.[id]||0)<=0) return false;
  p.inventory[id]--;
  if(p.inventory[id]<=0) delete p.inventory[id];
  p.hunger=Math.min(MAX_HUNGER,(p.hunger||0)+FOOD_VALUES[id]);
  gainXp(p,2);
  savePlayers();
  sendTo(p.id,{type:'inventory_update',inventory:p.inventory||{},inventorySlots:p.inventorySlots||[],hotbar:p.hotbar||[]});
  syncStats(p);
  return true;
}
function unequipArmor(p){
 const id=p.equipment?.armorItem;if(!id)return false;
 p.inventory=p.inventory||{};p.inventory[id]=(p.inventory[id]||0)+1;p.equipment.armorItem=0;p.armor=0;
 savePlayers();syncStats(p,true);return true;
}
function equipArmor(p,id){id=Number(id);if(!ARMOR_VALUES[id]||(p.inventory?.[id]||0)<=0)return false;const old=p.equipment?.armorItem||0;if(old)p.inventory[old]=(p.inventory[old]||0)+1;p.inventory[id]--;if(p.inventory[id]<=0)delete p.inventory[id];p.equipment=p.equipment||{};p.equipment.armorItem=id;p.armor=ARMOR_VALUES[id];savePlayers();syncStats(p,true);return true;}
setInterval(()=>{if(!config.hungerEnabled)return;for(const p of players.values()){if(p.mode==='creative')continue;if(Date.now()-(p.lastHungerTick||0)<HUNGER_TICK_MS)continue;p.lastHungerTick=Date.now();p.hunger=Math.max(0,(p.hunger??20)-1);if(p.hunger===0){applyDamage(p,STARVATION_DAMAGE);if(p.health<=0)handlePlayerDeath(p,'starvation');}syncStats(p);}},5000);
              // PVP 最大命中距离（像素，约 12 格）

// ==================== V3.7 权限与身份系统 ====================
// 三级身份：player（默认）/ admin（管理员）/ developer（开发者）
// 身份按昵称绑定并持久化。注意：当前昵称即身份，无账号密码体系，
// 防伪造身份（昵称冒用）属于 V4.3 安全优化范围，本版先保证流程打通。
const PERMISSIONS = {
  player: ['chat'],
  admin: ['chat', 'kick', 'ban', 'world_control', 'announce'],
  developer: ['chat', 'kick', 'ban', 'world_control', 'announce', 'debug', 'creative'],
};

function getRole(nickname) {
  const r = roles[nickname];
  return (r === 'admin' || r === 'developer') ? r : 'player';
}

function getPrefix(role) {
  if (role === 'developer') return '[开发者]';
  if (role === 'admin') return '[管理员]';
  return '';
}

function hasPermission(role, action) {
  return (PERMISSIONS[role] || []).includes(action);
}

// 应用身份到玩家对象：developer 默认创造模式 + 飞行 + 无限物品（与 V3.4 role-manager 设计一致）
function applyRole(p, role) {
  p.role = role || 'player';
  p.prefix = getPrefix(p.role);
  const savedMode = playerModes[p.nickname] === 'creative' ? 'creative' : 'survival';
  if (p.role === 'developer') {
    p.mode = 'creative';
    p.canFly = true;
    p.infiniteItems = true;
  } else if (p.role === 'admin' && config.creativeModeControl) {
    p.mode = savedMode;
    p.canFly = p.mode === 'creative';
    p.infiniteItems = p.mode === 'creative';
  } else {
    p.mode = 'survival';
    p.canFly = false;
    p.infiniteItems = false;
  }
  return p;
}

// 设置身份（持久化 + 在线玩家实时生效 + 广播）
function setRole(nickname, role, by) {
  nickname = String(nickname || '').trim();
  if (!nickname) return false;
  if (role === 'player') delete roles[nickname];
  else roles[nickname] = role;
  if (role !== 'admin') delete playerModes[nickname];
  saveJson(ROLES_FILE, roles);
  saveJson(MODES_FILE, playerModes);
  // 在线玩家实时更新并广播
  for (const [id, p] of players) {
    if (p.nickname === nickname) {
      applyRole(p, getRole(nickname));
      sendTo(id, {
        type: 'role_update', id, nickname: p.nickname,
        role: p.role, prefix: p.prefix, mode: p.mode,
        canFly: !!p.canFly, infiniteItems: !!p.infiniteItems
      });
      broadcast({ type: 'role_update', id, nickname, role: p.role, prefix: p.prefix, mode: p.mode }, id);
    }
  }
  broadcastPlayerList();
  logAdmin('setrole', by || 'op', nickname, 'role=' + role);
  return true;
}

// ==================== V3.7 管理日志 ====================
function logAdmin(action, by, target, detail) {
  adminLog.push({ at: new Date().toISOString(), action, by: by || 'op', target: target || '', detail: detail || '' });
  if (adminLog.length > 500) adminLog = adminLog.slice(-500);
  saveJson(ADMINLOG_FILE, adminLog);
  console.log(`[admin] ${action} by=${by} target=${target} ${detail || ''}`);
}

// ==================== V3.7 Kick / Ban 检查 ====================
function isBanned(nickname) {
  return banlist.some(b => b.nickname === nickname);
}
function banPlayer(nickname, reason, by) {
  if (!isBanned(nickname)) {
    banlist.push({ nickname, reason: reason || '违反服务器规则', by: by || 'op', at: new Date().toISOString() });
    saveJson(BANLIST_FILE, banlist);
  }
  logAdmin('ban', by, nickname, reason || '');
}
function unbanPlayer(nickname, by) {
  const before = banlist.length;
  banlist = banlist.filter(b => b.nickname !== nickname);
  saveJson(BANLIST_FILE, banlist);
  if (banlist.length !== before) logAdmin('unban', by, nickname, '');
  return banlist.length !== before;
}
// 返回剩余毫秒数；0 表示不在限制中（顺手清理过期记录）
function kickedRemain(nickname) {
  const until = kicklist[nickname];
  if (!until) return 0;
  const remain = until - Date.now();
  if (remain <= 0) {
    delete kicklist[nickname];
    saveJson(KICKLIST_FILE, kicklist);
    return 0;
  }
  return remain;
}
function kickPlayer(nickname, by, reason) {
  kicklist[nickname] = Date.now() + KICK_DURATION_MS;
  saveJson(KICKLIST_FILE, kicklist);
  logAdmin('kick', by, nickname, reason || ('限制' + (KICK_DURATION_MS / 60000) + '分钟'));
}

// 按系统时间生成文件名片段：YYYY-MM-DD_HH-MM-SS-mmm（精确到毫秒，保证每次保存文件名唯一）
function fileTimestamp(d = new Date()) {
  const p = (n, w = 2) => String(n).padStart(w, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}` +
    `_${p(d.getHours())}-${p(d.getMinutes())}-${p(d.getSeconds())}-${p(d.getMilliseconds(), 3)}`;
}

// ==================== 服务端权威世界（差量覆盖） ====================
// key = ty * WORLD_W + tx  ->  tileId
// tileId 可以是 0（被挖空），用于覆盖种子地形上的原生方块
const worldTiles = new Map();
const {WorldInteractions}=require('./world-interactions');
const worldInteractions=new WorldInteractions({file:path.join(DATA_DIR,'chests.json'),tileAt:index=>worldTiles.get(index)});
function handleWorldAction(p,msg){
  try{
    const result=worldInteractions.handle(p?.accountId,p,msg);
    if(result.removed){worldTiles.set(msg.index,0);pendingSync.set(msg.index,0);broadcast({type:'block',tx:msg.index%WORLD_W,ty:Math.floor(msg.index/WORLD_W),tileId:0});}
    if(msg.action==='drop'||msg.action==='pickup'){
      savedPlayers[p.nickname]=savePlayerData(p);savePlayers();
      broadcast({type:'shared_drops',drops:[...worldInteractions.drops.values()]});
    }
    return{ok:true,...result};
  }catch(e){return{ok:false,error:e.message};}
}


setInterval(()=>{worldInteractions.clean();for(const event of worldInteractions.events.splice(0))broadcast({type:'shared_explosion',...event});},100);

// 服务端权威时钟：所有客户端昼夜统一以此时钟为准（200ms 广播校正）
let gameTime = 0.15; // 0~1 一天（与客户端 game.time 同构）
let gameDay = 0;     // 天数

// 200ms 增量同步队列：只广播"本窗口内"的方块改动（动态地图），避免全量广播的带宽爆炸
const pendingSync = new Map(); // key -> tileId

// 记录一次方块改动到权威世界（含边界与类型校验）
function recordBlock(tx, ty, tileId, actor) {
  if (!Number.isInteger(tx) || !Number.isInteger(ty) || !Number.isInteger(tileId)) return;
  if (tx < 0 || tx >= WORLD_W || ty < 0 || ty >= WORLD_H) return;
  const key = ty * WORLD_W + tx;
  if(tileId!==27 && worldInteractions.protected(key))return false;
  if(tileId===27 && actor?.accountId)worldInteractions.register(key,actor.accountId);
  worldTiles.set(key, tileId);
  pendingSync.set(key, tileId); // 同时记入增量队列，供 200ms 定时同步
}

function worldStatePayload() {
  return { tiles: Array.from(worldTiles.entries()) };
}

// ==================== 玩家与会话 ====================

const PLAYER_SAVE_FILE = path.join(__dirname, 'players.json');
const PLAYER_AUTO_SAVE = 10000;
let savedPlayers = {};
try { savedPlayers = JSON.parse(fs.readFileSync(PLAYER_SAVE_FILE,'utf8')); } catch(e) { savedPlayers = {}; }
function savePlayers(){ try { fs.writeFileSync(PLAYER_SAVE_FILE, JSON.stringify(savedPlayers,null,2)); } catch(e){} }
function saveAccounts(){ saveJson(ACCOUNT_FILE, accounts); }

const PLAYER_DATA_BACKUP = path.join(__dirname, 'players_backup.json');

setInterval(() => {
  try {
    savePlayers();
    if (!fs.existsSync(PLAYER_DATA_BACKUP)) {
      fs.writeFileSync(PLAYER_DATA_BACKUP, JSON.stringify(savedPlayers, null, 2));
    }
  } catch(e) {}
}, 10000);

const players = new Map(); // id -> player
let nextId = 1;

function broadcast(msg, exceptId) {
  const data = JSON.stringify(msg);
  for (const [id, p] of players) {
    if (id !== exceptId && p.ws && p.ws.readyState === WebSocket.OPEN) {
      p.ws.send(data);
    }
    // HTTP 模式玩家需要把消息存入队列
    if (id !== exceptId && !p.ws) {
      p.messages = p.messages || [];
      p.messages.push(msg);
    }
  }
}

function sendTo(id, msg) {
  const p = players.get(id);
  if (!p) return;
  if (p.ws && p.ws.readyState === WebSocket.OPEN) {
    p.ws.send(JSON.stringify(msg));
  } else {
    p.messages = p.messages || [];
    p.messages.push(msg);
  }
}

// 在线人数实时广播
function broadcastOnlineCount() {
  broadcast({ type: 'onlineCount', count: players.size });
}

// V3.7 在线玩家列表广播：含身份前缀与模式，加入/离开/身份变更时推送。
// 客户端负责"最多显示5个+滚动"（V3.8 HUD），服务端发全量保证信息完整。
function broadcastPlayerList() {
  if (!config.playerListDisplay) return;
  const list = [];
  for (const [id, p] of players) {
    list.push({
      id, nickname: p.nickname,
      role: p.role || 'player', prefix: p.prefix || '',
      mode: p.mode || 'survival', health: p.health,
    });
  }
  broadcast({ type: 'player_list_update', count: list.length, players: list });
}

function getPlayerList(excludeId) {
  const list = [];
  for (const [id, p] of players) {
    if (id !== excludeId) {
      list.push({
        id, nickname: p.nickname,
        x: p.x, y: p.y, vx: p.vx, vy: p.vy,
        facing: p.facing, walkPhase: p.walkPhase, health: p.health,
        inventory: p.inventory || {},
        hotbar: p.hotbar || [],
        role: p.role || 'player', prefix: p.prefix || '',
        mode: p.mode || 'survival',
      });
    }
  }
  return list;
}

// 把玩家从服务器移除（kick/ban/超时共用）：通知本人、存档、广播离开
function removePlayer(id, notifyMsg) {
  const p = players.get(id);
  if (!p) return;
  if (notifyMsg) sendTo(id, notifyMsg);
  if (p.ws) { try { p.ws.close(); } catch (e) {} }
  savedPlayers[p.nickname] = savePlayerData(p);
  savePlayers();
  players.delete(id);
  broadcast({ type: 'leave', id });
  broadcastOnlineCount();
  broadcastPlayerList();
}

// ==================== V3.7 聊天系统 ====================
// channel: 'normal' 普通聊天 | 'announce' 管理员公告 | 'server' 服务器消息
function handleChat(p, text, channel) {
  if (!p) return;
  if (!config.chatEnabled) { sendTo(p.id, { type: 'chat_denied', reason: '聊天已被管理员关闭' }); return; }
  if (!hasPermission(p.role, 'chat')) { sendTo(p.id, { type: 'chat_denied', reason: '没有聊天权限' }); return; }
  // 公告频道需要 announce 权限（admin / developer）
  if (channel === 'announce' && !hasPermission(p.role, 'announce')) {
    sendTo(p.id, { type: 'chat_denied', reason: '只有管理员可以发公告' }); return;
  }
  // 限速：防刷屏
  const now = Date.now();
  if (p.lastChatAt && now - p.lastChatAt < CHAT_MIN_INTERVAL) {
    sendTo(p.id, { type: 'chat_denied', reason: '发言太快，请稍候' }); return;
  }
  p.lastChatAt = now;
  const clean = String(text || '').replace(/[\x00-\x1f\x7f]/g, '').trim().slice(0, CHAT_MAX_LEN);
  if (!clean) return;
  broadcast({
    type: 'chat',
    id: p.id,
    nickname: p.nickname,
    role: p.role || 'player',
    prefix: p.prefix || '',
    text: clean,
    channel: channel === 'announce' ? 'announce' : 'normal',
    at: now,
  });
}

// 服务器系统消息（开发者可用，全服可见，无发送者）
function serverMessage(text) {
  broadcast({ type: 'chat', id: 0, nickname: '服务器', role: 'developer', prefix: '[服务器]', text: String(text).slice(0, CHAT_MAX_LEN), channel: 'server', at: Date.now() });
}

// ==================== V3.7 PVP 系统 ====================
// 服务端校验：总开关、伤害上限、距离上限（用双方上报位置做粗略判定，防全图秒杀）
function handlePvpHit(attacker, msg) {
  if (!attacker) return;
  if (!config.pvp) { sendTo(attacker.id, { type: 'pvp_denied', reason: 'PVP 未开启' }); return; }
  const target = players.get(Number(msg.target));
  if (!target) { sendTo(attacker.id, { type: 'pvp_denied', reason: '目标不在线' }); return; }
  if (target.id === attacker.id) return;
  const damage = Math.max(1, Math.min(PVP_MAX_DAMAGE, Number(msg.damage) || 1));
  // 距离校验：双方都有坐标时才检查，超出范围直接拒
  if (attacker.x && attacker.y && target.x && target.y) {
    const dist = Math.hypot(attacker.x - target.x, attacker.y - target.y);
    if (dist > PVP_MAX_RANGE) { sendTo(attacker.id, { type: 'pvp_denied', reason: '目标太远' }); return; }
  }
  const dealt=applyDamage(target,damage); target.lastDamageAt=Date.now(); syncStats(target);
  sendTo(target.id,{type:'pvp_hit',from:attacker.id,fromNickname:attacker.nickname,fromPrefix:attacker.prefix||'',damage:dealt,health:target.health,armor:armorReduction(target)});
  if(target.health<=0) handlePlayerDeath(target,'pvp');
}

// ==================== 静态文件 + API 服务器 ====================
const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.ico': 'image/x-icon',
};

const server = http.createServer((req, res) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') { res.writeHead(204); res.end(); return; }

  let urlPath;
  try { urlPath=decodeURIComponent(req.url.split('?')[0]); } catch { res.writeHead(400);res.end('Bad request');return; }
  const cookies = String(req.headers.cookie || '');
  const opToken = (cookies.match(/opToken=([^;]+)/)||[])[1];
  const opAuthed = !!(opToken && OP_TOKENS.has(opToken));

  if (urlPath === '/op' || urlPath === '/op/') {
    res.writeHead(200, {'Content-Type':'text/html; charset=utf-8'});
    fs.createReadStream(path.join(ROOT,'admin','index.html')).pipe(res);
    return;
  }

  if (req.method === 'POST') {
    let body = '';
    req.on('data', chunk => body += chunk);
    req.on('end', () => {
      let data = {};
      if (body.trim()) {
        try { data = JSON.parse(body); } catch { res.writeHead(400); res.end('Invalid JSON'); return; }
      }
      handleHttpApi(urlPath, data, res, opAuthed);
    });
    return;
  }

  if (urlPath === '/status' || urlPath === '/status/') {
    res.writeHead(200, {'Content-Type':'text/html; charset=utf-8', 'Cache-Control':'no-cache, no-store, must-revalidate'});
    fs.createReadStream(path.join(ROOT,'status.html')).pipe(res);
    return;
  }

  if (urlPath === '/api/public-address') {
    jsonRes(res, 200, getPublicAddressInfo());
    return;
  }

  // GET /api/* → 交给 HTTP API 处理（如 /api/players 用 GET 轮询在线玩家）
  if (urlPath.startsWith('/api/')) {
    handleHttpApi(urlPath, {}, res, opAuthed);
    return;
  }

  // GET → 静态文件托管
  let rel = urlPath === '/' ? '/index.html' : urlPath;
  const filePath = path.normalize(path.join(ROOT, rel));
  if (filePath !== ROOT && !filePath.startsWith(ROOT + path.sep)) {
    res.writeHead(403); res.end('Forbidden'); return;
  }
  const publicFile = /^(?:\/(?:index|404|status)\.html|\/(?:js|css|client|admin)\/[a-zA-Z0-9_.\/-]+\.(?:js|css|html|png|jpg|svg|ico|woff2?))$/.test(rel);
  if(!publicFile || rel.split(/[\\/]/).some(part=>part==='..')){res.writeHead(403);res.end('Forbidden');return;}
  fs.stat(filePath, (err, stat) => {
    if (err || !stat.isFile()) { res.writeHead(404); res.end('Not Found'); return; }
    const ext = path.extname(filePath).toLowerCase();
    // 缓存策略：HTML 不缓存（保证每次刷新拿到最新页面）；JS/CSS/图片短缓存（5 分钟）
    const isHtml = ext === '.html' || ext === '.htm';
    const headers = { 'Content-Type': MIME[ext] || 'application/octet-stream' };
    if (isHtml) {
      headers['Cache-Control'] = 'no-cache, no-store, must-revalidate';
    } else {
      headers['Cache-Control'] = 'public, max-age=300';
    }
    res.writeHead(200, headers);
    fs.createReadStream(filePath).pipe(res);
  });
});

function jsonRes(res, code, obj) {
  res.writeHead(code, {'Content-Type':'application/json'});
  res.end(JSON.stringify(obj));
}

// 需要管理员鉴权的接口统一入口：未登录直接 403（V3.7 修复：旧版这些接口无鉴权，任何人可调用）
function requireOp(res, opAuthed) {
  if (!opAuthed) { jsonRes(res, 403, { ok:false, error:'unauthorized' }); return false; }
  return true;
}

function handleHttpApi(url, data, res, opAuthed) {
  switch (url) {
    case '/api/world': {
      const accountId=accountIdFromToken(data.accountToken);
      const p=[...players.values()].find(p=>p.accountId===accountId);
      if(!accountId||!p){jsonRes(res,401,{ok:false,error:'请先登录游戏'});return;}
      if((data.action==='drop'||data.action==='pickup')&&data.inventory&&typeof data.inventory==='object'&&!Array.isArray(data.inventory)){p.inventory=Object.fromEntries(Object.entries(data.inventory).filter(([id,n])=>Number.isInteger(Number(id))&&Number(id)>0&&Number(id)<=255&&Number.isSafeInteger(n)&&n>0&&n<=1000000000));}
      jsonRes(res,200,handleWorldAction(p,data));return;
    }

    // ---------- 游戏账户：注册 / 登录 ----------
    case '/api/account/register': {
      const accountId = normalizeAccountId(data.accountId);
      const password = String(data.password || '');
      const nickname = String(data.nickname || accountId).trim().slice(0, 16) || accountId;
      if (!validAccountId(accountId)) { jsonRes(res, 400, {ok:false,error:'bad_account_id',message:'游戏ID只能使用字母、数字、下划线，长度不限'}); break; }
      if (password.length < 6 || password.length > 128) { jsonRes(res, 400, {ok:false,error:'bad_password',message:'密码长度需要6-128位'}); break; }
      if (accounts[accountId]) { jsonRes(res, 409, {ok:false,error:'account_exists',message:'游戏ID已存在'}); break; }
      // 昵称也避免重复，防止聊天/管理面板混淆身份
      if (Object.values(accounts).some(a => String(a.nickname).toLowerCase() === nickname.toLowerCase())) { jsonRes(res, 409, {ok:false,error:'nickname_exists',message:'昵称已被使用'}); break; }
      const pr = makePasswordRecord(password);
      accounts[accountId] = { id:accountId, nickname, salt:pr.salt, passwordHash:pr.hash, createdAt:new Date().toISOString(), lastLogin:null };
      saveAccounts();
      const token = newAccountSession(accountId);
      jsonRes(res, 200, {ok:true,token,account:accountPublic(accounts[accountId])});
      break;
    }
    case '/api/account/login': {
      const accountId = normalizeAccountId(data.accountId);
      const password = String(data.password || '');
      const a = accounts[accountId];
      if (!a || !checkPassword(a,password)) { jsonRes(res, 403, {ok:false,error:'invalid_login',message:'游戏ID或密码错误'}); break; }
      if ([...players.values()].some(p => p.accountId === accountId)) { jsonRes(res, 409, {ok:false,error:'already_online',message:'该账户已经在线'}); break; }
      a.lastLogin = new Date().toISOString(); saveAccounts();
      const token = newAccountSession(accountId);
      jsonRes(res, 200, {ok:true,token,account:accountPublic(a)});
      break;
    }
    case '/api/account/check': {
      const a = accountFromToken(data.token);
      jsonRes(res, 200, {ok:!!a,account:a?accountPublic(a):null});
      break;
    }
    case '/api/account/logout': {
      ACCOUNT_TOKENS.delete(String(data.token || ''));
      jsonRes(res, 200, {ok:true});
      break;
    }
    // ---------- 管理员登录（无需鉴权） ----------
    case '/api/op/login': {
      if (String(data.password || '') !== OP_PASSWORD) {
        jsonRes(res, 403, {ok:false});
        break;
      }
      const token = Math.random().toString(36).slice(2) + Date.now();
      OP_TOKENS.add(token);
      res.writeHead(200, {
        'Content-Type':'application/json',
        'Set-Cookie': `opToken=${token}; Path=/; HttpOnly; SameSite=Strict`
      });
      res.end(JSON.stringify({ok:true}));
      break;
    }
    case '/api/op/check': {
      const token = String(data.token || '');
      jsonRes(res, 200, {ok:OP_TOKENS.has(token)});
      break;
    }

    // ---------- V4.1 账户管理 ----------
    case '/api/op/accounts': {
      if (!requireOp(res, opAuthed)) break;
      jsonRes(res, 200, {ok:true, accounts:Object.values(accounts).map(a => Object.assign(accountPublic(a), {
        role:getRole(a.nickname), mode:(getRole(a.nickname)==='developer'?'creative':(playerModes[a.nickname]||'survival'))
      }))});
      break;
    }
    case '/api/op/account/create': {
      if (!requireOp(res, opAuthed)) break;
      const accountId=normalizeAccountId(data.accountId), password=String(data.password||''), nickname=String(data.nickname||accountId).trim().slice(0,16)||accountId;
      if (!validAccountId(accountId) || password.length<6 || password.length>128) { jsonRes(res,400,{ok:false,error:'bad_params'}); break; }
      if (accounts[accountId]) { jsonRes(res,409,{ok:false,error:'account_exists'}); break; }
      if (Object.values(accounts).some(a=>String(a.nickname).toLowerCase()===nickname.toLowerCase())) { jsonRes(res,409,{ok:false,error:'nickname_exists'}); break; }
      const pr=makePasswordRecord(password); accounts[accountId]={id:accountId,nickname,salt:pr.salt,passwordHash:pr.hash,createdAt:new Date().toISOString(),lastLogin:null}; saveAccounts(); logAdmin('account_create','op',accountId,'nickname='+nickname);
      jsonRes(res,200,{ok:true,account:accountPublic(accounts[accountId])}); break;
    }
    case '/api/op/account/delete': {
      if (!requireOp(res, opAuthed)) break;
      const accountId=normalizeAccountId(data.accountId); const a=accounts[accountId];
      if (!a) { jsonRes(res,404,{ok:false,error:'not_found'}); break; }
      const p=[...players.values()].find(x=>x.accountId===accountId); if(p) removePlayer(p.id,{type:'kick',reason:'账户已被管理员删除'});
      for (const [t,id] of ACCOUNT_TOKENS) if(id===accountId) ACCOUNT_TOKENS.delete(t);
      delete savedPlayers[a.nickname]; delete roles[a.nickname]; delete playerModes[a.nickname]; delete accounts[accountId]; savePlayers(); saveJson(ROLES_FILE,roles); saveJson(MODES_FILE,playerModes); saveAccounts();
      logAdmin('account_delete','op',accountId,''); jsonRes(res,200,{ok:true}); break;
    }
    case '/api/op/account/reset-password': {
      if (!requireOp(res, opAuthed)) break;
      const accountId=normalizeAccountId(data.accountId), password=String(data.password||''), a=accounts[accountId];
      if(!a || password.length<6 || password.length>128){jsonRes(res,400,{ok:false,error:'bad_params'});break;}
      const pr=makePasswordRecord(password); a.salt=pr.salt; a.passwordHash=pr.hash; saveAccounts(); for(const [t,id] of ACCOUNT_TOKENS)if(id===accountId)ACCOUNT_TOKENS.delete(t); logAdmin('account_password_reset','op',accountId,''); jsonRes(res,200,{ok:true}); break;
    }
    case '/api/op/give': {
      if (!requireOp(res, opAuthed)) break;
      const id=Number(data.id), accountId=normalizeAccountId(data.accountId); const p=id?players.get(id):[...players.values()].find(x=>x.accountId===accountId);
      const itemId=Number(data.itemId), count=Math.max(1,Math.min(9999,Number(data.count)||1)); if(!Number.isFinite(itemId)||itemId<0){jsonRes(res,400,{ok:false,error:'bad_item'});break;}
      if(p){ p.inventory=p.inventory||{}; p.inventory[itemId]=(p.inventory[itemId]||0)+count; savePlayers(); sendTo(p.id,{type:'inventory_update',inventory:p.inventory,inventorySlots:p.inventorySlots||[],hotbar:p.hotbar||[]}); syncStats(p); logAdmin('give_item','op',p.nickname,'item='+itemId+' count='+count); jsonRes(res,200,{ok:true,nickname:p.nickname,itemId,count,online:true,inventory:p.inventory}); break; }
      const a=accounts[accountId]; if(!a){jsonRes(res,404,{ok:false,error:'account_not_found'});break;}
      const sd=savedPlayers[a.nickname]||savePlayerData({x:0,y:0,health:100,inventory:{},hotbar:[0,0,0,0,0,0,0,0,0,0],hunger:20,xp:0,level:1,armor:0,equipment:{}}); sd.inventory=sd.inventory||{}; sd.inventory[itemId]=(sd.inventory[itemId]||0)+count; savedPlayers[a.nickname]=sd; savePlayers(); logAdmin('give_item','op',a.nickname,'item='+itemId+' count='+count+' offline'); jsonRes(res,200,{ok:true,nickname:a.nickname,itemId,count,online:false,inventory:sd.inventory}); break;
    }
    // ---------- V3.7 管理接口（全部需要 op 鉴权） ----------
    case '/api/op/status': {
      if (!requireOp(res, opAuthed)) break;
      const mem = process.memoryUsage();
      jsonRes(res, 200, {
        ok: true,
        online: players.size,
        uptime: Math.floor(process.uptime()),
        memoryMB: Math.round(mem.rss / 1024 / 1024),
        worldChanges: worldTiles.size,
        day: gameDay, time: gameTime,
        config,
        banned: banlist.length,
        kicked: Object.keys(kicklist).length,
        privileged: Object.values(roles).filter(r=>r==='admin'||r==='developer').length,
      });
      break;
    }
    case '/api/op/kick': {
      if (!requireOp(res, opAuthed)) break;
      const p = players.get(Number(data.id));
      if (!p) { jsonRes(res, 404, {ok:false, error:'not_online'}); break; }
      kickPlayer(p.nickname, 'op', data.reason);
      removePlayer(Number(data.id), { type:'kick', reason: data.reason || '你已被管理员踢出（5分钟内无法重进）' });
      jsonRes(res, 200, {ok:true});
      break;
    }
    case '/api/op/ban': {
      if (!requireOp(res, opAuthed)) break;
      let nickname = String(data.nickname || '');
      const p = players.get(Number(data.id));
      if (p) nickname = p.nickname;
      if (!nickname) { jsonRes(res, 400, {ok:false, error:'no_target'}); break; }
      banPlayer(nickname, data.reason, 'op');
      if (p) removePlayer(p.id, { type:'kick', reason:'你已被封禁' });
      jsonRes(res, 200, {ok:true});
      break;
    }
    case '/api/op/unban': {
      if (!requireOp(res, opAuthed)) break;
      const ok = unbanPlayer(String(data.nickname || ''), 'op');
      jsonRes(res, 200, {ok});
      break;
    }
    case '/api/op/setrole': {
      if (!requireOp(res, opAuthed)) break;
      let nickname = String(data.nickname || '');
      const p = players.get(Number(data.id));
      if (p) nickname = p.nickname;
      const role = String(data.role || 'player');
      if (!nickname || !['player','admin','developer'].includes(role)) {
        jsonRes(res, 400, {ok:false, error:'bad_params'}); break;
      }
      setRole(nickname, role, 'op');
      jsonRes(res, 200, {ok:true, nickname, role});
      break;
    }
    case '/api/op/setmode': {
      if (!requireOp(res, opAuthed)) break;
      const p = players.get(Number(data.id));
      const nickname = String(data.nickname || (p && p.nickname) || '').trim();
      const mode = String(data.mode || '');
      if (!nickname || !['survival','creative'].includes(mode)) {
        jsonRes(res, 400, {ok:false, error:'bad_params'}); break;
      }
      const role = getRole(nickname);
      if (role !== 'admin' && role !== 'developer') {
        jsonRes(res, 403, {ok:false, error:'mode_denied', message:'只有管理员或开发者可以使用创造模式'}); break;
      }
      if (role === 'developer') {
        playerModes[nickname] = 'creative';
      } else {
        playerModes[nickname] = mode;
      }
      saveJson(MODES_FILE, playerModes);
      if (p) {
        applyRole(p, role);
        sendTo(p.id, { type:'mode_update', id:p.id, mode:p.mode, canFly:!!p.canFly, infiniteItems:!!p.infiniteItems });
        broadcast({ type:'mode_update', id:p.id, mode:p.mode }, p.id);
      }
      broadcastPlayerList();
      logAdmin('setmode', 'op', nickname, 'mode=' + (p ? p.mode : mode));
      jsonRes(res, 200, {ok:true, nickname, mode:p ? p.mode : mode});
      break;
    }
    case '/api/op/config': {
      if (!requireOp(res, opAuthed)) break;
      // 只允许更新已知布尔开关，防止注入任意字段
      for (const k of ['pvp','creativeModeControl','chatEnabled','playerListDisplay','deathDrop','hungerEnabled','nuclearEnabled','mobilePerformance']) {
        if (typeof data[k] === 'boolean') config[k] = data[k];
      }
      saveJson(CONFIG_FILE, config);
      broadcast({ type:'config', config });
      logAdmin('config', 'op', '', JSON.stringify(config));
      jsonRes(res, 200, {ok:true, config});
      break;
    }
    case '/api/op/log': {
      if (!requireOp(res, opAuthed)) break;
      jsonRes(res, 200, {ok:true, log: adminLog.slice(-50).reverse()});
      break;
    }
    case '/api/op/announce': {
      if (!requireOp(res, opAuthed)) break;
      const text = String(data.text || '').trim().slice(0, CHAT_MAX_LEN);
      if (text) serverMessage(text);
      logAdmin('announce', 'op', '', text);
      jsonRes(res, 200, {ok:true});
      break;
    }

    // ---------- 旧版管理接口（保留路径兼容旧管理面板，V3.7 起要求鉴权） ----------
    case '/api/save': {
      if (!requireOp(res, opAuthed)) break;
      saveWorld();
      logAdmin('save', 'op', '', '');
      jsonRes(res, 200, {ok:true});
      break;
    }
    case '/api/kick': {
      if (!requireOp(res, opAuthed)) break;
      const p = players.get(Number(data.id));
      if (p) {
        kickPlayer(p.nickname, 'op', data.reason);
        removePlayer(Number(data.id), { type:'kick', reason:'你已被管理员踢出（5分钟内无法重进）' });
      }
      jsonRes(res, 200, {ok:true});
      break;
    }
    case '/api/reset': {
      if (!requireOp(res, opAuthed)) break;
      worldInteractions.chests={};worldInteractions.leases.clear();worldInteractions.drops.clear();worldInteractions.save();
      worldTiles.clear();
      pendingSync.clear();
      logAdmin('reset', 'op', '', '世界差量已清空');
      jsonRes(res, 200, {ok:true});
      break;
    }
    case '/api/ban': {
      if (!requireOp(res, opAuthed)) break;
      const p = players.get(Number(data.id));
      if (p) {
        banPlayer(p.nickname, data.reason, 'op');
        removePlayer(Number(data.id), { type:'kick', reason:'你已被封禁' });
      }
      jsonRes(res, 200, {ok:true});
      break;
    }
    case '/api/unban': {
      if (!requireOp(res, opAuthed)) break;
      unbanPlayer(String(data.nickname||''), 'op');
      jsonRes(res, 200, {ok:true});
      break;
    }

    // ---------- 游戏协议接口（公开，HTTP 轮询模式使用） ----------
    case '/api/join': {
      const accountId=accountIdFromToken(data.accountToken);
      if(!accountId){jsonRes(res,401,{ok:false,error:'请先登录'});return;}
      if([...players.values()].some(p=>p.accountId===accountId)){jsonRes(res,409,{ok:false,error:'账户已在线'});return;}
      const nickname=accounts[accountId].nickname;
      // V3.7 加入检查：先 Ban 后 Kick
      if (isBanned(nickname)) { jsonRes(res, 403, {error:'banned', reason:'你已被封禁'}); break; }
      const remain = kickedRemain(nickname);
      if (remain > 0) { jsonRes(res, 403, {error:'kicked', until: Date.now() + remain, reason:'你已被踢出，请 ' + Math.ceil(remain/60000) + ' 分钟后再试'}); break; }
      const id = nextId++;
      const role = getRole(nickname);
      const old = savedPlayers[nickname] || {};
      const p = applyRole({
        id, ws: null, accountId, nickname,
        x: Number.isFinite(Number(old.x)) ? Number(old.x) : 0,
        y: Number.isFinite(Number(old.y)) ? Number(old.y) : 0,
        vx: 0, vy: 0, facing: old.facing || 1, walkPhase: 0,
        health: old.health || 100, hunger:old.hunger ?? 20, xp:old.xp||0, level:old.level||1,
        armor:old.armor||0, equipment:old.equipment||{},
        inventory: old.inventory || {},
        inventorySlots: Array.isArray(old.inventorySlots) ? old.inventorySlots : [],
        hotbar: old.hotbar || [0,0,0,0,0,0,0,0,0,0],
        lastActive: Date.now(), messages: [],
      }, role);
      players.set(id, p);
      // 加入即同步时间：把当前权威昼夜时钟以 force 形式塞进消息队列，
      // 客户端 poll 时会随 welcome 一并拿到并立即对齐（与 WS 模式一致）。
      p.messages.push({ type: 'sync', t: gameTime, day: gameDay, tiles: null, force: true });
      broadcast({ type: 'join', id, nickname, role: p.role, prefix: p.prefix, mode: p.mode }, id);
      broadcastOnlineCount();
      broadcastPlayerList();
      console.log(`[HTTP join] id=${id} nickname=${nickname} role=${p.role} (${players.size} online)`);
      jsonRes(res, 200, {
        id, seed: WORLD_SEED,
        role: p.role, prefix: p.prefix, mode: p.mode,
        canFly: p.canFly, infiniteItems: p.infiniteItems,
        x: p.x, y: p.y, inventory: p.inventory || {}, inventorySlots: p.inventorySlots || [], hotbar: p.hotbar || [],
        config,
        players: getPlayerList(id),
        worldstate: worldStatePayload(), // 下发服务端权威世界差量
      });
      break;
    }
    case '/api/players': {
      const list = getPlayerList();
      jsonRes(res, 200, {
        count: list.length,
        players: list.map(p => ({
          id:p.id, accountId:p.accountId, nickname:p.nickname, x:p.x, y:p.y, health:p.health, hunger:p.hunger, armor:armorReduction(p), xp:p.xp, level:p.level, online:true,
          role:p.role, prefix:p.prefix, mode:p.mode,
        }))
      });
      break;
    }
    case '/api/player/info': {
      const p = players.get(Number(data.id));
      jsonRes(res, 200, p ? {
        ok:true, id:data.id, nickname:p.nickname, x:p.x, y:p.y, health:p.health,
        role:p.role, prefix:p.prefix, mode:p.mode,
      } : {ok:false});
      break;
    }
    case '/api/chat': {
      // HTTP 轮询模式聊天
      const p = players.get(Number(data.id));
      if (!p) { jsonRes(res, 404, {ok:false, error:'not_online'}); break; }
      p.lastActive = Date.now();
      handleChat(p, data.text, data.channel);
      jsonRes(res, 200, {ok:true});
      break;
    }
    case '/api/move': {
      const p = players.get(data.id);
      if (!p) { res.writeHead(404); res.end('Not found'); return; }
      p.x = data.x; p.y = data.y;
      p.vx = data.vx; p.vy = data.vy;
      p.facing = data.facing; p.walkPhase = data.walkPhase;
      p.health = data.health;
      p.lastActive = Date.now();
      broadcast({ type: 'move', id: data.id, ...data }, data.id);
      res.writeHead(200); res.end('OK');
      break;
    }
    case '/api/block': {
      const p = players.get(data.id);
      if (p) p.lastActive = Date.now();
      if(recordBlock(data.tx, data.ty, data.tileId,p)===false){jsonRes(res,403,{ok:false,error:'箱子受保护'});return;} // 记入权威世界
      broadcast({ type: 'block', id: data.id, tx: data.tx, ty: data.ty, tileId: data.tileId }, data.id);
      res.writeHead(200); res.end('OK');
      break;
    }
    case '/api/flash': {
      // 闪光弹事件（HTTP 轮询模式上报）：转发给其他在线玩家
      const p = players.get(data.id);
      if (p) p.lastActive = Date.now();
      broadcast({ type: 'flash', id: data.id, x: data.x, y: data.y }, data.id);
      res.writeHead(200); res.end('OK');
      break;
    }
    case '/api/sleep': {
      // 床跳过黑夜（HTTP 轮询模式）：把服务端权威昼夜时钟跳到早晨并立即广播
      gameTime = 0;
      broadcast({ type: 'sync', t: gameTime, day: gameDay, tiles: null, force: true });
      res.writeHead(200); res.end('OK');
      break;
    }
    case '/api/poll': {
      const p = players.get(data.id);
      if (!p) { res.writeHead(404); res.end('Not found'); return; }
      // V3.7：HTTP 模式玩家同样受 Ban/Kick 约束（轮询时检查，立即生效）
      if (isBanned(p.nickname)) {
        removePlayer(data.id, { type:'kick', reason:'你已被封禁' });
        jsonRes(res, 403, {error:'banned'}); return;
      }
      if (kickedRemain(p.nickname) > 0) {
        removePlayer(data.id, { type:'kick', reason:'你已被踢出' });
        jsonRes(res, 403, {error:'kicked'}); return;
      }
      p.lastActive = Date.now();
      const messages = p.messages || [];
      p.messages = [];
      const playerList = getPlayerList(data.id);
      playerList.unshift({
        id: data.id, nickname: p.nickname,
        x: p.x, y: p.y, vx: p.vx, vy: p.vy,
        facing: p.facing, walkPhase: p.walkPhase, health: p.health,
        inventory: p.inventory || {},
        hotbar: p.hotbar || [],
        role: p.role, prefix: p.prefix, mode: p.mode,
      });
      jsonRes(res, 200, { messages, players: playerList });
      break;
    }
    case '/api/action': { const p=players.get(Number(data.id)); if(p&&data.type==='use_food') useFood(p,data.itemId); else if(p&&data.type==='equip_armor') equipArmor(p,data.itemId); else if(p&&data.type==='unequip_armor') unequipArmor(p); else if(p&&data.type==='player_death') handlePlayerDeath(p,data.cause||'client'); jsonRes(res,200,{ok:true}); break;}
    default:
      res.writeHead(404); res.end('Not Found');
  }
}

// ==================== WebSocket 服务器 ====================
const wss = new WebSocket.Server({ server });

wss.on('connection', (ws) => {
  const id = nextId++;
  console.log(`[connect] id=${id}`);

  ws.on('message', (raw) => {
    let msg;
    try { msg = JSON.parse(raw); } catch { return; }

    const p = players.get(id);
    if (p) p.lastActive = Date.now();

    if(msg.type==='world_action'){
      sendTo(id,{type:'world_result',requestId:msg.requestId,...handleWorldAction(p,msg)});return;
    }
    switch (msg.type) {
      case 'join': {
        const accountId = accountIdFromToken(msg.accountToken);
        const account = accountId ? accounts[accountId] : null;
        if (!account) { ws.send(JSON.stringify({type:'kick',reason:'请先登录游戏账户'})); try{ws.close();}catch(e){} return; }
        if ([...players.values()].some(x=>x.accountId===accountId)) { ws.send(JSON.stringify({type:'kick',reason:'该账户已经在线'})); try{ws.close();}catch(e){} return; }
        const nickname = account.nickname;
        // V3.7 加入检查：先 Ban 后 Kick，不通过则告知原因并断开
        if (isBanned(nickname)) {
          ws.send(JSON.stringify({ type:'kick', reason:'你已被封禁，无法加入服务器' }));
          try { ws.close(); } catch (e) {}
          return;
        }
        const remain = kickedRemain(nickname);
        if (remain > 0) {
          ws.send(JSON.stringify({ type:'kick', reason:'你已被踢出，请 ' + Math.ceil(remain/60000) + ' 分钟后再试' }));
          try { ws.close(); } catch (e) {}
          return;
        }
        const old = savedPlayers[nickname] || {};
        const role = getRole(nickname);
        const np = applyRole({
          id, ws, accountId, nickname,
          x: old.x || 0, y: old.y || 0, vx: 0, vy: 0, facing: old.facing || 1, walkPhase: 0, health: old.health || 100, hunger:old.hunger ?? 20, xp:old.xp||0, level:old.level||1, armor:old.armor||0, equipment:old.equipment||{},
          inventory: old.inventory || {},
          inventorySlots: Array.isArray(old.inventorySlots) ? old.inventorySlots : [],
          hotbar: old.hotbar || [0,0,0,0,0,0,0,0,0,0],
          lastActive: Date.now(), messages: [],
        }, role);
        players.set(id, np);

        const playerList = [];
        for (const [pid, op] of players) {
          if (pid !== id) {
            playerList.push({
              id: pid, nickname: op.nickname,
              x: op.x, y: op.y, vx: op.vx, vy: op.vy,
              facing: op.facing, walkPhase: op.walkPhase, health: op.health,
              inventory: op.inventory || {},
              inventorySlots: op.inventorySlots || [],
              hotbar: op.hotbar || [],
              role: op.role || 'player', prefix: op.prefix || '',
              mode: op.mode || 'survival',
            });
          }
        }
        // 欢迎消息携带服务端权威世界差量 + V3.7 身份/模式/世界配置
        sendTo(id, {
          type: 'welcome', id, seed: WORLD_SEED,
          players: playerList,
          inventory: np.inventory || {}, inventorySlots: np.inventorySlots || [], hotbar: np.hotbar || [],
          x: np.x, y: np.y,
          role: np.role, prefix: np.prefix, mode: np.mode,
          canFly: np.canFly, infiniteItems: np.infiniteItems,
          config,
          worldstate: worldStatePayload(),
        });
        // 加入即同步时间：立即推一条 force 同步，客户端收到瞬间对齐昼夜（无需等 200ms 广播收敛）
        sendTo(id, { type: 'sync', t: gameTime, day: gameDay, tiles: null, force: true });

        broadcast({ type: 'join', id, nickname, role: np.role, prefix: np.prefix, mode: np.mode }, id);
        broadcastOnlineCount();
        broadcastPlayerList();
        console.log(`[join] id=${id} nickname=${nickname} role=${np.role} (${players.size} online)`);
        break;
      }
      case 'playerData': {
        const p = players.get(id);
        if (!p) return;
        p.inventory = msg.inventory || {};
        if (Array.isArray(msg.inventorySlots)) p.inventorySlots = msg.inventorySlots;
        p.hotbar = msg.hotbar || [];
        p.x = msg.x ?? p.x;
        p.y = msg.y ?? p.y;
        break;
      }
      case 'move': {
        const p = players.get(id);
        if (!p) return;
        p.x = msg.x; p.y = msg.y;
        p.vx = msg.vx; p.vy = msg.vy;
        p.facing = msg.facing; p.walkPhase = msg.walkPhase;
        if (p.invulnerableUntil && Date.now()<p.invulnerableUntil) p.health=Math.max(1,p.health);
        if (Number(msg.health)<=0) handlePlayerDeath(p,'client');
        p.lastActive = Date.now();
        broadcast({ type: 'move', id, ...msg }, id);
        break;
      }
      case 'block': {
        const p = players.get(id);
        if (p) p.lastActive = Date.now();
        if(recordBlock(msg.tx, msg.ty, msg.tileId,p)===false){sendTo(id,{type:'block',tx:msg.tx,ty:msg.ty,tileId:worldTiles.get(msg.ty*WORLD_W+msg.tx)});return;} // 记入权威世界
        broadcast({ type: 'block', id, tx: msg.tx, ty: msg.ty, tileId: msg.tileId }, id);
        break;
      }
      case 'chat': {
        // V3.7 聊天：身份前缀 + 公告频道 + 限速（逻辑在 handleChat）
        handleChat(players.get(id), msg.text, msg.channel);
        break;
      }
      case 'pvp_hit': {
        // V3.7 PVP：服务端开关 + 伤害/距离校验（逻辑在 handlePvpHit）
        handlePvpHit(players.get(id), msg);
        break;
      }
      case 'use_food': { const p=players.get(id); if(p) useFood(p,msg.itemId); break; }
      case 'unequip_armor': {const p=players.get(id);if(p)unequipArmor(p);break;}
      case 'equip_armor': { const p=players.get(id); if(p) equipArmor(p,msg.itemId); break; }
      case 'player_death': { const p=players.get(id); if(p && (p.health<=0 || msg.confirm===true)) handlePlayerDeath(p,msg.cause||'client'); break; }
      case 'flash': {
        // 闪光弹事件转发：其他客户端按距离自行判定是否被闪
        const p = players.get(id);
        if (p) p.lastActive = Date.now();
        broadcast({ type: 'flash', id, x: msg.x, y: msg.y }, id);
        break;
      }
      case 'sleep': {
        // 床跳过黑夜：把服务端权威昼夜时钟直接跳到早晨，并立即广播（force=true 让所有客户端瞬间对齐）
        gameTime = 0;
        broadcast({ type: 'sync', t: gameTime, day: gameDay, tiles: null, force: true });
        break;
      }
    }
  });

  ws.on('close', () => {
    const closingPlayer=players.get(id);if(closingPlayer?.accountId)worldInteractions.release(closingPlayer.accountId);

    if (players.has(id)) {
      const p = players.get(id);
      savedPlayers[p.nickname] = savePlayerData(p);
      savePlayers();
      players.delete(id);
      broadcast({ type: 'leave', id });
      broadcastOnlineCount();
      broadcastPlayerList();
      console.log(`[leave] id=${id} nickname=${p.nickname} (${players.size} online)`);
    }
  });

  ws.on('error', () => {
    // V3.7 修复：旧版此处引用了未定义的 p 会直接抛异常
    if (players.has(id)) {
      const p = players.get(id);
      savedPlayers[p.nickname] = savePlayerData(p);
      savePlayers();
      players.delete(id);
      broadcast({ type: 'leave', id });
      broadcastOnlineCount();
      broadcastPlayerList();
    }
  });
});

// ==================== 启动 / 退出 ====================
server.listen(PORT, "0.0.0.0", () => {
  // 初始化：新建 world / data 存档目录（已存在则忽略），并恢复最近一份存档
  if (!fs.existsSync(WORLD_DIR)) fs.mkdirSync(WORLD_DIR, { recursive: true });
  if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
  loadLatestWorld();
  console.log(`✅ 像素沙盒 · 服务器版 V3.7（核心合并版）已启动，端口 ${PORT}`);
  console.log(`   世界种子: ${WORLD_SEED}（WORLD_W=${WORLD_W} WORLD_H=${WORLD_H}，须与 js/data.js 一致）`);
  console.log(`   存档目录: ${WORLD_DIR}（每 ${SAVE_INTERVAL_MS}ms 按系统时间命名落盘一份世界数据）`);
  console.log(`   数据目录: ${DATA_DIR}（roles/banlist/kicklist/admin-log/config）`);
  console.log(`   世界配置: PVP=${config.pvp} 聊天=${config.chatEnabled} 创造管控=${config.creativeModeControl}`);
  console.log(`   静态托管: index.html / css / js`);
  startSakuraFrpWatcher((info) => {
    if (info && info.url) {
      console.log(`   🌐 SakuraFrp 公网地址: ${info.url}`);
      console.log(`   🔌 WebSocket: ${info.wsUrl}`);
    }
  });
});

// 构建权威世界数据快照（落盘与退出前保存共用）
function buildWorldPayload() {
  return {
    seed: WORLD_SEED,
    time: gameTime,
    day: gameDay,
    savedAt: new Date().toISOString(),
    tiles: Array.from(worldTiles.entries()),
  };
}

// 将权威世界数据落盘到 world/（按系统时间命名）。异步写，不阻塞主循环。
function saveWorld() {
  const file = path.join(WORLD_DIR, `world_${fileTimestamp()}.json`);
  fs.writeFile(file, JSON.stringify(buildWorldPayload()), (err) => {
    if (err) console.error('[save] 世界数据保存失败:', err.message);
    else pruneOldSaves();
  });
}

// 自动清理：只保留最近 MAX_SAVE_FILES 份存档，超出部分删除最旧的（文件名定宽时间戳，字典序=时间序）
function pruneOldSaves() {
  let files;
  try {
    files = fs.readdirSync(WORLD_DIR).filter(f => /^world_\d{4}-\d{2}-\d{2}_.*\.json$/.test(f));
  } catch (e) { return; }
  if (files.length <= MAX_SAVE_FILES) return;
  files.sort();
  const excess = files.slice(0, files.length - MAX_SAVE_FILES);
  let removed = 0;
  for (const f of excess) {
    try { fs.unlinkSync(path.join(WORLD_DIR, f)); removed++; } catch (e) {}
  }
  if (removed > 0) console.log(`[save] 已自动清理 ${removed} 份过期存档（保留最近 ${MAX_SAVE_FILES} 份）`);
}

// 启动时从 world/ 读取最近一份存档，恢复权威世界（差量方块 + 昼夜时钟）。
// 文件名含毫秒时间戳且定宽，按字典序即时间序，取最后一个即最新。
function loadLatestWorld() {
  let files;
  try {
    files = fs.readdirSync(WORLD_DIR).filter(f => /^world_\d{4}-\d{2}-\d{2}_.*\.json$/.test(f));
  } catch (e) { return; }
  if (files.length === 0) {
    console.log('   [存档] 未找到历史存档，从种子地形开始新世界');
    return;
  }
  files.sort();
  const latest = files[files.length - 1];
  try {
    const data = JSON.parse(fs.readFileSync(path.join(WORLD_DIR, latest), 'utf8'));
    if (Array.isArray(data.tiles)) {
      for (const [k, v] of data.tiles) worldTiles.set(k, v);
    }
    if (typeof data.time === 'number') gameTime = data.time;
    if (typeof data.day === 'number') gameDay = data.day;
    console.log(`   [存档] 已恢复最近存档: ${latest}（${worldTiles.size} 处方块改动，day=${gameDay} time=${gameTime.toFixed(3)}）`);
  } catch (e) {
    console.error('   [存档] 读取最近存档失败，回退到种子地形:', e.message);
  }
}

// 优雅退出
function shutdown(signal) {
  console.log(`\n[world] 收到 ${signal}，退出前同步保存一份世界数据...`);
  try {
    const file = path.join(WORLD_DIR, `world_${fileTimestamp()}.json`);
    fs.writeFileSync(file, JSON.stringify(buildWorldPayload()));
  } catch (e) {
    console.error('[save] 退出前保存失败:', e.message);
  }
  process.exit(0);
}
process.on('SIGINT', () => shutdown('SIGINT'));
process.on('SIGTERM', () => shutdown('SIGTERM'));

// 定时检查无操作玩家，超时则踢出
setInterval(() => {
  const now = Date.now();
  for (const [id, p] of players) {
    if (now - p.lastActive > IDLE_TIMEOUT) {
      console.log(`[timeout] 踢出 id=${id} nickname=${p.nickname} (无操作${Math.round((now - p.lastActive) / 1000)}秒)`);
      if (p.ws) {
        try {
          p.ws.send(JSON.stringify({ type: 'kick', reason: '无操作超时，已被自动踢出' }));
          p.ws.close();
        } catch (e) {}
      }
      savedPlayers[p.nickname] = savePlayerData(p);
      savePlayers();
      players.delete(id);
      broadcast({ type: 'leave', id });
      broadcastOnlineCount();
      broadcastPlayerList();
    }
  }
}, 10000);

// 200ms 高频同步（动态地图 + 权威时钟）：
//   - 时间：广播服务端权威昼夜（t/day），所有客户端昼夜一致
//   - 地图：合并广播本窗口内的方块改动（增量，非全量）
setInterval(() => {
  if (players.size === 0) return;
  // 权威时钟推进：200ms / dayLength(360s) = 0.2/360
  gameTime += 0.2 / 360;
  if (gameTime >= 1) { gameTime -= 1; gameDay++; }
  // 时间与增量地图合并成一条消息发送（省一次消息往返）
  const tiles = pendingSync.size > 0 ? Array.from(pendingSync.entries()) : null;
  pendingSync.clear();
  broadcast({ type: 'sync', t: gameTime, day: gameDay, tiles });
}, 200);

// 每 100ms 将权威世界（差量方块 + 昼夜时钟）按系统时间命名保存到 world/ 文件夹
setInterval(saveWorld, SAVE_INTERVAL_MS);

// 60 秒全量兜底：确保断线重连或网络丢包后客户端能纠正方块不一致（仅在有改动时发送）
setInterval(() => {
  if (worldTiles.size === 0 || players.size === 0) return;
  const payload = { type: 'worldstate', tiles: Array.from(worldTiles.entries()) };
  broadcast(payload);
  console.log(`[sync] 广播 worldstate（${worldTiles.size} 处方块改动）`);
}, 60000);

// 玩家自动保存
setInterval(() => { try { savePlayers(); } catch(e){} }, PLAYER_AUTO_SAVE);
