# Pixel Sandbox HTML V4.3.1

基于上传的 V4.3.0 完整源码升级，网页客户端入口 `index.html`，服务端入口 `server/server.js`。

## 启动

安装 Node.js 24 或以上，在项目根目录执行 `node server/server.js`，访问 `http://localhost:8080`。
发行包包含纯 JavaScript 的 ws 依赖；如需重装，在 server 目录执行 `npm install`。
Windows 也可双击 `deploy/windows/start-server.bat`。Linux 使用 `bash deploy/linux/start-linux.sh`。
生产部署通过 OP_PASSWORD 环境变量设置管理密码。PORT 默认 8080。管理入口 `/op`。

## 操作

- 手机：直接上下滑动滚动背包，按住物品 240ms 再拖动，松手放入高亮槽位。
- 电脑：拖动物品，或点击拿起、再点击目标槽位。拖到面板外取消。
- 背包与快捷栏共享物品数量；快捷栏是引用，不是另一份物品。
- 箱子物品可拖到左侧“放回背包”，同类物品合并。背包满时恢复原箱子槽。
- 护甲拖到护甲槽后由服务器装备；“卸下”返回背包。

## 升级与存档

先停止旧服务并备份整个旧目录。在新目录解压本发行包后，将旧服 `server/data/`、`server/world/`、`server/players.json` 复制到新目录对应位置，再启动。
源码目录保留上传包中的原数据；发布 ZIP 不包含账户、历史玩家、权限表、后台日志或世界存档，防止把原服私人数据分发出去。未迁移数据时首次启动生成新世界。
旧版备份不要删除，回退时恢复旧程序与对应备份。不要让两套服务同时写同一份存档。

## 验证

执行 `npm test`。测试使用隔离的临时服务与测试账号，不修改你的正式存档。
自动测试覆盖物品转移、槽位交换、取消恢复、滚动识别、多指隔离、HTTP 启动、注册和 WebSocket 握手。
尚需在 Android 和 iPhone/iPad 真机上验收触控与软键盘；本版不宣称已完成所有设备验证。
未来阶段和已知限制见 CHANGELOG.txt。现有 HTTP 轮询动作鉴权及客户端上报背包仍需后续专项加固，本版不是完整反作弊升级。
