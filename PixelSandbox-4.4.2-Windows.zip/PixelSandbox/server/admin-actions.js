// [V3.7] 本模块已正式合并进 server.js（核心合并版），此文件仅保留作设计参考，不再被引用。
// V3.2 Admin action definitions
// kick: temporary remove (5 minutes)
// ban: block until unban
// mode: survival / creative

module.exports={
    actions:[
        "kick",
        "ban",
        "unban",
        "set_mode"
    ]
};