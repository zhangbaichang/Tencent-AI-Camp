/*
 Client HUD player list V3.3
 - max 5 visible players
 - scroll container
 - update from websocket player_list_update
*/
function updateOnlinePlayers(list){
 console.log("online players",list);
}