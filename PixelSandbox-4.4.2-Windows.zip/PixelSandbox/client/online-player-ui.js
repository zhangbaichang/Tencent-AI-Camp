// V3.2 Client online player UI logic
// Receives player_list_update websocket messages
// Displays up to 5 players with scrolling support