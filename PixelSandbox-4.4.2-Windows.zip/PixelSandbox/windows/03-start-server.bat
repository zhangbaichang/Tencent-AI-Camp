@echo off
setlocal EnableExtensions

title Pixel Sandbox Server

set "ROOT=%~dp0.."
set "SERVER=%ROOT%\server"

if not exist "%SERVER%\server.js" (
  echo [ERROR] 找不到 server\server.js
  echo "%SERVER%\server.js"
  pause
  exit /b 1
)

if not exist "%SERVER%\node_modules\ws" (
  echo [Pixel Sandbox] 依赖未安装。
  echo 请先运行 windows\02-install-depend.bat
  echo.
  pause
  exit /b 1
)

cd /d "%SERVER%"
if errorlevel 1 (
  echo [ERROR] 无法进入 server 目录。
  pause
  exit /b 1
)

echo ========================================
echo Pixel Sandbox Server
echo ========================================
echo Node.js:
call node -v
echo.
echo Server directory:
echo "%SERVER%"
echo.
echo Listening target: 0.0.0.0:8080
echo ========================================
echo.

call node server.js

echo.
echo ========================================
echo Server process exited.
echo ========================================
pause
exit /b 0
