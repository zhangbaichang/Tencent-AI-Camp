@echo off
setlocal
cd /d "%~dp0..\.."
node server\server.js
pause
