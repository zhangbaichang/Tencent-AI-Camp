/**
 * 像素沙盒 - 主游戏引擎
 * 玩家物理 / 渲染 / 挖掘建造 / 合成 / 敌人 / 昼夜 / UI
 */
(function() {
'use strict';

const { TILE, WORLD_W, WORLD_H, GRAVITY, MAX_FALL, PLAYER_SPEED, JUMP_FORCE, REACH } = window.GAME_CONST;
const BLOCKS = window.BLOCKS;
const RECIPES = window.RECIPES;
const WorldGen = window.WorldGen;
const getBlockShade = window.getBlockShade;
const BLOCK_ELEMENTS = window.BLOCK_ELEMENTS;
const ELEMENT_INFO = window.ELEMENT_INFO;
const ELEMENT_REACTIONS = window.ELEMENT_REACTIONS;
const PERIODIC_TABLE = window.PERIODIC_TABLE;
const ORE_ELEMENT_MAP = window.ORE_ELEMENT_MAP;

// 世界种子：固定值，保证每次进入世界一致（联机时与服务端相同，所有玩家世界一致）
const WORLD_SEED = 7777;

// ==================== 游戏状态 ====================
const game = {
  canvas: null, ctx: null,
  lightCanvas: null, lightCtx: null,
  world: null, surface: null,
  camX: 0, camY: 0,
  cw: 0, ch: 0,
  keys: {},
  mouse: { x: 0, y: 0, worldX: 0, worldY: 0, left: false, right: false },
  player: null,
  enemies: [],
  particles: [],
  droppedItems: [],
  inventory: {},
  hotbar: [0,0,0,0,0,0,0,0,0,0], // 方块ID
  hotbarCounts: [0,0,0,0,0,0,0,0,0,0],
  selectedSlot: 0,
  hoveredSlot: -1,
  time: 0.15, // 0~1 一天
  dayLength: 360, // 秒（原120，放慢约3倍，昼夜节奏更舒缓）
  mining: { target: null, progress: 0, x:0, y:0 },
  craftingOpen: false,
  craftingDirty: true,
  craftingMode: 'hand', // 'hand' | 'workbench' | 'furnace'
  inventoryOpen: false,
  inventoryDirty: true,
  paused: false,
  fps: 0,
  showMap: false,
  // 卡牌对战
  battleTarget: null,
  battleCards: [],       // 已选热栏槽位索引（最多3个）
  battleOpen: false,
  battleCooldown: 0,
  battleAnimating: false, // 攻击动画进行中
  discoveredElements: new Set(), // 已发现的化学元素符号
  elementPopupActive: false, // 周期表弹窗是否显示
  regenAccum: 0, // 血量回复累积
  // 手机触屏输入
  touchInput: {
    moveX: 0,       // 摇杆水平: -1/0/1
    moveY: 0,       // 摇杆垂直: -1/0/1（用于 8 向瞄准）
    jump: false,    // 跳跃按钮
    mine: false,    // 挖掘按钮(持续)
    place: false,   // 放置按钮(单次)
    drop: false,    // 甩落/丢弃按钮(单次)
    tap: false,     // 画布点击(单次,用于敌人交互)
    isTouch: false, // 是否触屏设备
    aimX: 0,        // 玩家在画布上点选的世界坐标 X（用于自主选择挖掘/放置目标）
    aimY: 0,        // 玩家在画布上点选的世界坐标 Y
    aimActive: false, // 是否已点选目标方块（true 时优先用点选块，false 时回退摇杆自动瞄准）
  },
  // 联机
  nickname: null,
  multiplayer: {
    ws: null,
    myId: null,
    connected: false,
    players: new Map(),
    sendAccum: 0,
    reconnectDelay: 0,
  },
};

// ==================== 初始化 ====================
function init() {
  if (game._initialized) return;
  game._initialized = true;
  game.canvas = document.getElementById('game-canvas');
  game.ctx = game.canvas.getContext('2d');
  resizeCanvas();
  window.addEventListener('resize', resizeCanvas);

  // 检测触屏设备
  if ('ontouchstart' in window || navigator.maxTouchPoints > 0) {
    game.touchInput.isTouch = true;
    document.body.classList.add('touch-device');
  }

  // 生成世界（固定种子，保证每次进入世界一致；联机时若服务端种子不同会自动对齐）
  setupWorld(WORLD_SEED);

  // 事件
  bindEvents();
  // 手机控件
  bindMobileControls();

  // 连接联机服务器
  connectMultiplayer();

  // 隐藏加载画面
  setTimeout(() => {
    const ls = document.getElementById('loading-screen');
    if (ls) ls.classList.add('hide');
  }, 800);

  // 启动游戏循环
  let lastTime = performance.now();
  let frameCount = 0, fpsTime = 0;
  function loop(now) {
    const dt = Math.min(50, now - lastTime);
    lastTime = now;
    frameCount++;
    fpsTime += dt;
    if (fpsTime > 500) { game.fps = Math.round(frameCount * 1000 / fpsTime); frameCount = 0; fpsTime = 0; }
    // 安全网：任何一次更新/渲染异常都只跳过本帧，绝不让游戏彻底卡死（死机）
    try {
      if (!game.paused) update(dt);
      render();
    } catch (err) {
      if (!game._loopErrShown) {
        game._loopErrShown = true;
        console.error('[loop error]', err);
        showToast('运行异常：' + (err && err.message ? err.message : err), 3000);
      }
    }
    requestAnimationFrame(loop);
  }
  requestAnimationFrame(loop);

  showToast('欢迎来到像素沙盒世界！', 2000);
}

// 根据种子生成世界 + 玩家（init 与联机收到服务端种子时都会调用）
function setupWorld(seed) {
  game.worldSeed = seed;
  console.log('[world] 种子 =', seed);
  const w = WorldGen.generateWorld(WORLD_W, WORLD_H, seed);
  game.world = w.world;
  game.surface = w.surfaceHeight;

  // 初始化水体分级数组（每格水位 0~4，初始水块为满级），供流体模拟使用
  game.waterLevels = new Uint8Array(WORLD_W * WORLD_H);
  for (let i = 0; i < game.world.length; i++) {
    if (game.world[i] === 12) game.waterLevels[i] = 4;
  }

  // 初始化岩浆分级数组（每格岩浆量 0~4，初始岩浆块为满级），与水体同步做流体模拟
  game.lavaLevels = new Uint8Array(WORLD_W * WORLD_H);
  for (let i = 0; i < game.world.length; i++) {
    if (game.world[i] === 63) game.lavaLevels[i] = 4;
  }

  // 门开关状态集合：存“开启”的门格索引（整扇门=上下两格都存）。开着的门可穿过、视觉上敞开
  game.openDoors = new Set();

  // 创建玩家（在地表中央，且避开水面/岩浆）
  const spawnTx0 = findSafeSpawnColumn();
  const spawnX = spawnTx0 * TILE;
  const spawnY = (game.surface[spawnTx0] - 2) * TILE;
  game.player = {
    x: spawnX, y: spawnY - 36,
    vx: 0, vy: 0,
    w: 18, h: 36,
    onGround: false,
    health: 100, maxHealth: 100,
    invuln: 0,
    lastDamageTime: 0,
    facing: 1,
    mining: false,
    walkPhase: 0,
  };

  // 给玩家一些初始物品
  game.inventory[4] = 10; // 10木头
  game.inventory[15] = 5; // 5火把
  game.inventory[13] = 20; // 20木板
  updateHotbar();
  game.hotbar[0] = 15; game.hotbarCounts[0] = 5;
  game.hotbar[1] = 4;  game.hotbarCounts[1] = 10;
  game.hotbar[2] = 13; game.hotbarCounts[2] = 20;
}

function resizeCanvas() {
  game.cw = game.canvas.width = game.canvas.clientWidth;
  game.ch = game.canvas.height = game.canvas.clientHeight;
}

// 方块图标 emoji
const BLOCK_EMOJI = {
  0:'', 1:'🌿', 2:'🟤', 3:'🪨', 4:'🪵', 5:'🍃', 6:'🏖️', 7:'⚫', 8:'🟠',
  9:'⚙️', 10:'🟡', 11:'💎', 12:'💧', 13:'🟧', 14:'🧱', 15:'🔥', 16:'🪟',
  17:'🔨', 18:'🏺', 19:'🟫', 20:'⬜', 21:'🟨', 22:'🟥', 23:'❄️', 24:'🧊', 25:'⬛',
  26:'🚪', 27:'📦', 28:'🚧', 29:'🔩', 30:'🟮', 31:'🔷', 32:'🏮', 33:'📚', 34:'⛓️', 35:'🔵',
  36:'⚪', 37:'🔮', 38:'🟩', 39:'🟦', 40:'🟡', 41:'💎',
  42:'⬜', 43:'💠', 44:'🟢', 45:'🔷', 46:'🧊',
  47:'🟠', 48:'🔇', 49:'🟨', 50:'🔍', 51:'🔌', 52:'💣', 53:'🧪', 54:'🔷', 55:'🔋',
  56:'⛏️', 57:'⛏️', 58:'⛏️',
};

// ==================== 世界操作 ====================
function getTile(tx, ty) {
  if (tx < 0 || tx >= WORLD_W || ty < 0 || ty >= WORLD_H) return 0;
  return game.world[ty * WORLD_W + tx];
}

function setTile(tx, ty, id) {
  if (tx < 0 || tx >= WORLD_W || ty < 0 || ty >= WORLD_H) return;
  const idx = ty * WORLD_W + tx;
  // 同步水体分级：移除水时清零，放置水时设为满级
  if (game.world[idx] === 12 && id !== 12) game.waterLevels[idx] = 0;
  if (id === 12) game.waterLevels[idx] = 4;
  // 同步岩浆分级：移除岩浆时清零，放置岩浆时设为满级（与水体同步）
  if (game.world[idx] === 63 && id !== 63) game.lavaLevels[idx] = 0;
  if (id === 63) game.lavaLevels[idx] = 4;
  game.world[idx] = id;
}

function isSolid(tx, ty) {
  const id = getTile(tx, ty);
  // 开着的门：可穿过（不视为实心）
  if (id === 26 && game.openDoors && game.openDoors.has(ty * WORLD_W + tx)) return false;
  return BLOCKS[id] && BLOCKS[id].solid;
}

function getTileLight(tx, ty) {
  const id = getTile(tx, ty);
  return BLOCKS[id] ? BLOCKS[id].light : 0;
}

// 检查以 (ctx, cty) 为中心、半径 rTiles 的方块区域内是否有发光方块（火把/灯笼/熔炉等）
// 用于判定某处是否"被照亮"——地下若无光源即视为黑暗，可生成怪物
function hasNearbyLight(ctx, cty, rTiles) {
  for (let dy = -rTiles; dy <= rTiles; dy++) {
    for (let dx = -rTiles; dx <= rTiles; dx++) {
      const id = getTile(ctx + dx, cty + dy);
      const b = BLOCKS[id];
      if (b && b.light && b.light > 0) return true;
    }
  }
  return false;
}

// 切换整扇门（占 2 格）的开关状态：开/关同时作用于上下两半
function toggleDoor(tx, ty) {
  if (getTile(tx, ty) !== 26) return;
  // 收集整扇门的两格索引
  const idxs = [ty * WORLD_W + tx];
  if (getTile(tx, ty - 1) === 26) idxs.push((ty - 1) * WORLD_W + tx);
  if (getTile(tx, ty + 1) === 26) idxs.push((ty + 1) * WORLD_W + tx);
  const nowOpen = !game.openDoors.has(idxs[0]);
  for (const i of idxs) {
    if (nowOpen) game.openDoors.add(i);
    else game.openDoors.delete(i);
  }
  sfx('click', { pan: audioPan(tx * TILE + TILE / 2) });
}

// 检查附近是否有工作台/熔炉
function hasCraftingStation(type) {
  const px = game.player.x / TILE | 0;
  const py = game.player.y / TILE | 0;
  for (let dx = -4; dx <= 4; dx++) {
    for (let dy = -4; dy <= 4; dy++) {
      const id = getTile(px + dx, py + dy);
      if (type === 'workbench' && id === 17) return true;
      if (type === 'furnace' && id === 18) return true;
    }
  }
  return false;
}

// ==================== 物理与碰撞 ====================
function moveEntity(e, dt) {
  const dts = dt / 16.67; // 标准化到60fps步长

  // X轴移动
  e.x += e.vx * dts;
  collideAxis(e, 'x');

  // Y轴移动（水中浮力：降低重力并限制下沉速度）
  const g = e.inWater ? GRAVITY * 0.18 : GRAVITY;
  const maxFall = e.inWater ? 2.2 : MAX_FALL;
  e.vy += g * dts;
  if (e.vy > maxFall) e.vy = maxFall;
  e.y += e.vy * dts;
  e.onGround = false;
  collideAxis(e, 'y');
}

function collideAxis(e, axis) {
  const minTx = Math.floor(e.x / TILE);
  const maxTx = Math.floor((e.x + e.w - 1) / TILE);
  const minTy = Math.floor(e.y / TILE);
  const maxTy = Math.floor((e.y + e.h - 1) / TILE);

  for (let ty = minTy; ty <= maxTy; ty++) {
    for (let tx = minTx; tx <= maxTx; tx++) {
      if (!isSolid(tx, ty)) continue;

      const tileLeft = tx * TILE;
      const tileTop = ty * TILE;
      const tileRight = tileLeft + TILE;
      const tileBottom = tileTop + TILE;

      if (axis === 'x') {
        if (e.vx > 0) { e.x = tileLeft - e.w; e.vx = 0; }
        else if (e.vx < 0) { e.x = tileRight; e.vx = 0; }
      } else {
        if (e.vy > 0) { e.y = tileTop - e.h; e.vy = 0; e.onGround = true; }
        else if (e.vy < 0) { e.y = tileBottom; e.vy = 0; }
      }
    }
  }

  // 世界边界
  if (e.x < 0) { e.x = 0; e.vx = 0; }
  if (e.x + e.w > WORLD_W * TILE) { e.x = WORLD_W * TILE - e.w; e.vx = 0; }
  if (e.y < 0) { e.y = 0; e.vy = 0; }
  if (e.y > WORLD_H * TILE) { e.y = 0; e.vy = 0; e.health = 0; } // 掉出世界
}

// 实体间碰撞解算：把 a 推出 b 的身体（a 受力、b 不动），用于玩家被怪物挡住
function pushOutOf(a, b) {
  const ox = Math.min(a.x + a.w, b.x + b.w) - Math.max(a.x, b.x);
  const oy = Math.min(a.y + a.h, b.y + b.h) - Math.max(a.y, b.y);
  if (ox <= 0 || oy <= 0) return;
  if (ox < oy) {
    if (a.x < b.x) a.x = b.x - a.w; else a.x = b.x + b.w;
  } else {
    if (a.y < b.y) { a.y = b.y - a.h; if (a.vy > 0) a.vy = 0; }
    else { a.y = b.y + b.h; if (a.vy < 0) a.vy = 0; }
  }
}

// 实体间碰撞解算：怪物之间优先在 x 方向散开，避免堆叠在同一列 / 同一 x 坐标
function resolveOverlapAABB(a, b) {
  const ox = Math.min(a.x + a.w, b.x + b.w) - Math.max(a.x, b.x);
  const oy = Math.min(a.y + a.h, b.y + b.h) - Math.max(a.y, b.y);
  if (ox <= 0 || oy <= 0) return;
  // 优先水平分离，保证重叠时两怪落在不同 x
  const pushX = ox / 2 + 0.1;
  const ax = a.x < b.x ? a.x - pushX : a.x + pushX;
  const bx = a.x < b.x ? b.x + pushX : b.x - pushX;
  if (!wouldBeSolidX(ax, a) && !wouldBeSolidX(bx, b)) {
    a.x = ax; b.x = bx;
    a.vx *= 0.5; b.vx *= 0.5;
  } else {
    // 水平推开会卡进墙里时，再退而求其次做垂直分离
    const pushY = oy / 2 + 0.1;
    if (a.y < b.y) { a.y -= pushY; b.y += pushY; } else { a.y += pushY; b.y -= pushY; }
    if (a.vy > 0) a.vy = 0;
    if (b.vy > 0) b.vy = 0;
  }
}

// 判断把实体放到 x（保持 y 不变）时是否会嵌进实心方块
function wouldBeSolidX(x, e) {
  const xl = Math.floor(x / TILE);
  const xr = Math.floor((x + e.w - 1) / TILE);
  const yt = Math.floor(e.y / TILE);
  const yb = Math.floor((e.y + e.h - 1) / TILE);
  for (let ty = yt; ty <= yb; ty++) {
    if (isSolid(xl, ty) || isSolid(xr, ty)) return true;
  }
  return false;
}

// ==================== 输入处理 ====================
function bindEvents() {
  window.addEventListener('keydown', e => {
    game.keys[e.code] = true;
    // 防止空格触发按钮点击（跳跃键）
    if (e.code === 'Space') e.preventDefault();
    // 对战时只允许 Escape（但动画期间禁止退出）
    if (game.battleOpen) {
      if (e.code === 'Escape' && !game.battleAnimating) closeBattle();
      return;
    }
    // 热栏选择
    if (e.code.startsWith('Digit')) {
      const n = parseInt(e.code.slice(5));
      game.selectedSlot = (n === 0) ? 9 : n - 1;
    }
    if (e.code === 'KeyE') {
      game.inventoryOpen = !game.inventoryOpen;
      if (game.inventoryOpen) game.craftingOpen = false;
      game.inventoryDirty = true;
    }
    if (e.code === 'KeyQ' && !e.repeat) {
      dropSelected(); // 甩落当前手持物品
    }
    if (e.code === 'Tab') {
      e.preventDefault();
      if (!game.craftingOpen) {
        game.craftingOpen = true;
        game.craftingMode = 'hand';
      } else if (game.craftingMode !== 'hand') {
        game.craftingMode = 'hand';
      } else {
        game.craftingOpen = false;
      }
      if (game.craftingOpen) game.inventoryOpen = false;
      game.craftingDirty = true;
    }
    if (e.code === 'Escape') { game.craftingOpen = false; game.inventoryOpen = false; }
    if (e.code === 'KeyM') { game.showMap = !game.showMap; }
  });
  window.addEventListener('keyup', e => { game.keys[e.code] = false; });

  game.canvas.addEventListener('mousemove', e => {
    const rect = game.canvas.getBoundingClientRect();
    game.mouse.x = e.clientX - rect.left;
    game.mouse.y = e.clientY - rect.top;
    // 计算世界坐标
    game.mouse.worldX = game.camX + game.mouse.x;
    game.mouse.worldY = game.camY + game.mouse.y;
    // 热栏悬停检测
    const slotSize = 40, gap = 4;
    const totalW = 10 * slotSize + 9 * gap;
    const startX = (game.cw - totalW) / 2;
    const hotY = game.ch - slotSize - 16;
    if (game.mouse.y >= hotY && game.mouse.y <= hotY + slotSize) {
      const relX = game.mouse.x - startX;
      if (relX >= 0 && relX < totalW) {
        game.hoveredSlot = Math.floor(relX / (slotSize + gap));
        if (game.hoveredSlot < 0 || game.hoveredSlot > 9) game.hoveredSlot = -1;
      } else {
        game.hoveredSlot = -1;
      }
    } else {
      game.hoveredSlot = -1;
    }
  });

  game.canvas.addEventListener('mousedown', e => {
    e.preventDefault();
    // 热栏点击选择
    if (e.button === 0) {
      const slotSize = 44, gap = 4;
      const totalW = 10 * slotSize + 9 * gap;
      const startX = (game.cw - totalW) / 2;
      const hotY = game.ch - slotSize - 14;
      if (game.mouse.y >= hotY && game.mouse.y <= hotY + slotSize) {
        const relX = game.mouse.x - startX;
        if (relX >= 0 && relX < totalW) {
          const slot = Math.floor(relX / (slotSize + gap));
          if (slot >= 0 && slot <= 9 && game.hotbar[slot] > 0) {
            game.selectedSlot = slot;
            sfx('click');
            return;
          }
        }
      }
    }
    if (e.button === 0) game.mouse.left = true;
    if (e.button === 2) game.mouse.right = true;
  });
  game.canvas.addEventListener('mouseup', e => {
    if (e.button === 0) game.mouse.left = false;
    if (e.button === 2) game.mouse.right = false;
  });
  game.canvas.addEventListener('contextmenu', e => e.preventDefault());

  // 触屏支持
  function onTouchStart(e) {
    e.preventDefault();
    const t = e.touches[0];
    const rect = game.canvas.getBoundingClientRect();
    game.mouse.x = t.clientX - rect.left;
    game.mouse.y = t.clientY - rect.top;
    game.mouse.worldX = game.camX + game.mouse.x;
    game.mouse.worldY = game.camY + game.mouse.y;
    // 触屏设备：记录玩家点选的世界坐标，作为挖掘/放置的自主选择目标
    if (game.touchInput.isTouch) {
      game.touchInput.aimX = game.mouse.worldX;
      game.touchInput.aimY = game.mouse.worldY;
      game.touchInput.aimActive = true;
      game.touchInput.tap = true;
    } else {
      game.mouse.left = true;
    }
  }
  function onTouchMove(e) {
    e.preventDefault();
    const t = e.touches[0];
    const rect = game.canvas.getBoundingClientRect();
    game.mouse.x = t.clientX - rect.left;
    game.mouse.y = t.clientY - rect.top;
    game.mouse.worldX = game.camX + game.mouse.x;
    game.mouse.worldY = game.camY + game.mouse.y;
    // 触屏拖动时持续更新点选目标，便于玩家瞄准
    if (game.touchInput.isTouch) {
      game.touchInput.aimX = game.mouse.worldX;
      game.touchInput.aimY = game.mouse.worldY;
      game.touchInput.aimActive = true;
    }
  }
  function onTouchEnd(e) {
    if (game.touchInput.isTouch) {
      game.touchInput.tap = false;
    } else {
      game.mouse.left = false;
    }
  }
  game.canvas.addEventListener('touchstart', onTouchStart, { passive: false });
  game.canvas.addEventListener('touchmove', onTouchMove, { passive: false });
  game.canvas.addEventListener('touchend', onTouchEnd, { passive: false });
  game.canvas.addEventListener('touchcancel', onTouchEnd, { passive: false });

  // 合成界面点击
  document.getElementById('crafting-overlay').addEventListener('click', e => {
    if (e.target.id === 'crafting-overlay') game.craftingOpen = false;
  });

  // 背包界面点击
  document.getElementById('inventory-overlay').addEventListener('click', e => {
    if (e.target.id === 'inventory-overlay') game.inventoryOpen = false;
  });

  // 对战面板点击外部关闭
  const battleOverlay = document.getElementById('battle-overlay');
  if (battleOverlay) {
    battleOverlay.addEventListener('click', e => {
      if (e.target.id === 'battle-overlay' && !game.battleAnimating) {
        closeBattle();
      }
    });
  }
}

// ==================== 手机触屏控件 ====================
function bindMobileControls() {
  // ---- 虚拟摇杆 ----
  const joyBase = document.getElementById('joystick-base');
  const joyKnob = document.getElementById('joystick-knob');
  let joyActive = false;
  let joyCenterX = 0, joyCenterY = 0;

  function joyStart(e) {
    e.preventDefault();
    joyActive = true;
    joyBase.classList.add('active');
    const rect = joyBase.getBoundingClientRect();
    joyCenterX = rect.left + rect.width / 2;
    joyCenterY = rect.top + rect.height / 2;
    joyMove(e);
  }

  function joyMove(e) {
    if (!joyActive) return;
    e.preventDefault();
    const t = e.touches ? e.touches[0] : e;
    let dx = t.clientX - joyCenterX;
    let dy = t.clientY - joyCenterY;
    const dist = Math.sqrt(dx * dx + dy * dy);
    const maxR = 45;
    if (dist > maxR) {
      dx = (dx / dist) * maxR;
      dy = (dy / dist) * maxR;
    }
    joyKnob.style.transform = `translate(calc(-50% + ${dx}px), calc(-50% + ${dy}px))`;
    // 水平移动：超过死区才触发
    const deadzone = 12;
    if (Math.abs(dx) > deadzone) {
      game.touchInput.moveX = dx > 0 ? 1 : -1;
    } else {
      game.touchInput.moveX = 0;
    }
    // 垂直分量：用于手机 8 向挖掘/放置瞄准（屏幕 y 向下为正）
    if (Math.abs(dy) > deadzone) {
      game.touchInput.moveY = dy > 0 ? 1 : -1;
    } else {
      game.touchInput.moveY = 0;
    }
  }

  function joyEnd(e) {
    e.preventDefault();
    joyActive = false;
    joyBase.classList.remove('active');
    joyKnob.style.transform = 'translate(-50%, -50%)';
    game.touchInput.moveX = 0;
    game.touchInput.moveY = 0;
  }

  joyBase.addEventListener('touchstart', joyStart, { passive: false });
  joyBase.addEventListener('touchmove', joyMove, { passive: false });
  joyBase.addEventListener('touchend', joyEnd, { passive: false });
  joyBase.addEventListener('touchcancel', joyEnd, { passive: false });
  // 鼠标也支持（测试用）
  joyBase.addEventListener('mousedown', joyStart);
  window.addEventListener('mousemove', e => { if (joyActive) joyMove(e); });
  window.addEventListener('mouseup', e => { if (joyActive) joyEnd(e); });

  // ---- 跳跃按钮 ----
  const btnJump = document.getElementById('btn-jump');
  function jumpStart(e) {
    e.preventDefault();
    e.stopPropagation();
    game.touchInput.jump = true;
    btnJump.classList.add('pressed');
  }
  function jumpEnd(e) {
    e.preventDefault();
    e.stopPropagation();
    game.touchInput.jump = false;
    btnJump.classList.remove('pressed');
  }
  btnJump.addEventListener('touchstart', jumpStart, { passive: false });
  btnJump.addEventListener('touchend', jumpEnd, { passive: false });
  btnJump.addEventListener('touchcancel', jumpEnd, { passive: false });
  btnJump.addEventListener('mousedown', jumpStart);
  btnJump.addEventListener('mouseup', jumpEnd);
  btnJump.addEventListener('mouseleave', jumpEnd);

  // ---- 挖掘按钮（持续按住）----
  const btnMine = document.getElementById('btn-mine');
  function mineStart(e) {
    e.preventDefault();
    e.stopPropagation();
    game.touchInput.mine = true;
    btnMine.classList.add('pressed');
  }
  function mineEnd(e) {
    e.preventDefault();
    e.stopPropagation();
    game.touchInput.mine = false;
    btnMine.classList.remove('pressed');
  }
  btnMine.addEventListener('touchstart', mineStart, { passive: false });
  btnMine.addEventListener('touchend', mineEnd, { passive: false });
  btnMine.addEventListener('touchcancel', mineEnd, { passive: false });
  btnMine.addEventListener('mousedown', mineStart);
  btnMine.addEventListener('mouseup', mineEnd);
  btnMine.addEventListener('mouseleave', mineEnd);

  // ---- 放置按钮（单次触发）----
  const btnPlace = document.getElementById('btn-place');
  function placeTap(e) {
    e.preventDefault();
    e.stopPropagation();
    game.touchInput.place = true;
    btnPlace.classList.add('pressed');
    setTimeout(() => btnPlace.classList.remove('pressed'), 150);
  }
  btnPlace.addEventListener('touchstart', placeTap, { passive: false });
  btnPlace.addEventListener('mousedown', placeTap);
  btnPlace.addEventListener('touchcancel', e => {
    e.preventDefault();
    btnPlace.classList.remove('pressed');
  }, { passive: false });

  // ---- 甩落/丢弃按钮 ----
  const btnDrop = document.getElementById('btn-drop');
  function dropStart(e) {
    e.preventDefault();
    e.stopPropagation();
    game.touchInput.drop = true;
    btnDrop.classList.add('pressed');
  }
  function dropEnd(e) {
    e.preventDefault();
    e.stopPropagation();
    game.touchInput.drop = false;
    btnDrop.classList.remove('pressed');
  }
  btnDrop.addEventListener('touchstart', dropStart, { passive: false });
  btnDrop.addEventListener('touchend', dropEnd, { passive: false });
  btnDrop.addEventListener('touchcancel', dropEnd, { passive: false });
  btnDrop.addEventListener('mousedown', dropStart);
  btnDrop.addEventListener('mouseup', dropEnd);
  btnDrop.addEventListener('mouseleave', dropEnd);

  // ---- 静音按钮（桌面+手机通用）----
  const btnMute = document.getElementById('btn-mute');
  if (btnMute) {
    const toggleMute = e => {
      e.preventDefault();
      e.stopPropagation();
      if (!window.Sound) return;
      const muted = Sound.toggleMute();
      btnMute.textContent = muted ? '🔇' : '🔊';
      showToast(muted ? '🔇 已静音' : '🔊 音效开启', 800);
    };
    btnMute.addEventListener('touchstart', toggleMute, { passive: false });
    btnMute.addEventListener('mousedown', toggleMute);
  }

  // ---- 背包按钮 ----
  const btnInv = document.getElementById('btn-inventory');
  btnInv.addEventListener('touchstart', e => {
    e.preventDefault();
    e.stopPropagation();
    game.inventoryOpen = !game.inventoryOpen;
    if (game.inventoryOpen) game.craftingOpen = false;
    game.inventoryDirty = true;
    sfx('click');
  }, { passive: false });
  btnInv.addEventListener('click', e => {
    e.stopPropagation();
  });

  // ---- 合成按钮 ----
  const btnCraft = document.getElementById('btn-craft');
  btnCraft.addEventListener('touchstart', e => {
    e.preventDefault();
    e.stopPropagation();
    if (!game.craftingOpen) {
      game.craftingOpen = true;
      game.craftingMode = 'hand';
    } else if (game.craftingMode !== 'hand') {
      game.craftingMode = 'hand';
    } else {
      game.craftingOpen = false;
    }
    if (game.craftingOpen) game.inventoryOpen = false;
    game.craftingDirty = true;
    sfx('click');
  }, { passive: false });
  btnCraft.addEventListener('click', e => {
    e.stopPropagation();
  });

  // ---- 热栏触屏选择 ----
  game.canvas.addEventListener('touchstart', e => {
    if (!game.touchInput.isTouch) return;
    // 如果触摸在控件上则跳过
    const target = e.target;
    if (target.closest('#mobile-controls')) return;
    // 热栏区域检测
    const rect = game.canvas.getBoundingClientRect();
    const tx = e.touches[0].clientX - rect.left;
    const ty = e.touches[0].clientY - rect.top;
    const slotSize = 44, gap = 4;
    const totalW = 10 * slotSize + 9 * gap;
    const startX = (game.cw - totalW) / 2;
    const hotY = game.ch - slotSize - 20; // 触屏热栏位置
    if (ty >= hotY && ty <= hotY + slotSize) {
      const relX = tx - startX;
      if (relX >= 0 && relX < totalW) {
        const slot = Math.floor(relX / (slotSize + gap));
        if (slot >= 0 && slot <= 9 && game.hotbar[slot] > 0) {
          game.selectedSlot = slot;
          sfx('click');
          e.preventDefault();
          return;
        }
      }
    }
  }, { passive: false });
}

// ==================== 玩家更新 ====================
function updatePlayer(dt) {
  const p = game.player;
  const dts = dt / 16.67;

  // 水体检测：玩家身体是否浸入水中（用于浮力/游泳）
  let inWater = false;
  {
    const minX = Math.floor((p.x + 2) / TILE);
    const maxX = Math.floor((p.x + p.w - 2) / TILE);
    const minY = Math.floor((p.y + 6) / TILE);
    const maxY = Math.floor((p.y + p.h - 2) / TILE);
    for (let yy = minY; yy <= maxY && !inWater; yy++) {
      for (let xx = minX; xx <= maxX; xx++) {
        if (getTile(xx, yy) === 12) { inWater = true; break; }
      }
    }
  }
  p.inWater = inWater;

  // 移动
  let moveX = 0;
  if (game.keys['KeyA'] || game.keys['ArrowLeft']) moveX -= 1;
  if (game.keys['KeyD'] || game.keys['ArrowRight']) moveX += 1;
  // 手机摇杆
  if (moveX === 0 && game.touchInput.moveX !== 0) moveX = game.touchInput.moveX;

  // 移动（水中减速并带水阻）
  const sp = inWater ? PLAYER_SPEED * 0.6 : PLAYER_SPEED;
  if (moveX !== 0) {
    p.vx = moveX * sp;
    p.facing = moveX;
    p.walkPhase += dts * 0.3;
  } else {
    p.vx *= inWater ? 0.85 : 0.7;
    if (Math.abs(p.vx) < 0.1) p.vx = 0;
    p.walkPhase = 0;
  }

  // 跳跃 / 游泳（水中按住向上键持续上浮）
  const jumpPressed = game.keys['KeyW'] || game.keys['Space'] || game.keys['ArrowUp'] || game.touchInput.jump;
  if (jumpPressed) {
    if (p.onGround) {
      p.vy = -JUMP_FORCE;
      p.onGround = false;
      sfx('jump');
    } else if (inWater) {
      p.vy -= 0.9 * dts;
      if (p.vy < -4.5) p.vy = -4.5;
      if (Math.random() < 0.12) sfx('splash', { pan: audioPan(p.x + p.w / 2) });
    }
  }

  // 物理
  moveEntity(p, dt);

  // 掉落伤害
  if (p.vy === 0 && !p.onGround) {
    // 检查是否是落地
  }
  if (p.invuln > 0) p.invuln -= dt;

  // 血量自动回复：受伤4秒后开始，每800ms回复2HP
  if (p.health < p.maxHealth && p.invuln <= 0) {
    const timeSinceDamage = performance.now() - (p.lastDamageTime || 0);
    if (timeSinceDamage > 4000) {
      game.regenAccum += dt;
      if (game.regenAccum >= 800) {
        game.regenAccum = 0;
        p.health = Math.min(p.maxHealth, p.health + 2);
        if (Math.random() < 0.4) {
          spawnParticles(p.x + p.w / 2, p.y + 4, '#22ff44', 2);
        }
      }
    }
  }

  // 岩浆伤害：接触岩浆(63)持续扣血（带无敌冷却）
  if (p.invuln <= 0) {
    const lcx = Math.floor((p.x + p.w / 2) / TILE);
    const lcy = Math.floor((p.y + p.h / 2) / TILE);
    let onLava = getTile(lcx, lcy) === 63;
    if (!onLava) {
      const lfy = Math.floor((p.y + p.h - 1) / TILE);
      onLava = getTile(lcx, lfy) === 63;
    }
    if (onLava) {
      p.health -= 6;
      p.lastDamageTime = performance.now();
      p.invuln = 600;
      sfx('hurt');
    }
  }

  // 死亡
  if (p.health <= 0) {
    respawn();
  }

  // 玩家所在方块坐标（提前计算，供下方触屏挖掘/放置使用，避免 TDZ 引用错误）
  const px = Math.floor((p.x + p.w / 2) / TILE);
  const py = Math.floor((p.y + p.h / 2) / TILE);

  // 挖掘/放置/对战
  // 手机触屏挖掘：优先用玩家在画布上点选的方块（自主选择），否则回退摇杆 8 向瞄准
  if (game.touchInput.isTouch && game.touchInput.mine && !game.battleOpen) {
    const aim = getMobileTargetTile(px, py);
    game.mouse.worldX = aim.tx * TILE + TILE / 2;
    game.mouse.worldY = aim.ty * TILE + TILE / 2;
    game.mouse.left = true;
  } else if (game.touchInput.isTouch && !game.touchInput.mine) {
    // 挖掘按钮松开时清除
    game.mouse.left = false;
  }
  // 手机触屏放置：优先用玩家点选的方块（单次触发），否则回退摇杆 8 向瞄准
  if (game.touchInput.isTouch && game.touchInput.place && !game.battleOpen) {
    const aim = getMobileTargetTile(px, py);
    game.mouse.worldX = aim.tx * TILE + TILE / 2;
    game.mouse.worldY = aim.ty * TILE + TILE / 2;
    game.mouse.right = true;
    game.touchInput.place = false; // 单次触发后清除
  }
  // 手机触屏甩落（单次触发）：丢出当前手持物品
  if (game.touchInput.isTouch && game.touchInput.drop && !game.battleOpen) {
    dropSelected();
    game.touchInput.drop = false;
  }

  const tx = Math.floor(game.mouse.worldX / TILE);
  const ty = Math.floor(game.mouse.worldY / TILE);
  const dist = Math.abs(tx - px) + Math.abs(ty - py);

  if (game.battleCooldown > 0) game.battleCooldown -= dt;

  // 点击敌人 → 开启卡牌对战（优先于挖掘）
  let clickedEnemy = false;
  const tapActive = game.mouse.left || (game.touchInput.isTouch && game.touchInput.tap);
  if (tapActive && !game.battleOpen && game.battleCooldown <= 0) {
    for (const en of game.enemies) {
      const ex = en.x + en.w / 2;
      const ey = en.y + en.h / 2;
      if (Math.abs(game.mouse.worldX - ex) < en.w &&
          Math.abs(game.mouse.worldY - ey) < en.h && dist <= REACH) {
        openBattle(en);
        game.mouse.left = false;
        game.touchInput.tap = false;
        clickedEnemy = true;
        break;
      }
    }
  }

  // 挖掘（未点中敌人时）
  // 触屏设备：挖掘只通过按钮触发
  const mineActive = game.touchInput.isTouch ? (game.touchInput.mine && game.mouse.left) : game.mouse.left;
  if (!clickedEnemy && mineActive && dist <= REACH && !game.battleOpen) {
    handleMining(tx, ty, dt);
  } else if (!game.battleOpen && !mineActive) {
    game.mining.target = null;
    game.mining.progress = 0;
  }

  // 触屏点击工作站打开UI
  if (game.touchInput.isTouch && game.touchInput.tap && !clickedEnemy && !game.battleOpen) {
    if (tryBucketAction(tx, ty)) { game.touchInput.tap = false; return; } // 桶舀取/倒出优先
    const tapTile = getTile(tx, ty);
    if (tapTile === 17 && dist <= REACH) {
      game.craftingOpen = true;
      game.craftingMode = 'workbench';
      game.craftingDirty = true;
      game.inventoryOpen = false;
      game.touchInput.tap = false;
      sfx('click');
    } else if (tapTile === 18 && dist <= REACH) {
      game.craftingOpen = true;
      game.craftingMode = 'furnace';
      game.craftingDirty = true;
      game.inventoryOpen = false;
      game.touchInput.tap = false;
      sfx('click');
    } else if (tapTile === 59 && dist <= REACH) {
      // 床：点按睡过夜晚
      sleepInBed();
      game.touchInput.tap = false;
    } else if (tapTile === 26 && dist <= REACH) {
      // 木门：点按开关（开着的门可穿过）
      toggleDoor(tx, ty);
      game.touchInput.tap = false;
    }
  }

  // 触屏点击为一次性行为：本帧处理后无论是否命中，都清除 tap，
  // 防止 tap 卡住导致每帧重复触发对战/合成界面（造成“假死机”）
  if (game.touchInput.isTouch) game.touchInput.tap = false;

  // 右键：打开工作站UI 或 放置方块
  if (game.mouse.right && !game.battleOpen) {
    if (tryBucketAction(tx, ty)) { game.mouse.right = false; return; }
    const targetTile = getTile(tx, ty);
    if (targetTile === 17 && dist <= REACH) {
      game.craftingOpen = true;
      game.craftingMode = 'workbench';
      game.craftingDirty = true;
      game.inventoryOpen = false;
      game.mouse.right = false;
      sfx('click');
    } else if (targetTile === 18 && dist <= REACH) {
      game.craftingOpen = true;
      game.craftingMode = 'furnace';
      game.craftingDirty = true;
      game.inventoryOpen = false;
      game.mouse.right = false;
      sfx('click');
    } else if (targetTile === 59 && dist <= REACH) {
      // 床：右键睡过夜晚
      sleepInBed();
      game.mouse.right = false;
    } else if (targetTile === 26 && dist <= REACH) {
      // 木门：右键开关（开着的门可穿过）
      toggleDoor(tx, ty);
      game.mouse.right = false;
    } else if (dist <= REACH && dist > 0) {
      handlePlacing(tx, ty);
      game.mouse.right = false;
    }
    // 触屏放置兜底清除
    if (game.touchInput.isTouch) game.mouse.right = false;
  }
}

// 挖掘逻辑：按硬度与工具需求推进进度，完成后掉落对应物品并清空方块
function handleMining(tx, ty, dt) {
  const tileId = getTile(tx, ty);
  if (tileId === 0) return;
  const block = BLOCKS[tileId];
  if (!block || block.hardness === 0) return;

  // 工具需求检查
  const requiredTier = block.tool || 0;
  const equippedToolId = game.hotbar[game.selectedSlot];
  const equippedTool = equippedToolId > 0 ? BLOCKS[equippedToolId] : null;
  const toolTier = (equippedTool && equippedTool.toolTier) ? equippedTool.toolTier : 0;

  if (requiredTier > 0 && toolTier < requiredTier) {
    const toolNames = ['', '木镐', '石镐', '铁镐'];
    if (!game.mining.toolWarnTimer || performance.now() - game.mining.toolWarnTimer > 1500) {
      showToast(`需要${toolNames[requiredTier]}或更好的工具！`, 1500);
      game.mining.toolWarnTimer = performance.now();
    }
    game.mining.target = null;
    game.mining.progress = 0;
    return;
  }

  // 工具加速：有工具时挖掘更快
  const speedMul = toolTier > 0 ? 1 + toolTier * 0.4 : 1;

  const targetKey = tx + ',' + ty;
  if (game.mining.target !== targetKey) {
    game.mining.target = targetKey;
    game.mining.progress = 0;
    game.mining.x = tx;
    game.mining.y = ty;
  }

  game.mining.progress += dt * speedMul;
  // 粒子
  if (Math.random() < 0.3) {
    spawnParticles(tx * TILE + TILE / 2, ty * TILE + TILE / 2, block.shade || block.color, 2);
  }
  // 挖掘中反馈音（按进度步进，避免刷屏）
  if (!game.mining._tick || game.mining.progress - game.mining._tick >= 0.25) {
    game.mining._tick = game.mining.progress;
    sfx('dig', { pan: audioPan(tx * TILE + TILE / 2) });
  }

  if (game.mining.progress >= block.hardness * 8) {
    // 挖掘完成
    const dropId = block.drop || tileId;
    addItem(dropId, 1);
    setTile(tx, ty, 0);
    syncBlockChange(tx, ty, 0);
    // 木门占 2 格：挖掉任意一半时，连带另一半一并移除（不再掉落，整扇门仍回收为 1 个门物品）；
    // 同时清掉开门状态集合，避免残留“开启”索引
    if (tileId === 26) {
      for (const d of [0, -1, 1]) {
        const ny = ty + d;
        if (getTile(tx, ny) === 26) {
          setTile(tx, ny, 0);
          syncBlockChange(tx, ny, 0);
          game.openDoors.delete(ny * WORLD_W + tx);
        }
      }
    }
    spawnParticles(tx * TILE + TILE / 2, ty * TILE + TILE / 2, block.color, 12);
    sfx('break', { tile: tileId, pan: audioPan(tx * TILE + TILE / 2) });
    game.mining.target = null;
    game.mining.progress = 0;

    // 元素发现检测
    const elementSymbol = ORE_ELEMENT_MAP[tileId];
    if (elementSymbol && !game.discoveredElements.has(elementSymbol)) {
      game.discoveredElements.add(elementSymbol);
      showElementDiscovery(elementSymbol);
    }

  }
}

function handlePlacing(tx, ty) {
  // 桶类物品不能当成方块放置（舀/倒由 tryBucketAction 处理）
  const holdBlk = BLOCKS[game.hotbar[game.selectedSlot]];
  if (holdBlk && holdBlk.placeable === false) {
    showToast('桶请右键使用：舀水或岩浆 / 倒在空处', 900);
    return;
  }
  // 目标位置必须是空气
  if (getTile(tx, ty) !== 0) return;

  // （已支持在空中放置：不再要求相邻有固体方块，玩家朝向 5 格内任意空气处均可放）

  // 不能放在玩家身上
  const p = game.player;
  const pTx = Math.floor(p.x / TILE);
  const pTy = Math.floor(p.y / TILE);
  const pTx2 = Math.floor((p.x + p.w - 1) / TILE);
  const pTy2 = Math.floor((p.y + p.h - 1) / TILE);
  if (tx >= pTx && tx <= pTx2 && ty >= pTy && ty <= pTy2) {
    if (BLOCKS[game.hotbar[game.selectedSlot]] && BLOCKS[game.hotbar[game.selectedSlot]].solid) return;
  }

  const slot = game.selectedSlot;
  const blockId = game.hotbar[slot];
  if (blockId === 0 || game.hotbarCounts[slot] <= 0) return;

  // 工具（拾取类，非方块）不能放置：只有真正带 toolTier 的道具（木镐/石镐/铁镐）才算工具。
  // 注意：矿物/石头用 block.tool 表示「需要的挖掘等级」，并非工具，可被正常放置。
  const placeBlock = BLOCKS[blockId];
  if (placeBlock && placeBlock.toolTier) {
    showToast('工具不能放置，请选择方块', 800);
    return;
  }

  // 木门：占上下 2 格（下半=点击处，上半=正上方一格）。需上方为空且不压住玩家。
  if (blockId === 26) {
    const topY = ty - 1;
    if (topY < 0 || getTile(tx, topY) !== 0 ||
        (tx >= pTx && tx <= pTx2 && topY >= pTy && topY <= pTy2)) {
      showToast('门需要上下 2 格空间，且不能压住自己', 1200);
      return;
    }
    setTile(tx, ty, 26);
    syncBlockChange(tx, ty, 26);
    setTile(tx, topY, 26);
    syncBlockChange(tx, topY, 26);
    removeItem(26, 1);
    sfx('place', { pan: audioPan(tx * TILE + TILE / 2) });
    return;
  }

  setTile(tx, ty, blockId);
  syncBlockChange(tx, ty, blockId);
  removeItem(blockId, 1);
  sfx(blockId === 15 ? 'torch' : 'place', { pan: audioPan(tx * TILE + TILE / 2) });
}

// 桶逻辑：空桶可舀水(12)/岩浆(63)，装满的桶可在空邻格倒出对应液体
function tryBucketAction(tx, ty) {
  const held = game.hotbar[game.selectedSlot];
  if (!BLOCKS[held] || !BLOCKS[held].isBucket) return false; // 只有手持桶才处理
  const LAVA = 63;
  const tile = getTile(tx, ty);

  // 空桶 → 舀取
  if (held === 60) {
    if (tile === 12) {                          // 水
      setTile(tx, ty, 0);
      syncBlockChange(tx, ty, 0);
      removeItem(60, 1); addItem(61, 1);
      sfx('splash', { pan: audioPan(tx * TILE + TILE / 2) });
      return true;
    } else if (tile === LAVA) {                 // 岩浆
      setTile(tx, ty, 0);
      syncBlockChange(tx, ty, 0);
      removeItem(60, 1); addItem(62, 1);
      sfx('lava', { pan: audioPan(tx * TILE + TILE / 2) });
      return true;
    }
    return false; // 空桶对着非液体不做任何事
  }

  // 装桶 → 倒出（目标须为空且旁边有支撑）
  if (tile !== 0) return false;
  const hasNeighbor = isSolid(tx - 1, ty) || isSolid(tx + 1, ty) ||
                      isSolid(tx, ty - 1) || isSolid(tx, ty + 1);
  if (!hasNeighbor) return false;
  if (held === 61) {                            // 水桶 → 倒水
    setTile(tx, ty, 12);
    syncBlockChange(tx, ty, 12);
    removeItem(61, 1); addItem(60, 1);
    sfx('splash', { pan: audioPan(tx * TILE + TILE / 2) });
    return true;
  }
  if (held === 62) {                            // 岩浆桶 → 倒岩浆
    setTile(tx, ty, LAVA);
    syncBlockChange(tx, ty, LAVA);
    removeItem(62, 1); addItem(60, 1);
    sfx('lava', { pan: audioPan(tx * TILE + TILE / 2) });
    return true;
  }
  return false;
}

// 手机 8 向瞄准：根据虚拟摇杆方向（moveX, moveY）量化成 8 个方向之一。
// 摇杆居中时回退到面朝方向（保持旧习惯）。屏幕 y 向下为正，故“上”对应 dy=-1。
function getTouchAimDir() {
  const ti = game.touchInput;
  const dx = ti.moveX, dy = ti.moveY;
  if (Math.abs(dx) < 0.3 && Math.abs(dy) < 0.3) {
    return { dx: game.player.facing || 1, dy: 0 };
  }
  // 8 个方向（顺时针，从“右”开始）
  const dirs = [
    { dx: 1, dy: 0 }, { dx: 1, dy: 1 }, { dx: 0, dy: 1 }, { dx: -1, dy: 1 },
    { dx: -1, dy: 0 }, { dx: -1, dy: -1 }, { dx: 0, dy: -1 }, { dx: 1, dy: -1 },
  ];
  const ang = Math.atan2(dy, dx);               // -π..π
  const oct = Math.round(ang / (Math.PI / 4));  // 0..7（接近边界四舍五入到最近方向）
  return dirs[((oct % 8) + 8) % 8];
}

// 手机挖掘/放置目标格：优先玩家在画布上点选的方块（自主选择），
// 若未点选或点选方块超出触及范围(REACH)，则回退到摇杆 8 向瞄准（相邻格）。
function getMobileTargetTile(px, py) {
  const ti = game.touchInput;
  if (ti.aimActive) {
    const atx = Math.floor(ti.aimX / TILE);
    const aty = Math.floor(ti.aimY / TILE);
    const adist = Math.abs(atx - px) + Math.abs(aty - py);
    if (adist <= REACH) return { tx: atx, ty: aty };
  }
  const aim = getTouchAimDir();
  return { tx: px + aim.dx, ty: py + aim.dy };
}

// ==================== 敌人系统 ====================
// 怪物数量上限：避免刷怪过多影响性能与体验
const ENEMY_MAX_TOTAL = 10;     // 同一时刻最多存活怪物总数
const ENEMY_MAX_SURFACE = 4;    // 地表（夜晚）上限
const ENEMY_MAX_UNDERGROUND = 7; // 地下/黑暗环境上限

function updateEnemies(dt) {
  const dts = dt / 16.67;
  const p = game.player;
  const pTy = Math.floor((p.y + p.h / 2) / TILE);
  const surfP = game.surface[Math.floor(p.x / TILE)] || WORLD_H * 0.35;

  // 夜晚（地表）生成敌人
  if (game.time > 0.5 && game.time < 0.95 &&
      game.enemies.length < ENEMY_MAX_SURFACE && game.enemies.length < ENEMY_MAX_TOTAL &&
      Math.random() < 0.004) {
    spawnEnemy(false);
  }

  // 地下/黑暗环境生成敌人：玩家身处地下且周围无光源时，按概率在黑暗中刷出
  if (game.enemies.length < ENEMY_MAX_UNDERGROUND && game.enemies.length < ENEMY_MAX_TOTAL &&
      pTy > surfP + 3 &&
      !hasNearbyLight(Math.floor(p.x / TILE), pTy, 6) && Math.random() < 0.008) {
    spawnEnemy(true);
  }

  for (let i = game.enemies.length - 1; i >= 0; i--) {
    const e = game.enemies[i];

    // AI：朝玩家移动
    const p = game.player;
    const dx = p.x - e.x;
    const dist = Math.abs(dx);

    if (dist < 200 && dist > 20) {
      e.vx = (dx > 0 ? 1 : -1) * 1.5;
    } else {
      e.vx *= 0.9;
    }

    // 跳跃（如果在地面碰到障碍）
    if (e.onGround && Math.abs(e.vx) > 0.5 && isSolid(
      Math.floor((e.x + (e.vx > 0 ? e.w + 2 : -2)) / TILE),
      Math.floor((e.y + e.h - 2) / TILE)
    )) {
      e.vy = -7;
    }

    // 物理
    moveEntity(e, dt);

    // 实体碰撞：与玩家接触（AABB 严格重叠判定）
    if (p.x < e.x + e.w && p.x + p.w > e.x && p.y < e.y + e.h && p.y + p.h > e.y) {
      if (p.invuln <= 0) {
        // 接触伤害 + 击退
        p.health -= 8;
        p.invuln = 800;
        p.lastDamageTime = performance.now();
        p.vx = (p.x < e.x ? -5 : 5);
        p.vy = -6;
        sfx('hurt');
      } else {
        // 无敌期间：把玩家推出怪物身体，避免直接穿过
        pushOutOf(p, e);
      }
    }

    // 删除死亡/掉出世界
    if (e.health <= 0 || e.y > WORLD_H * TILE) {
      game.enemies.splice(i, 1);
    }

    e.animPhase = (e.animPhase || 0) + dts * 0.15;
  }

  // 怪物之间互相碰撞：优先在 x 方向散开，避免堆叠在同一点 / 同一 x 列
  for (let i = 0; i < game.enemies.length; i++) {
    for (let j = i + 1; j < game.enemies.length; j++) {
      resolveOverlapAABB(game.enemies[i], game.enemies[j]);
    }
  }

  // 白天清除地表敌人（地下怪物身处黑暗，保留不被清除）
  if (game.time < 0.05 || game.time > 0.95) {
    for (let i = game.enemies.length - 1; i >= 0; i--) {
      const e = game.enemies[i];
      const eTy = Math.floor((e.y + e.h / 2) / TILE);
      const eSurf = game.surface[Math.floor(e.x / TILE)] || WORLD_H * 0.35;
      if (eTy <= eSurf + 2 && Math.random() < 0.02) game.enemies.splice(i, 1);
    }
  }
}

// 找一个与现有怪物不同 x（不同 tile 列）的空地，避免刷怪重叠 / 同列堆叠
function findFreeEnemyTileX(baseTx, side) {
  const occupied = new Set(game.enemies.map(e => Math.floor(e.x / TILE)));
  if (!occupied.has(baseTx)) return baseTx;
  for (let d = 1; d < 40; d++) {
    const c1 = baseTx + side * d;
    if (c1 >= 2 && c1 <= WORLD_W - 3 && !occupied.has(c1)) return c1;
    const c2 = baseTx - side * d;
    if (c2 >= 2 && c2 <= WORLD_W - 3 && !occupied.has(c2)) return c2;
  }
  return baseTx;
}

function spawnEnemy(underground) {
  const p = game.player;
  // 在玩家附近但屏幕外生成
  const side = Math.random() < 0.5 ? -1 : 1;
  const dist = (game.cw / TILE / 2 + 3) * TILE;
  let x = p.x + side * dist;
  let tx = Math.max(2, Math.min(WORLD_W - 3, Math.floor(x / TILE)));
  tx = findFreeEnemyTileX(tx, side); // 避免与现有怪物落在同一 x 列
  x = tx * TILE;

  let ty;
  if (underground) {
    // 在玩家所在深度附近寻找可站立（本格空、下方为实地）的非实心格
    const pTy = Math.floor((p.y + p.h / 2) / TILE);
    let placed = -1;
    for (let d = 0; d <= 14 && placed < 0; d++) {
      const candidates = d === 0 ? [pTy] : [pTy - d, pTy + d];
      for (const s of candidates) {
        if (s < 1 || s >= WORLD_H - 1) continue;
        if (!isSolid(tx, s) && isSolid(tx, s + 1)) { placed = s; break; }
      }
    }
    ty = placed >= 0 ? placed : pTy;
  } else {
    // 地表：找到地表后落在上方
    ty = 0;
    for (let yy = 0; yy < WORLD_H; yy++) {
      if (isSolid(tx, yy)) { ty = yy - 2; break; }
    }
  }

  game.enemies.push({
    x: x,
    y: underground ? (ty + 1) * TILE - 24 : ty * TILE,
    vx: 0, vy: 0,
    w: 24, h: 24,
    onGround: false,
    health: 30, maxHealth: 30,
    animPhase: 0,
    type: 'slime',
    underground: !!underground,
  });
}

// ==================== 掉落物系统 ====================
function updateDroppedItems(dt) {
  const dts = dt / 16.67;
  const p = game.player;

  for (let i = game.droppedItems.length - 1; i >= 0; i--) {
    const item = game.droppedItems[i];
    if (!item.vx) item.vx = 0; // 兼容未设 vx 的掉落物（如敌人掉落），避免坐标变 NaN
    item.age = (item.age || 0) + dt; // 已存活时间（ms），用于拾取前的短暂保护
    item.vy += GRAVITY * dts;
    const maxFall = (typeof item.maxFall === 'number') ? item.maxFall : MAX_FALL;
    if (item.vy > maxFall) item.vy = maxFall;
    item.y += item.vy * dts;
    item.x += item.vx * dts;
    item.vx *= 0.9;

    // 碰撞
    const tx = Math.floor(item.x / TILE);
    const ty = Math.floor((item.y + 8) / TILE);
    if (isSolid(tx, ty)) {
      item.y = ty * TILE - 8;
      item.vy = 0;
    }

    // 硫磺弹：倒计时引爆
    if (item.isBomb) {
      item.fuse -= dt;
      if (item.fuse <= 0) {
        explode(item.x, item.y, 3);
        game.droppedItems.splice(i, 1);
        continue;
      }
    }

    item.life -= dt;

    // 拾取（noPickup 的掉落物仅作视觉展示，不进背包，例如飘落的树叶）
    if (!item.noPickup) {
      const dx = (p.x + p.w / 2) - (item.x + 4);
      const dy = (p.y + p.h / 2) - (item.y + 4);
      if (Math.abs(dx) < 24 && Math.abs(dy) < 24 && item.age > 50) {
        addItem(item.id, item.count);
        game.droppedItems.splice(i, 1);
        sfx('pickup');
        continue;
      }
    }

    if (item.life <= 0) game.droppedItems.splice(i, 1);
  }
}

// ==================== 粒子系统 ====================
function spawnParticles(x, y, color, count) {
  for (let i = 0; i < count; i++) {
    game.particles.push({
      x, y,
      vx: (Math.random() - 0.5) * 6,
      vy: (Math.random() - 0.5) * 6 - 2,
      life: 0.5 + Math.random() * 0.5,
      maxLife: 0.5 + Math.random() * 0.5,
      size: 2 + Math.random() * 4,
      color,
      gravity: 0.3,
    });
  }
}

function updateParticles(dt) {
  const dts = dt / 16.67;
  for (let i = game.particles.length - 1; i >= 0; i--) {
    const p = game.particles[i];
    p.vy += p.gravity * dts;
    p.x += p.vx * dts;
    p.y += p.vy * dts;
    p.vx *= 0.96;
    p.life -= dt / 1000;
    if (p.life <= 0) game.particles.splice(i, 1);
  }
}

// ==================== 主更新循环 ====================
// 流体模拟：基于元胞自动机的水位扩散（向下流 + 横向铺开），水位范围 0~4
function updateWater() {
  const W = WORLD_W, H = WORLD_H;
  const lvl = game.waterLevels;
  const world = game.world;
  const buf = game._waterBuf || (game._waterBuf = new Int8Array(W * H));
  buf.fill(0);
  for (let y = 0; y < H; y++) {
    for (let x = 0; x < W; x++) {
      const i = y * W + x;
      const c = lvl[i];
      if (c <= 0) continue;
      let rem = c; // 流出预算，确保本格不会给出超过自身水量（避免凭空生水）
      // 向下流：落入空气整格下移；与下方水均衡
      if (y + 1 < H) {
        const d = i + W;
        const dl = lvl[d];
        if (dl === 0 && world[d] === 0) {
          const f = Math.min(rem, c);
          buf[i] -= f; buf[d] += f; rem -= f;
        } else if (dl > 0 && dl < 4) {
          const f = Math.min(rem, Math.ceil((c - dl) / 2));
          if (f > 0) { buf[i] -= f; buf[d] += f; rem -= f; }
        }
      }
      // 向两侧流（仅当水深>=2 且仍有余量，避免薄层无限扩散）
      if (rem > 0 && c >= 2) {
        const give = c >= 3 ? 2 : 1;
        for (const nx of (x > 0 ? [x - 1] : []).concat(x < W - 1 ? [x + 1] : [])) {
          const n = y * W + nx;
          const nl = lvl[n];
          if ((nl === 0 && world[n] === 0) || (nl > 0 && nl < 4)) {
            if (nl < c) {
              const f = Math.min(rem, give);
              if (f > 0) { buf[i] -= f; buf[n] += f; rem -= f; }
            }
          }
        }
      }
    }
  }
  for (let i = 0; i < W * H; i++) {
    if (buf[i] === 0) continue;
    let v = lvl[i] + buf[i];
    if (v < 0) v = 0; else if (v > 4) v = 4;
    lvl[i] = v;
    world[i] = v > 0 ? 12 : 0;
  }
}

// 岩浆流体模拟（与 updateWater 同源的元胞自动机，但更粘稠，且遇水生成黑曜石）
// 与水同步在每 ~90ms 调用一次；粘稠体现在：每 tick 仅下移/外溢 1 级，且侧流仅在满级(c===4)时触发
function updateLava() {
  const W = WORLD_W, H = WORLD_H;
  const lvl = game.lavaLevels;
  const world = game.world;
  const buf = game._lavaBuf || (game._lavaBuf = new Int8Array(W * H));
  buf.fill(0);
  for (let y = 0; y < H; y++) {
    for (let x = 0; x < W; x++) {
      const i = y * W + x;
      const c = lvl[i];
      if (c <= 0) continue;
      let rem = c; // 流出预算（避免凭空生岩浆）
      // 向下流
      let blockedBelow = true;
      if (y + 1 < H) {
        const d = i + W;
        const dw = world[d];
        if (dw === 12) {
          // 岩浆落入水中 → 生成黑曜石（消耗本格岩浆，互不污染 level 数组）
          world[d] = 25;
          game.lavaLevels[d] = 0;
          game.waterLevels[d] = 0;
          buf[i] -= c; rem = 0; blockedBelow = false;
        } else if (dw === 0) {
          const f = Math.min(rem, 1); // 粘稠：每 tick 只下移 1 级
          if (f > 0) { buf[i] -= f; buf[d] += f; rem -= f; }
          blockedBelow = false;
        } else if (lvl[d] > 0 && lvl[d] < 4) {
          const f = Math.min(rem, 1);
          if (f > 0 && lvl[d] < c) { buf[i] -= f; buf[d] += f; rem -= f; }
          blockedBelow = false;
        }
      }
      // 向两侧流：仅当下方被挡住(形成水洼)、且本格已满级(c===4)时，外溢 1 级（更粘稠，避免下落时乱窜）
      if (rem > 0 && c === 4 && blockedBelow) {
        for (const nx of (x > 0 ? [x - 1] : []).concat(x < W - 1 ? [x + 1] : [])) {
          const n = y * W + nx;
          const nw = world[n];
          if (nw === 12) {
            // 侧触水 → 黑曜石
            world[n] = 25;
            game.waterLevels[n] = 0;
            game.lavaLevels[n] = 0;
            continue;
          }
          const nl = lvl[n];
          if (nw === 0 && nl === 0) {
            const f = 1;
            buf[i] -= f; buf[n] += f; rem -= f;
          } else if (nl > 0 && nl < 4) {
            const f = 1;
            if (nl < c) { buf[i] -= f; buf[n] += f; rem -= f; }
          }
        }
      }
    }
  }
  for (let i = 0; i < W * H; i++) {
    if (buf[i] === 0) continue;
    let v = lvl[i] + buf[i];
    if (v < 0) v = 0; else if (v > 4) v = 4;
    lvl[i] = v;
    // 只动岩浆格本身（保留黑曜石/水等其它方块不被误清）
    if (v > 0) world[i] = 63;
    else if (world[i] === 63) world[i] = 0;
  }
}

function update(dt) {
  // 昼夜
  game.time += dt / 1000 / game.dayLength;
  if (game.time >= 1) game.time = 0;

  // 昼夜切换音效（白天<->夜晚）
  const ph = game.time < 0.5 ? 0 : 1;
  if (game._phase === undefined) game._phase = ph;
  else if (ph !== game._phase) {
    game._phase = ph;
    if (window.Sound) Sound.play(ph ? 'night' : 'day');
  }

  // 音频系统每帧推进（环境/动态音乐，随昼夜变化）
  if (window.Sound) Sound.update(dt, game.time);

  updatePlayer(dt);
  updateRemotePlayers(dt);
  updateEnemies(dt);
  updateDroppedItems(dt);
  updateParticles(dt);

  // 流体（水 + 岩浆）模拟：节流到约每 90ms 一次，水与岩浆同步更新
  game._waterAcc = (game._waterAcc || 0) + dt;
  if (game._waterAcc >= 90) {
    game._waterAcc = 0;
    updateWater();
    updateLava();
  }

  // 摄像机跟随
  const targetCamX = game.player.x + game.player.w / 2 - game.cw / 2;
  const targetCamY = game.player.y + game.player.h / 2 - game.ch / 2;
  game.camX += (targetCamX - game.camX) * 0.1;
  game.camY += (targetCamY - game.camY) * 0.1;
  game.camX = Math.max(0, Math.min(WORLD_W * TILE - game.cw, game.camX));
  game.camY = Math.max(0, Math.min(WORLD_H * TILE - game.ch, game.camY));

  // 更新鼠标世界坐标
  game.mouse.worldX = game.camX + game.mouse.x;
  game.mouse.worldY = game.camY + game.mouse.y;

  // 更新UI
  updateUI();

  // 联机：发送位置（节流约14次/秒）
  if (game.multiplayer.connected && game.multiplayer.myId !== null) {
    game.multiplayer.sendAccum += dt;
    if (game.multiplayer.sendAccum >= 70) {
      game.multiplayer.sendAccum = 0;
      const p = game.player;
      const mp = game.multiplayer;
      if (mp.ws && mp.ws.readyState === 1) {
        mp.ws.send(JSON.stringify({
          type: 'move',
          x: p.x, y: p.y, vx: p.vx, vy: p.vy,
          facing: p.facing, walkPhase: p.walkPhase, health: p.health,
        }));
      }
    }
  }
}

function findSafeSpawnColumn() {
  const cx = WORLD_W >> 1;
  const isSafe = (tx) => {
    if (tx < 2 || tx > WORLD_W - 3) return false;
    const sy = game.surface[tx];
    if (sy == null || sy < 2 || sy >= WORLD_H - 3) return false;
    const top = game.world[sy * WORLD_W + tx];
    if (top === 12 || top === 63) return false;          // 地表本身不能是水/岩浆
    for (let d = 1; d <= 2; d++) {                        // 头顶 2 格须为空气（玩家站立/下落区）
      const t = game.world[(sy - d) * WORLD_W + tx];
      if (t !== 0) return false;
    }
    return true;
  };
  if (isSafe(cx)) return cx;
  for (let d = 1; d < WORLD_W / 2; d++) {
    if (isSafe(cx + d)) return cx + d;
    if (isSafe(cx - d)) return cx - d;
  }
  return cx; // 兜底：极端情况下仍用中央列
}

function respawn() {
  const p = game.player;
  const spawnTx = findSafeSpawnColumn();
  p.x = spawnTx * TILE;
  p.y = (game.surface[spawnTx] - 2) * TILE - p.h;
  p.vx = 0; p.vy = 0;
  p.health = p.maxHealth;
  p.invuln = 2000;
  game.enemies = [];
  showToast('重生中...', 2000);
}

// ==================== 渲染系统 ====================
function render() {
  const ctx = game.ctx;

  // 天空
  drawSky(ctx);

  // 地图
  drawTiles(ctx);

  // 掉落物
  drawDroppedItems(ctx);

  // 敌人
  drawEnemies(ctx);

  // 其他联机玩家
  drawOtherPlayers(ctx);

  // 玩家
  drawPlayer(ctx);

  // 粒子
  drawParticles(ctx);

  // 光照
  drawLighting(ctx);

  // 挖掘进度
  drawMiningProgress(ctx);

  // 鼠标指示
  drawMouseTarget(ctx);

  // UI
  drawUI(ctx);
}

function drawSky(ctx) {
  // 昼夜颜色
  const t = game.time;
  let r, g, b;
  if (t < 0.1) { // 黎明
    const k = t / 0.1;
    r = lerp(20, 100, k); g = lerp(20, 160, k); b = lerp(60, 220, k);
  } else if (t < 0.4) { // 白天
    r = 100; g = 160; b = 220;
  } else if (t < 0.5) { // 黄昏
    const k = (t - 0.4) / 0.1;
    r = lerp(100, 200, k); g = lerp(160, 100, k); b = lerp(220, 60, k);
  } else if (t < 0.6) { // 暮色
    const k = (t - 0.5) / 0.1;
    r = lerp(200, 20, k); g = lerp(100, 20, k); b = lerp(60, 60, k);
  } else { // 夜晚
    r = 15; g = 15; b = 40;
  }

  ctx.fillStyle = `rgb(${r|0},${g|0},${b|0})`;
  ctx.fillRect(0, 0, game.cw, game.ch);

  // 太阳/月亮
  const sunX = game.cw * (t * 2 - 0.5);
  const sunY = game.ch * 0.15 + Math.sin(t * Math.PI) * -30;
  if (t < 0.5) {
    ctx.fillStyle = `rgba(255,240,100,0.8)`;
    ctx.beginPath();
    ctx.arc(sunX, Math.max(20, sunY), 25, 0, Math.PI * 2);
    ctx.fill();
  } else {
    const moonX = game.cw * ((t - 0.5) * 2 - 0.5);
    ctx.fillStyle = `rgba(200,200,220,0.8)`;
    ctx.beginPath();
    ctx.arc(moonX, Math.max(20, sunY), 18, 0, Math.PI * 2);
    ctx.fill();
  }

  // 星星（夜晚）
  if (t > 0.55) {
    const starAlpha = Math.min(1, (t - 0.55) / 0.1);
    ctx.fillStyle = `rgba(255,255,255,${starAlpha * 0.6})`;
    for (let i = 0; i < 50; i++) {
      const sx = (i * 73 + 13) % game.cw;
      const sy = (i * 37 + 7) % (game.ch * 0.5);
      ctx.fillRect(sx, sy, 1.5, 1.5);
    }
  }
}

function drawTiles(ctx) {
  const startTx = Math.max(0, Math.floor(game.camX / TILE));
  const endTx = Math.min(WORLD_W - 1, Math.ceil((game.camX + game.cw) / TILE));
  const startTy = Math.max(0, Math.floor(game.camY / TILE));
  const endTy = Math.min(WORLD_H - 1, Math.ceil((game.camY + game.ch) / TILE));

  for (let ty = startTy; ty <= endTy; ty++) {
    for (let tx = startTx; tx <= endTx; tx++) {
      const id = getTile(tx, ty);
      if (id === 0) continue;

      const block = BLOCKS[id];
      const sx = Math.floor(tx * TILE - game.camX);
      const sy = Math.floor(ty * TILE - game.camY);

      // 主色
      ctx.fillStyle = block.color;
      ctx.fillRect(sx, sy, TILE, TILE);

      // 纹理变化
      const shade = getBlockShade(id, tx, ty);
      if (shade && shade.variation !== 0) {
        const v = shade.variation;
        if (v > 0) {
          ctx.fillStyle = `rgba(255,255,255,${Math.abs(v)})`;
        } else {
          ctx.fillStyle = `rgba(0,0,0,${Math.abs(v)})`;
        }
        ctx.fillRect(sx, sy, TILE, TILE);
      }

      // 矿石高光（特殊方块）
      if (id >= 7 && id <= 11 || id >= 36 && id <= 41) {
        ctx.fillStyle = block.shade;
        // 矿石斑点
        const h = ((tx * 73856093) ^ (ty * 19349663)) & 0xffff;
        for (let s = 0; s < 3; s++) {
          const ox = ((h >> (s * 5)) & 0x1f) % (TILE - 6);
          const oy = ((h >> (s * 3)) & 0x1f) % (TILE - 6);
          ctx.fillRect(sx + ox, sy + oy, 4, 4);
        }
        // 新矿石额外光效
        if (id === 37) { // 银矿闪光
          ctx.fillStyle = 'rgba(255,255,255,0.3)';
          ctx.fillRect(sx + 6, sy + 6, 2, 2);
        }
        if (id === 40) { // 硫矿黄色脉
          ctx.fillStyle = '#e8e040';
          ctx.fillRect(sx + 4, sy + TILE - 6, TILE - 8, 2);
        }
      }

      // 方块边缘
      ctx.strokeStyle = `rgba(0,0,0,0.15)`;
      ctx.lineWidth = 1;
      ctx.strokeRect(sx + 0.5, sy + 0.5, TILE - 1, TILE - 1);

      // 草地顶部
      if (id === 1) {
        ctx.fillStyle = '#5fb850';
        ctx.fillRect(sx, sy, TILE, 3);
      }
      // 雪地顶部
      if (id === 23) {
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(sx, sy, TILE, 2);
      }
      // 火把
      if (id === 15) {
        ctx.fillStyle = '#6d4423';
        ctx.fillRect(sx + TILE/2 - 2, sy + TILE/4, 4, TILE * 3/4);
        ctx.fillStyle = '#ffcc40';
        ctx.beginPath();
        ctx.arc(sx + TILE/2, sy + TILE/4, 5, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#ff8800';
        ctx.beginPath();
        ctx.arc(sx + TILE/2, sy + TILE/4, 3, 0, Math.PI * 2);
        ctx.fill();
      }
      // 水：按水位分级绘制（流体物理），露出水面线
      if (id === 12) {
        const lvl = game.waterLevels[ty * WORLD_W + tx] || 4;
        const wh = Math.max(4, Math.round((lvl / 4) * TILE)); // 水体高度
        const top = sy + (TILE - wh);
        // 整格淡蓝（背后的景物透出一点水感）
        ctx.fillStyle = 'rgba(40,96,168,0.55)';
        ctx.fillRect(sx, sy, TILE, TILE);
        // 水体本体
        ctx.fillStyle = block.color;
        ctx.fillRect(sx, top, TILE, wh);
        // 水面高光线
        ctx.fillStyle = 'rgba(150,205,255,0.55)';
        ctx.fillRect(sx, top, TILE, 2);
        // 细微波纹
        ctx.fillStyle = 'rgba(255,255,255,0.12)';
        ctx.fillRect(sx + ((tx * 7 + ty * 3) % (TILE - 6)), top + 4, 4, 1);
      }
      // 岩浆：按岩浆量分级绘制（流体物理），露出熔岩面，深度越浅露出的底越多
      if (id === 63) {
        const l = game.lavaLevels[ty * WORLD_W + tx] || 4;
        const wh = Math.max(4, Math.round((l / 4) * TILE)); // 岩浆体高度
        const top = sy + (TILE - wh);
        // 暗红基底（整格）
        ctx.fillStyle = '#3a1205';
        ctx.fillRect(sx, sy, TILE, TILE);
        // 岩浆体
        ctx.fillStyle = block.color; // #e0581a
        ctx.fillRect(sx, top, TILE, wh);
        // 顶部熔岩亮面（橙黄）
        ctx.fillStyle = 'rgba(255,150,40,0.9)';
        ctx.fillRect(sx, top, TILE, 2);
        ctx.fillStyle = 'rgba(255,90,20,0.5)';
        ctx.fillRect(sx, top + 2, TILE, 2);
        // 底部辉光
        ctx.fillStyle = 'rgba(255,200,60,0.22)';
        ctx.fillRect(sx + 2, sy + TILE - 4, TILE - 4, 4);
      }
      // 灯笼（光源）
      if (id === 32) {
        ctx.fillStyle = '#ffcc40';
        ctx.beginPath();
        ctx.arc(sx + TILE/2, sy + TILE/2, 6, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#ff8800';
        ctx.beginPath();
        ctx.arc(sx + TILE/2, sy + TILE/2, 4, 0, Math.PI * 2);
        ctx.fill();
      }
      // 床（右键/点按可睡过夜晚）
      if (id === 59) {
        ctx.fillStyle = '#a08050';                 // 木架
        ctx.fillRect(sx, sy + TILE - 6, TILE, 6);
        ctx.fillStyle = '#e8e8f0';                 // 床单
        ctx.fillRect(sx, sy + TILE - 12, TILE, 6);
        ctx.fillStyle = '#d05050';                 // 被子
        ctx.fillRect(sx + TILE/2, sy + TILE - 12, TILE/2, 6);
        ctx.fillStyle = '#ffffff';                 // 枕头
        ctx.fillRect(sx + 2, sy + TILE - 12, 6, 6);
      }
      // 木门（占 2 格：下半+上半，合起来是一扇高门）
      if (id === 26) {
        const topHalf = getTile(tx, ty - 1) === 26; // 上方还有门板→本格为下半
        const open = game.openDoors && game.openDoors.has(ty * WORLD_W + tx);
        if (open) {
          // 开启：门板贴到右侧，留出可通行的开口
          ctx.fillStyle = '#5a3a1a';
          ctx.fillRect(sx + TILE - 5, sy + 1, 4, TILE - 2);
          ctx.fillStyle = '#3a2a10';
          ctx.fillRect(sx + TILE - 5, sy + TILE / 2 - 1, 4, 2);
        } else {
          // 关闭：整扇门板
          ctx.fillStyle = '#6a4a20';
          ctx.fillRect(sx + 2, sy + 2, TILE - 4, TILE - 4);
          ctx.fillStyle = '#4a3018';
          ctx.fillRect(sx + 2, sy + TILE / 2 - 1, TILE - 4, 2); // 门板中缝
          ctx.fillStyle = '#3a2a10';
          if (topHalf) {
            ctx.fillRect(sx + TILE - 7, sy + TILE - 9, 3, 5); // 下半：门把手
          } else {
            ctx.fillRect(sx + 2, sy + 3, TILE - 4, 3);        // 上半：门楣横木
          }
        }
      }
      // 箱子
      if (id === 27) {
        ctx.fillStyle = '#5a3a1a';
        ctx.fillRect(sx, sy + TILE/3, TILE, 2);
        ctx.fillStyle = '#3a2a10';
        ctx.fillRect(sx + TILE/2 - 2, sy + TILE/2 - 2, 4, 4);
      }
      // 木栅栏
      if (id === 28) {
        ctx.fillStyle = '#4a2e15';
        ctx.fillRect(sx + 3, sy, 3, TILE);
        ctx.fillRect(sx + TILE/2, sy, 3, TILE);
        ctx.fillRect(sx + TILE - 6, sy, 3, TILE);
      }
      // 书架
      if (id === 33) {
        ctx.fillStyle = '#5a3a1a';
        ctx.fillRect(sx, sy + TILE/3, TILE, 1);
        ctx.fillRect(sx, sy + (TILE*2)/3, TILE, 1);
        ctx.fillStyle = '#aa3333';
        ctx.fillRect(sx + 3, sy + 4, 3, TILE/3 - 6);
        ctx.fillStyle = '#3333aa';
        ctx.fillRect(sx + TILE/2, sy + 4, 3, TILE/3 - 6);
        ctx.fillStyle = '#33aa33';
        ctx.fillRect(sx + 3, sy + TILE/3 + 3, 3, TILE/3 - 6);
      }
    }
  }
}

function drawPlayer(ctx) {
  const p = game.player;
  const sx = p.x - game.camX;
  const sy = p.y - game.camY;

  // 头顶用户名（始终显示，即使闪烁）
  if (game.nickname) {
    ctx.font = 'bold 11px sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    const tw = ctx.measureText(game.nickname).width;
    const nx = sx + p.w / 2;
    const ny = sy - 14;
    ctx.fillStyle = 'rgba(0,0,0,0.6)';
    ctx.fillRect(nx - tw / 2 - 4, ny - 8, tw + 8, 16);
    ctx.fillStyle = '#00d4ff';
    ctx.fillText(game.nickname, nx, ny);
  }

  // 无敌闪烁
  if (p.invuln > 0 && Math.floor(p.invuln / 100) % 2 === 0) return;

  ctx.save();

  // 走路动画
  const walkOffset = p.onGround && Math.abs(p.vx) > 0.5 ? Math.sin(p.walkPhase * 10) * 2 : 0;
  const armSwing = p.onGround && Math.abs(p.vx) > 0.5 ? Math.sin(p.walkPhase * 10) * 8 : 0;

  // 身体
  ctx.fillStyle = '#3a6ab8';
  ctx.fillRect(sx + 2, sy + 10 + walkOffset, p.w - 4, p.h - 14);

  // 头
  ctx.fillStyle = '#e8b888';
  ctx.fillRect(sx + 3, sy, p.w - 6, 12);

  // 头发
  ctx.fillStyle = '#3a2a1a';
  ctx.fillRect(sx + 3, sy, p.w - 6, 4);

  // 眼睛
  ctx.fillStyle = '#222';
  if (p.facing > 0) {
    ctx.fillRect(sx + 9, sy + 6, 2, 2);
  } else {
    ctx.fillRect(sx + 7, sy + 6, 2, 2);
  }

  // 手臂（挖掘时挥动）
  let armY = sy + 12 + walkOffset;
  if (game.mining.target) {
    armY += Math.sin(performance.now() * 0.03) * 4;
  }
  ctx.fillStyle = '#e8b888';
  ctx.fillRect(sx + (p.facing > 0 ? p.w - 4 : 0), armY, 4, 10);

  // 腿
  ctx.fillStyle = '#2a4a8a';
  const legOffset = walkOffset;
  ctx.fillRect(sx + 2, sy + p.h - 6 + legOffset, 6, 6);
  ctx.fillRect(sx + p.w - 8, sy + p.h - 6 - legOffset, 6, 6);

  ctx.restore();
}

function drawEnemies(ctx) {
  for (const e of game.enemies) {
    const sx = e.x - game.camX;
    const sy = e.y - game.camY;

    // 弹性变形
    const sq = Math.sin(e.animPhase * 10) * 2;
    const w = e.w + sq;
    const h = e.h - sq;

    // 身体
    ctx.fillStyle = '#44cc44';
    ctx.fillRect(sx + (e.w - w) / 2, sy + (e.h - h), w, h);

    // 眼睛
    ctx.fillStyle = '#222';
    ctx.fillRect(sx + 6, sy + 8, 4, 4);
    ctx.fillRect(sx + e.w - 10, sy + 8, 4, 4);

    // 嘴
    ctx.fillStyle = '#226622';
    ctx.fillRect(sx + 8, sy + 16, e.w - 16, 2);

    // 血条
    if (e.health < e.maxHealth) {
      ctx.fillStyle = 'rgba(0,0,0,0.5)';
      ctx.fillRect(sx, sy - 6, e.w, 3);
      ctx.fillStyle = '#ff3333';
      ctx.fillRect(sx, sy - 6, e.w * (e.health / e.maxHealth), 3);
    }
  }
}

function drawDroppedItems(ctx) {
  for (const item of game.droppedItems) {
    const block = BLOCKS[item.id];
    if (!block) continue;
    const sx = item.x - game.camX;
    const sy = item.y - game.camY;
    const bob = Math.sin(performance.now() * 0.005 + item.x) * 3;
    ctx.fillStyle = block.color;
    ctx.fillRect(sx, sy + bob, 8, 8);
    ctx.strokeStyle = 'rgba(255,255,255,0.4)';
    ctx.strokeRect(sx + 0.5, sy + bob + 0.5, 7, 7);
  }
}

function drawParticles(ctx) {
  for (const p of game.particles) {
    const alpha = Math.max(0, p.life / p.maxLife);
    ctx.globalAlpha = alpha;
    ctx.fillStyle = p.color;
    ctx.fillRect(p.x - game.camX, p.y - game.camY, p.size, p.size);
  }
  ctx.globalAlpha = 1;
}

function drawLighting(ctx) {
  const t = game.time;
  let darkness = 0;

  // 夜晚暗度
  if (t > 0.5 && t < 0.95) {
    if (t < 0.6) darkness = (t - 0.5) / 0.1 * 0.5;
    else if (t < 0.85) darkness = 0.5;
    else darkness = (0.95 - t) / 0.1 * 0.5;
  }

  // 玩家在地下时大幅加暗（地下整体变暗，火把成为必需光源）
  const p = game.player;
  const pTy = Math.floor((p.y + p.h / 2) / TILE);
  const surface = game.surface[Math.floor(p.x / TILE)] || WORLD_H * 0.35;
  if (pTy > surface + 3) {
    const depth = (pTy - surface) / 15;
    darkness = Math.max(darkness, Math.min(0.92, depth * 0.5 + 0.45));
  }

  // 收集视野内光源（火把/灯笼/熔炉等带 light 的方块）
  const lightSources = [];
  const startTx = Math.max(0, Math.floor(game.camX / TILE) - 1);
  const endTx = Math.min(WORLD_W, Math.ceil((game.camX + game.cw) / TILE) + 1);
  const startTy = Math.max(0, Math.floor(game.camY / TILE) - 1);
  const endTy = Math.min(WORLD_H, Math.ceil((game.camY + game.ch) / TILE) + 1);
  for (let ty = startTy; ty <= endTy; ty++) {
    for (let tx = startTx; tx <= endTx; tx++) {
      const tileId = getTile(tx, ty);
      const block = BLOCKS[tileId];
      if (!block || !block.light || block.light === 0) continue;
      lightSources.push({
        x: tx * TILE + TILE / 2 - game.camX,
        y: ty * TILE + TILE / 2 - game.camY,
        radius: block.light,
        id: tileId,
      });
    }
  }

  const now = performance.now();

  // 暖色光晕（始终叠加，营造灯笼/熔炉氛围）
  ctx.save();
  ctx.globalCompositeOperation = 'lighter';
  for (const src of lightSources) {
    // 火把(id 15)不再叠加暖色光晕，去掉其周围那圈橙黄色“边框”
    if (src.id === 15) continue;
    // 火焰闪烁
    let flicker = 1;
    if (src.id === 15 || src.id === 32 || src.id === 18) {
      flicker = 0.82 + Math.sin(now * 0.012 + src.x * 0.1) * 0.06 + Math.sin(now * 0.028 + src.y * 0.07) * 0.04 + (Math.random() - 0.5) * 0.08;
    }
    const r = TILE * src.radius * flicker;
    const glowAlpha = src.id === 15 ? 0.18 : src.id === 32 ? 0.22 : 0.12;
    const grad = ctx.createRadialGradient(src.x, src.y, 0, src.x, src.y, r);
    grad.addColorStop(0, `rgba(255,180,60,${glowAlpha * flicker})`);
    grad.addColorStop(0.3, `rgba(255,120,30,${glowAlpha * 0.5 * flicker})`);
    grad.addColorStop(1, 'rgba(255,80,0,0)');
    ctx.fillStyle = grad;
    ctx.fillRect(src.x - r, src.y - r, r * 2, r * 2);
  }
  ctx.restore();

  if (darkness < 0.01) return;

  // —— 关键修复：暗层画在离屏画布上，挖洞后再叠加到主画布 ——
  // 旧实现直接在主画布上挖洞（destination-out），会把已绘制的世界一起擦掉、露出页面背景（黑屏）。
  // 现改为：离屏暗层挖洞 → 透明处叠回主画布时露出下面的世界，火把/玩家周围才真正“照亮”。
  const lc = game.lightCanvas;
  if (!lc || lc.width !== game.cw || lc.height !== game.ch) {
    game.lightCanvas = document.createElement('canvas');
    game.lightCanvas.width = game.cw;
    game.lightCanvas.height = game.ch;
    game.lightCtx = game.lightCanvas.getContext('2d');
  }
  const l = game.lightCtx;
  l.globalCompositeOperation = 'source-over';
  l.clearRect(0, 0, game.cw, game.ch);
  l.fillStyle = `rgba(5,5,20,${darkness})`;
  l.fillRect(0, 0, game.cw, game.ch);

  // 玩家处挖洞：核心完全透出世界（地下时光圈缩小，逼迫玩家使用火把照明）
  const pSx = p.x + p.w / 2 - game.camX;
  const pSy = p.y + p.h / 2 - game.camY;
  const underground = pTy > surface + 3;
  const lightR = underground ? TILE * 3.2 : TILE * 5.5;
  l.globalCompositeOperation = 'destination-out';
  const pGrad = l.createRadialGradient(pSx, pSy, 0, pSx, pSy, lightR);
  pGrad.addColorStop(0, 'rgba(0,0,0,1)');
  pGrad.addColorStop(0.5, 'rgba(0,0,0,0.55)');
  pGrad.addColorStop(1, 'rgba(0,0,0,0)');
  l.fillStyle = pGrad;
  l.fillRect(0, 0, game.cw, game.ch);

  // 火把/灯笼等光源挖洞（带闪烁）：核心 alpha=1 让该区域完全透出世界 → 夜晚真正发亮
  for (const src of lightSources) {
    let flicker = 1;
    if (src.id === 15 || src.id === 32 || src.id === 18) {
      flicker = 0.82 + Math.sin(now * 0.012 + src.x * 0.1) * 0.06 + Math.sin(now * 0.028 + src.y * 0.07) * 0.04 + (Math.random() - 0.5) * 0.08;
    }
    const r = TILE * src.radius * flicker;
    const lg = l.createRadialGradient(src.x, src.y, 0, src.x, src.y, r);
    lg.addColorStop(0, 'rgba(0,0,0,1)');
    lg.addColorStop(0.4, 'rgba(0,0,0,0.6)');
    lg.addColorStop(0.75, 'rgba(0,0,0,0.18)');
    lg.addColorStop(1, 'rgba(0,0,0,0)');
    l.fillStyle = lg;
    l.fillRect(src.x - r, src.y - r, r * 2, r * 2);
  }

  // 把暗层叠回主画布：未挖洞处保持黑暗，挖洞处露出已绘制的世界
  l.globalCompositeOperation = 'source-over';
  ctx.drawImage(game.lightCanvas, 0, 0);
}

function drawMiningProgress(ctx) {
  if (!game.mining.target) return;
  const tx = game.mining.x;
  const ty = game.mining.y;
  const block = BLOCKS[getTile(tx, ty)];
  if (!block) return;

  const sx = tx * TILE - game.camX;
  const sy = ty * TILE - game.camY;
  const prog = game.mining.progress / (block.hardness * 8);

  // 裂纹
  ctx.fillStyle = `rgba(0,0,0,${prog * 0.5})`;
  ctx.fillRect(sx, sy, TILE, TILE);

  // 裂纹线条
  ctx.strokeStyle = `rgba(0,0,0,${prog * 0.8})`;
  ctx.lineWidth = 1;
  if (prog > 0.2) {
    ctx.beginPath();
    ctx.moveTo(sx + 4, sy + 4);
    ctx.lineTo(sx + TILE - 4, sy + TILE - 4);
    ctx.moveTo(sx + TILE - 4, sy + 4);
    ctx.lineTo(sx + 4, sy + TILE - 4);
    ctx.stroke();
  }
  if (prog > 0.5) {
    ctx.beginPath();
    ctx.moveTo(sx, sy + TILE / 2);
    ctx.lineTo(sx + TILE, sy + TILE / 2);
    ctx.moveTo(sx + TILE / 2, sy);
    ctx.lineTo(sx + TILE / 2, sy + TILE);
    ctx.stroke();
  }
}

function drawMouseTarget(ctx) {
  const tx = Math.floor(game.mouse.worldX / TILE);
  const ty = Math.floor(game.mouse.worldY / TILE);
  const p = game.player;
  const px = Math.floor((p.x + p.w / 2) / TILE);
  const py = Math.floor((p.y + p.h / 2) / TILE);
  const dist = Math.abs(tx - px) + Math.abs(ty - py);
  if (dist > REACH) return;

  const tileId = getTile(tx, ty);
  const sx = tx * TILE - game.camX;
  const sy = ty * TILE - game.camY;

  // 检查工具需求
  const block = BLOCKS[tileId];
  let canMine = true;
  if (block && block.tool) {
    const equippedId = game.hotbar[game.selectedSlot];
    const eqBlock = equippedId > 0 ? BLOCKS[equippedId] : null;
    const toolTier = (eqBlock && eqBlock.toolTier) ? eqBlock.toolTier : 0;
    if (toolTier < block.tool) canMine = false;
  }

  if (tileId === 0) {
    ctx.strokeStyle = 'rgba(100,255,100,0.5)';
  } else if (!canMine) {
    ctx.strokeStyle = 'rgba(255,80,80,0.7)';
  } else {
    ctx.strokeStyle = 'rgba(255,255,255,0.5)';
  }
  ctx.lineWidth = 2;
  ctx.strokeRect(sx, sy, TILE, TILE);

  // 显示工具需求
  if (!canMine && block) {
    const tierNames = ['', '木镐', '石镐', '铁镐'];
    ctx.fillStyle = 'rgba(255,80,80,0.9)';
    ctx.font = 'bold 9px sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(`需要${tierNames[block.tool]}`, sx + TILE / 2, sy - 6);
  }
}

// ==================== UI ====================
function drawUI(ctx) {
  // 生命值
  const healthBarW = 200;
  const healthBarH = 18;
  ctx.fillStyle = 'rgba(0,0,0,0.6)';
  ctx.fillRect(10, 10, healthBarW + 4, healthBarH + 4);
  ctx.fillStyle = '#1a1a2e';
  ctx.fillRect(12, 12, healthBarW, healthBarH);
  const hpct = game.player.health / game.player.maxHealth;
  ctx.fillStyle = hpct > 0.5 ? '#22cc44' : (hpct > 0.25 ? '#ccaa22' : '#cc3333');
  ctx.fillRect(12, 12, healthBarW * hpct, healthBarH);
  ctx.fillStyle = '#fff';
  ctx.font = 'bold 12px sans-serif';
  ctx.textAlign = 'center';
  ctx.fillText(`❤ ${Math.ceil(game.player.health)} / ${game.player.maxHealth}`, 12 + healthBarW / 2, 12 + 13);

  // 血量回复指示
  const timeSinceDamage = performance.now() - (game.player.lastDamageTime || 0);
  if (game.player.health < game.player.maxHealth && timeSinceDamage > 4000 && game.player.invuln <= 0) {
    const pulse = 0.4 + Math.sin(performance.now() * 0.005) * 0.3;
    ctx.strokeStyle = `rgba(34,255,68,${pulse})`;
    ctx.lineWidth = 2;
    ctx.strokeRect(10, 10, healthBarW + 4, healthBarH + 4);
    ctx.fillStyle = `rgba(34,255,68,${pulse})`;
    ctx.font = 'bold 9px sans-serif';
    ctx.textAlign = 'left';
    ctx.fillText('＋回复中', 12 + healthBarW + 10, 24);
  }

  // 装备工具显示
  const equippedId = game.hotbar[game.selectedSlot];
  if (equippedId > 0) {
    const eqBlock = BLOCKS[equippedId];
    if (eqBlock && eqBlock.toolTier) {
      const tierNames = ['', '木镐', '石镐', '铁镐'];
      ctx.fillStyle = 'rgba(0,0,0,0.5)';
      ctx.fillRect(10, 36, 130, 20);
      ctx.fillStyle = '#ffaa44';
      ctx.font = 'bold 11px sans-serif';
      ctx.textAlign = 'left';
      ctx.textBaseline = 'middle';
      ctx.fillText(`⛏️ ${tierNames[eqBlock.toolTier]} Lv.${eqBlock.toolTier}`, 16, 47);
    }
  }

  // 昼夜指示
  const timeText = game.time < 0.5 ? `☀ 白天` : `🌙 夜晚`;
  ctx.fillStyle = 'rgba(0,0,0,0.5)';
  ctx.fillRect(game.cw - 120, 10, 110, 22);
  ctx.fillStyle = '#fff';
  ctx.font = '12px sans-serif';
  ctx.textAlign = 'left';
  ctx.fillText(timeText, game.cw - 110, 25);

  // 已发现元素计数
  const totalElements = Object.keys(PERIODIC_TABLE).length;
  const foundCount = game.discoveredElements.size;
  ctx.fillStyle = 'rgba(0,0,0,0.5)';
  ctx.fillRect(game.cw - 120, 36, 110, 22);
  ctx.fillStyle = '#88ffcc';
  ctx.font = 'bold 11px sans-serif';
  ctx.textAlign = 'left';
  ctx.fillText(`🔬 ${foundCount}/${totalElements} 元素`, game.cw - 110, 51);

  // FPS
  ctx.fillStyle = 'rgba(0,0,0,0.4)';
  ctx.fillRect(game.cw - 60, game.ch - 24, 50, 18);
  ctx.fillStyle = '#88ff88';
  ctx.font = '11px monospace';
  ctx.fillText(`${game.fps}fps`, game.cw - 55, game.ch - 11);

  // 热栏
  drawHotbar(ctx);

  // 操作提示
  if (game.time === 0 || performance.now() < 8000) {
    ctx.fillStyle = 'rgba(0,0,0,0.6)';
    ctx.fillRect(game.cw / 2 - 180, game.ch - 60, 360, 36);
    ctx.fillStyle = '#fff';
    ctx.font = '11px sans-serif';
    ctx.textAlign = 'center';
    if (game.touchInput.isTouch) {
      ctx.fillText('摇杆移动 | ⬆️跳跃 | ⛏️挖掘(面前方块) | 🧱放置 | 点怪对战', game.cw / 2, game.ch - 42);
      ctx.fillText('🎒背包 | 🔧合成 | 点击热栏选栏 | 右键工作台/熔炉打开UI', game.cw / 2, game.ch - 28);
    } else {
      ctx.fillText('A/D移动 | W/空格跳跃 | 左键挖掘 | 右键放置/使用工作站 | 1-0选栏 | E背包 | Tab合成', game.cw / 2, game.ch - 42);
      ctx.fillText('右键工作台/熔炉打开独立UI | 挖矿获得材料合成工具 | 挖掘新矿石发现化学元素', game.cw / 2, game.ch - 28);
    }
  }
}

function drawHotbar(ctx) {
  const slotSize = 44;
  const gap = 4;
  const totalW = 10 * slotSize + 9 * gap;
  const startX = (game.cw - totalW) / 2;
  // 触屏设备热栏上移，避免与摇杆/按钮重叠
  const y = game.ch - slotSize - (game.touchInput.isTouch ? 20 : 14);

  for (let i = 0; i < 10; i++) {
    const x = startX + i * (slotSize + gap);
    const isSelected = i === game.selectedSlot;
    const isHovered = i === game.hoveredSlot;

    // 背景
    ctx.fillStyle = isSelected ? 'rgba(0,212,255,0.25)' : (isHovered ? 'rgba(255,255,255,0.12)' : 'rgba(0,0,0,0.55)');
    ctx.fillRect(x, y, slotSize, slotSize);

    // 边框
    ctx.strokeStyle = isSelected ? '#00d4ff' : (isHovered ? 'rgba(255,255,255,0.5)' : 'rgba(255,255,255,0.2)');
    ctx.lineWidth = isSelected ? 2.5 : 1.5;
    ctx.strokeRect(x + 1, y + 1, slotSize - 2, slotSize - 2);

    // 方块图标
    const blockId = game.hotbar[i];
    if (blockId > 0 && game.hotbarCounts[i] > 0) {
      const iconSize = 28;
      const iconX = x + (slotSize - iconSize) / 2;
      const iconY = y + (slotSize - iconSize) / 2 - 2;
      drawBlockIcon(ctx, iconX, iconY, iconSize, blockId);

      // 元素指示器
      const element = BLOCK_ELEMENTS[blockId];
      if (element) {
        const elemInfo = ELEMENT_INFO[element];
        ctx.fillStyle = elemInfo.color;
        ctx.beginPath();
        ctx.arc(x + 7, y + 7, 4, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = 'rgba(0,0,0,0.4)';
        ctx.lineWidth = 1;
        ctx.stroke();
      }

      // 数量
      const count = game.hotbarCounts[i];
      if (count > 0) {
        ctx.fillStyle = 'rgba(0,0,0,0.75)';
        ctx.fillRect(x + slotSize - 20, y + slotSize - 16, 18, 14);
        ctx.fillStyle = '#fff';
        ctx.font = 'bold 11px sans-serif';
        ctx.textAlign = 'right';
        ctx.textBaseline = 'middle';
        ctx.fillText(count, x + slotSize - 4, y + slotSize - 9);
      }
    }

    // 槽位号
    ctx.fillStyle = isSelected ? 'rgba(0,212,255,0.9)' : 'rgba(255,255,255,0.35)';
    ctx.font = 'bold 9px sans-serif';
    ctx.textAlign = 'left';
    ctx.textBaseline = 'top';
    ctx.fillText(i === 9 ? '0' : String(i + 1), x + 4, y + 4);
  }

  // 悬停提示
  if (game.hoveredSlot >= 0) {
    const blockId = game.hotbar[game.hoveredSlot];
    if (blockId > 0 && game.hotbarCounts[game.hoveredSlot] > 0) {
      const block = BLOCKS[blockId];
      const element = BLOCK_ELEMENTS[blockId];
      const elemInfo = element ? ELEMENT_INFO[element] : null;
      let tipText = block.name;
      if (elemInfo) tipText += ` [${elemInfo.icon}${elemInfo.name}]`;
      if (block.toolTier) {
        const tierNames = ['', '木镐', '石镐', '铁镐'];
        tipText += ` [⛏ Lv.${block.toolTier} ${tierNames[block.toolTier]}]`;
      }
      tipText += ` x${game.hotbarCounts[game.hoveredSlot]}`;

      ctx.font = 'bold 12px sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      const tipW = ctx.measureText(tipText).width + 20;
      const tipX = startX + game.hoveredSlot * (slotSize + gap) + slotSize / 2;
      const tipY = y - 30;

      ctx.fillStyle = 'rgba(0,0,0,0.85)';
      ctx.fillRect(tipX - tipW / 2, tipY - 12, tipW, 24);
      ctx.strokeStyle = 'rgba(0,212,255,0.4)';
      ctx.lineWidth = 1;
      ctx.strokeRect(tipX - tipW / 2 + 0.5, tipY - 11.5, tipW - 1, 23);
      ctx.fillStyle = '#e0e8f0';
      ctx.fillText(tipText, tipX, tipY);
    }
  }

  // 工作站提示：靠近熔炉/工作台时，用彩色胶囊分别提示（更醒目），点击/右键打开
  const stationHints = [];
  if (hasWB) stationHints.push({ label: '🔨 工作台', color: '#00d4ff' });
  if (hasFN) stationHints.push({ label: '🔥 熔炉', color: '#ff7a1e' });
  if (stationHints.length) {
    ctx.font = 'bold 13px sans-serif';
    ctx.textAlign = 'left';
    ctx.textBaseline = 'middle';
    const padX = 12, gap = 10, h = 28, boxY = y - h - 34;
    let curX = startX;
    for (const s of stationHints) {
      const full = s.label + '  右键打开';
      const w = ctx.measureText(full).width + padX * 2;
      ctx.fillStyle = 'rgba(0,0,0,0.82)';
      ctx.fillRect(curX, boxY, w, h);
      ctx.strokeStyle = s.color;
      ctx.lineWidth = 2;
      ctx.strokeRect(curX + 1, boxY + 1, w - 2, h - 2);
      ctx.fillStyle = '#ffffff';
      ctx.fillText(full, curX + padX, boxY + h / 2);
      curX += w + gap;
    }
  }
}

// 绘制方块像素图标（热栏/合成界面通用）
function drawBlockIcon(ctx, x, y, size, blockId) {
  const block = BLOCKS[blockId];
  if (!block || !block.color) return;

  const s = size;
  // 底色
  ctx.fillStyle = block.color;
  ctx.fillRect(x, y, s, s);

  const shade = block.shade || block.color;
  const id = blockId;

  // 根据方块类型绘制不同的像素纹理
  if (id === 4) {
    // 原木：年轮纹理
    ctx.fillStyle = shade;
    ctx.fillRect(x, y + 2, s, 2);
    ctx.fillRect(x, y + s - 4, s, 2);
    ctx.fillStyle = 'rgba(0,0,0,0.2)';
    ctx.fillRect(x + s/2 - 1, y + 4, 2, s - 8);
  } else if (id === 3) {
    // 石头：随机斑点
    ctx.fillStyle = shade;
    ctx.fillRect(x + 3, y + 4, 4, 3);
    ctx.fillRect(x + s - 8, y + 6, 3, 4);
    ctx.fillRect(x + 5, y + s - 8, 4, 3);
  } else if (id === 2) {
    // 泥土：深色颗粒
    ctx.fillStyle = shade;
    ctx.fillRect(x + 2, y + 3, 3, 3);
    ctx.fillRect(x + s - 6, y + 5, 3, 2);
    ctx.fillRect(x + 4, y + s - 6, 2, 3);
  } else if (id === 1) {
    // 草地：绿色顶部
    ctx.fillStyle = '#5fb850';
    ctx.fillRect(x, y, s, 4);
    ctx.fillStyle = shade;
    ctx.fillRect(x + 3, y + s - 4, 3, 3);
  } else if (id === 6) {
    // 沙子：亮点
    ctx.fillStyle = 'rgba(255,255,200,0.4)';
    ctx.fillRect(x + 2, y + 3, 2, 2);
    ctx.fillRect(x + s - 5, y + 5, 2, 2);
    ctx.fillRect(x + 4, y + s - 4, 2, 2);
  } else if (id === 13) {
    // 木板：水平纹路
    ctx.fillStyle = shade;
    ctx.fillRect(x, y + s/3, s, 1);
    ctx.fillRect(x, y + (s*2)/3, s, 1);
    ctx.fillStyle = 'rgba(0,0,0,0.15)';
    ctx.fillRect(x + s/2, y, 1, s/3);
    ctx.fillRect(x + s/3, y + s/3, 1, s/3);
  } else if (id >= 7 && id <= 11) {
    // 矿石：矿脉亮点
    ctx.fillStyle = shade;
    ctx.fillRect(x + 3, y + 4, 4, 4);
    ctx.fillRect(x + s - 7, y + 6, 3, 3);
    ctx.fillRect(x + 5, y + s - 8, 3, 3);
    if (id === 11) {
      ctx.fillStyle = 'rgba(255,255,255,0.5)';
      ctx.fillRect(x + 4, y + 5, 2, 2);
    }
  } else if (id === 15) {
    // 火把
    ctx.fillStyle = '#6d4423';
    ctx.fillRect(x + s/2 - 2, y + s/3, 4, s * 2/3);
    ctx.fillStyle = '#ffcc40';
    ctx.beginPath();
    ctx.arc(x + s/2, y + s/3, 5, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#ff8800';
    ctx.beginPath();
    ctx.arc(x + s/2, y + s/3, 3, 0, Math.PI * 2);
    ctx.fill();
  } else if (id === 59) {
    // 床
    ctx.fillStyle = '#a08050';
    ctx.fillRect(x, y + s - 5, s, 5);
    ctx.fillStyle = '#e8e8f0';
    ctx.fillRect(x, y + s - 10, s, 5);
    ctx.fillStyle = '#d05050';
    ctx.fillRect(x + s/2, y + s - 10, s/2, 5);
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(x + 2, y + s - 10, 5, 5);
  } else if (id === 17) {
    // 工作台：网格
    ctx.fillStyle = shade;
    ctx.fillRect(x, y, s, 3);
    ctx.fillRect(x, y + s/2, s, 1);
    ctx.fillRect(x + s/2, y + 3, 1, s - 3);
  } else if (id === 18) {
    // 熔炉：开口
    ctx.fillStyle = shade;
    ctx.fillRect(x, y, s, 3);
    ctx.fillStyle = '#ff6600';
    ctx.fillRect(x + s/3, y + s/3, s/3, s/3);
  } else if (id === 16) {
    // 玻璃：高光
    ctx.fillStyle = 'rgba(255,255,255,0.3)';
    ctx.fillRect(x + 2, y + 2, 3, s - 4);
  } else if (id === 14 || id === 22) {
    // 砖块/石砖：砖缝
    ctx.fillStyle = shade;
    ctx.fillRect(x, y + s/2, s, 1);
    ctx.fillRect(x + s/2, y, 1, s/2);
    ctx.fillRect(x + s/4, y + s/2, 1, s/2);
  } else if (id === 12) {
    // 水：波纹
    ctx.fillStyle = 'rgba(100,180,255,0.4)';
    ctx.fillRect(x, y + 2, s, 2);
    ctx.fillRect(x, y + s/2, s, 1);
  } else if (id === 60) {
    // 空桶
    ctx.fillStyle = '#8a8a90';
    ctx.fillRect(x + s*0.25, y + s*0.30, s*0.5, s*0.55);
    ctx.fillStyle = '#5a5a60';
    ctx.fillRect(x + s*0.22, y + s*0.26, s*0.56, s*0.08);
    ctx.fillRect(x + s*0.20, y + s*0.26, s*0.08, s*0.12);
    ctx.fillRect(x + s*0.72, y + s*0.26, s*0.08, s*0.12);
  } else if (id === 61) {
    // 水桶
    ctx.fillStyle = '#7a7a82';
    ctx.fillRect(x + s*0.25, y + s*0.30, s*0.5, s*0.55);
    ctx.fillStyle = '#2f6fc0';
    ctx.fillRect(x + s*0.27, y + s*0.40, s*0.46, s*0.42);
    ctx.fillStyle = '#5a5a60';
    ctx.fillRect(x + s*0.22, y + s*0.26, s*0.56, s*0.08);
  } else if (id === 62) {
    // 岩浆桶
    ctx.fillStyle = '#7a7a82';
    ctx.fillRect(x + s*0.25, y + s*0.30, s*0.5, s*0.55);
    ctx.fillStyle = '#e0581a';
    ctx.fillRect(x + s*0.27, y + s*0.40, s*0.46, s*0.42);
    ctx.fillStyle = '#5a5a60';
    ctx.fillRect(x + s*0.22, y + s*0.26, s*0.56, s*0.08);
  } else if (id === 63) {
    // 岩浆
    ctx.fillStyle = '#e0581a';
    ctx.fillRect(x, y, s, s);
    ctx.fillStyle = '#ffae3a';
    ctx.fillRect(x, y, s, 3);
  } else if (id === 23) {
    // 雪：白点
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(x, y, s, 3);
  } else if (id === 24) {
    // 冰：裂纹
    ctx.fillStyle = 'rgba(255,255,255,0.3)';
    ctx.fillRect(x + 2, y + 3, 4, 1);
    ctx.fillRect(x + s - 6, y + s - 4, 4, 1);
  } else if (id === 25) {
    // 黑曜石：紫色斑点
    ctx.fillStyle = '#3a1a4e';
    ctx.fillRect(x + 3, y + 4, 3, 3);
    ctx.fillRect(x + s - 6, y + s - 7, 3, 3);
  } else if (id === 26) {
    // 木门
    ctx.fillStyle = shade;
    ctx.fillRect(x + 2, y + 2, s - 4, s - 4);
    ctx.fillStyle = '#5a3a1a';
    ctx.fillRect(x + s - 8, y + s/2 - 1, 3, 3);
  } else if (id === 27) {
    // 箱子
    ctx.fillStyle = shade;
    ctx.fillRect(x, y + s/3, s, 2);
    ctx.fillStyle = '#5a3a1a';
    ctx.fillRect(x + s/2 - 2, y + s/2 - 1, 4, 3);
  } else if (id === 28) {
    // 栅栏
    ctx.fillStyle = shade;
    ctx.fillRect(x + 2, y, 2, s);
    ctx.fillRect(x + s/2 - 1, y, 2, s);
    ctx.fillRect(x + s - 4, y, 2, s);
    ctx.fillRect(x, y + s/3, s, 2);
    ctx.fillRect(x, y + (s*2)/3, s, 2);
  } else if (id === 29 || id === 30 || id === 34) {
    // 金属砖：光泽
    ctx.fillStyle = 'rgba(255,255,255,0.3)';
    ctx.fillRect(x + 2, y + 2, s - 4, 2);
    ctx.fillStyle = shade;
    ctx.fillRect(x, y + s - 3, s, 3);
  } else if (id === 31 || id === 35) {
    // 晶体砖：闪光
    ctx.fillStyle = 'rgba(255,255,255,0.5)';
    ctx.fillRect(x + 3, y + 3, 3, 3);
    ctx.fillRect(x + s - 6, y + s - 6, 2, 2);
    ctx.fillStyle = shade;
    ctx.fillRect(x, y + s/2, s, 1);
  } else if (id === 32) {
    // 灯笼
    ctx.fillStyle = '#6d4423';
    ctx.fillRect(x + 2, y, s - 4, 3);
    ctx.fillRect(x + 2, y + s - 3, s - 4, 3);
    ctx.fillStyle = '#ffcc40';
    ctx.beginPath();
    ctx.arc(x + s/2, y + s/2, s/3, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#ff8800';
    ctx.beginPath();
    ctx.arc(x + s/2, y + s/2, s/4, 0, Math.PI * 2);
    ctx.fill();
  } else if (id === 33) {
    // 书架
    ctx.fillStyle = shade;
    ctx.fillRect(x, y + s/3, s, 1);
    ctx.fillRect(x, y + (s*2)/3, s, 1);
    ctx.fillStyle = '#aa3333';
    ctx.fillRect(x + 3, y + 4, 3, s/3 - 6);
    ctx.fillStyle = '#3333aa';
    ctx.fillRect(x + s/2, y + 4, 3, s/3 - 6);
    ctx.fillStyle = '#33aa33';
    ctx.fillRect(x + 3, y + s/3 + 3, 3, s/3 - 6);
  } else if (id === 19 || id === 20 || id === 21) {
    // 锭块：金属光泽
    ctx.fillStyle = 'rgba(255,255,255,0.25)';
    ctx.fillRect(x + 2, y + 2, s - 4, 2);
    ctx.fillStyle = shade;
    ctx.fillRect(x, y + s - 4, s, 4);
  } else if (id === 5) {
    // 树叶
    ctx.fillStyle = shade;
    ctx.fillRect(x + 3, y + 3, 3, 3);
    ctx.fillRect(x + s - 6, y + 5, 3, 3);
    ctx.fillRect(x + 5, y + s - 6, 3, 2);
  } else if (id >= 36 && id <= 41) {
    // 新矿石：矿脉亮点
    ctx.fillStyle = shade;
    ctx.fillRect(x + 3, y + 4, 4, 4);
    ctx.fillRect(x + s - 7, y + 6, 3, 3);
    ctx.fillRect(x + 5, y + s - 8, 3, 3);
    if (id === 37) { // 银矿白光
      ctx.fillStyle = 'rgba(255,255,255,0.5)';
      ctx.fillRect(x + 4, y + 5, 2, 2);
    }
    if (id === 40) { // 硫矿黄色
      ctx.fillStyle = '#e8e040';
      ctx.fillRect(x + 4, y + s - 5, s - 8, 2);
    }
    if (id === 41) { // 石英透明感
      ctx.fillStyle = 'rgba(255,255,255,0.4)';
      ctx.fillRect(x + 4, y + 5, 2, 2);
      ctx.fillRect(x + s - 6, y + s - 7, 2, 2);
    }
  } else if (id >= 42 && id <= 46) {
    // 新冶炼锭块
    ctx.fillStyle = 'rgba(255,255,255,0.2)';
    ctx.fillRect(x + 2, y + 2, s - 4, 2);
    ctx.fillStyle = shade;
    ctx.fillRect(x, y + s - 4, s, 4);
    if (id === 43) { // 银锭高光
      ctx.fillStyle = 'rgba(255,255,255,0.4)';
      ctx.fillRect(x + 4, y + 4, 3, 2);
    }
  } else if (id === 47) {
    // 青铜块
    ctx.fillStyle = shade;
    ctx.fillRect(x, y + s/2, s, 1);
    ctx.fillStyle = 'rgba(255,180,80,0.3)';
    ctx.fillRect(x + 2, y + 2, s - 4, 2);
  } else if (id === 48) {
    // 焊料块
    ctx.fillStyle = shade;
    ctx.fillRect(x + 2, y + 2, 3, 3);
    ctx.fillRect(x + s - 5, y + s - 5, 3, 3);
  } else if (id === 49) {
    // 琥珀金
    ctx.fillStyle = 'rgba(255,255,200,0.4)';
    ctx.fillRect(x + 3, y + 3, 3, 3);
    ctx.fillRect(x + s - 6, y + s - 6, 2, 2);
  } else if (id === 50) {
    // 透镜
    ctx.fillStyle = 'rgba(255,255,255,0.4)';
    ctx.beginPath();
    ctx.arc(x + s/2, y + s/2, s/3, 0, Math.PI * 2);
    ctx.fill();
  } else if (id === 51) {
    // 导电板
    ctx.fillStyle = shade;
    ctx.fillRect(x + 2, y + 2, 3, 3);
    ctx.fillRect(x + s - 5, y + 2, 3, 3);
    ctx.fillStyle = 'rgba(0,200,255,0.3)';
    ctx.fillRect(x + 5, y + s/2 - 1, s - 10, 2);
  } else if (id === 52) {
    // 硫磺弹
    ctx.fillStyle = shade;
    ctx.beginPath();
    ctx.arc(x + s/2, y + s/2, s/3, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#ff6600';
    ctx.fillRect(x + s/2 - 1, y + 2, 2, 4);
  } else if (id === 53) {
    // 毒药瓶
    ctx.fillStyle = shade;
    ctx.fillRect(x + s/3, y, s/3, 4);
    ctx.fillStyle = block.color;
    ctx.beginPath();
    ctx.arc(x + s/2, y + s/2 + 2, s/3, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = 'rgba(155,89,182,0.5)';
    ctx.fillRect(x + 4, y + s/2, 3, 2);
  } else if (id === 54) {
    // 半导体
    ctx.fillStyle = shade;
    ctx.fillRect(x + 2, y + s/2 - 1, s - 4, 2);
    ctx.fillStyle = 'rgba(0,255,100,0.3)';
    ctx.fillRect(x + 3, y + 3, 3, 3);
    ctx.fillStyle = 'rgba(255,0,0,0.3)';
    ctx.fillRect(x + s - 6, y + s - 6, 3, 3);
  } else if (id === 55) {
    // 电池组
    ctx.fillStyle = shade;
    ctx.fillRect(x, y + 2, s, s - 4);
    ctx.fillStyle = '#ff3333';
    ctx.fillRect(x + 2, y + 4, s/2 - 2, s - 8);
    ctx.fillStyle = '#3333ff';
    ctx.fillRect(x + s/2, y + 4, s/2 - 2, s - 8);
    ctx.fillStyle = '#888';
    ctx.fillRect(x + s/2 - 1, y, 2, 3);
  } else if (id === 56 || id === 57 || id === 58) {
    // 镐子工具
    // 颜色根据等级变化
    const headColors = { 56:'#9a6b3a', 57:'#7a7a80', 58:'#c0c0c8' };
    const headDark = { 56:'#6d4423', 57:'#5a5a5f', 58:'#909098' };
    const hc = headColors[id];
    const hd = headDark[id];
    // 手柄
    ctx.fillStyle = '#6d4423';
    ctx.fillRect(x + s/2 - 1, y + s/3, 3, s * 2/3);
    // 镐头
    ctx.fillStyle = hc;
    ctx.fillRect(x + 2, y + 2, s - 4, 5);
    ctx.fillStyle = hd;
    ctx.fillRect(x + 2, y + 5, s - 4, 2);
    // 高光
    ctx.fillStyle = 'rgba(255,255,255,0.3)';
    ctx.fillRect(x + 3, y + 3, s - 6, 1);
  }

  // 边框
  ctx.strokeStyle = 'rgba(0,0,0,0.3)';
  ctx.lineWidth = 1;
  ctx.strokeRect(x + 0.5, y + 0.5, s - 1, s - 1);
}

// ==================== 合成界面 ====================
function drawCrafting() {
  const overlay = document.getElementById('crafting-overlay');
  const panel = document.getElementById('crafting-panel');
  overlay.style.display = 'flex';

  // 设置面板样式
  panel.className = '';
  panel.classList.add('mode-' + game.craftingMode);

  const mode = game.craftingMode;
  const modeConfig = {
    'hand':      { title: '✋ 手工合成', icon: '✋', needStation: false },
    'workbench': { title: '🔨 工作台', icon: '🔨', needStation: true, station: 'workbench' },
    'furnace':   { title: '🔥 熔炉', icon: '🔥', needStation: true, station: 'furnace' },
  };
  const cfg = modeConfig[mode] || modeConfig['hand'];

  const hasStation = cfg.needStation ? hasCraftingStation(cfg.station) : true;

  // 筛选当前模式的配方
  const needKey = mode === 'hand' ? 'none' : mode;
  const filteredRecipes = RECIPES.filter(r => r.needs === needKey);

  let html = `<div class="craft-title"><span>${cfg.title}</span><span class="craft-close-x" id="craft-close-x" title="关闭">✕</span></div>`;

  if (cfg.needStation) {
    html += `<div class="craft-stations">`;
    html += `<span class="station-badge ${hasStation ? 'active' : 'inactive'}">${cfg.icon} ${cfg.station === 'workbench' ? '工作台' : '熔炉'} ${hasStation ? '✓ 附近' : '✗ 不在附近'}</span>`;
    html += `</div>`;
  }

  if (filteredRecipes.length === 0) {
    html += '<div class="craft-empty">暂无可用配方</div>';
  } else {
    html += '<div class="craft-list">';

    for (const r of filteredRecipes) {
      const outId = parseInt(Object.keys(r.output)[0]);
      const outCount = r.output[outId];
      const outBlock = BLOCKS[outId];
      let inputs = '';
      let canCraft = hasStation;
      for (const [id, count] of Object.entries(r.input)) {
        const b = BLOCKS[parseInt(id)];
        const have = game.inventory[parseInt(id)] || 0;
        const enough = have >= count;
        if (!enough) canCraft = false;
        inputs += `<span class="recipe-item ${enough ? '' : 'missing'}">${b.name}×${count}</span>`;
      }

      // 化学方程式
      let chemHtml = '';
      if (r.chem) {
        chemHtml = `<div class="recipe-chem">⚗ ${r.chem}</div>`;
      }

      // 工具需求提示
      let toolHtml = '';
      if (outBlock && outBlock.toolTier) {
        const tierNames = ['', '木镐', '石镐', '铁镐'];
        toolHtml = `<div class="recipe-tool-req">⛏ 挖掘等级 ${outBlock.toolTier}（${tierNames[outBlock.toolTier]}）</div>`;
      }

      html += `
        <div class="recipe-card ${canCraft ? '' : 'dimmed'}" data-idx="${RECIPES.indexOf(r)}">
          <canvas class="recipe-icon-canvas" width="32" height="32" data-block="${outId}"></canvas>
          <div class="recipe-info">
            <div class="recipe-name">${r.name} ×${outCount}</div>
            <div class="recipe-inputs">${inputs}</div>
            ${chemHtml}
            ${toolHtml}
          </div>
          <div class="recipe-btn ${canCraft ? '' : 'disabled'}">${canCraft ? '合成' : '🔒'}</div>
        </div>`;
    }

    html += '</div>';
  }

  html += `<div class="craft-close-btn" id="craft-close-btn">关闭 (Tab/Esc)</div>`;

  panel.innerHTML = html;

  // 绘制配方图标
  panel.querySelectorAll('.recipe-icon-canvas').forEach(cv => {
    const bid = parseInt(cv.dataset.block);
    const c = cv.getContext('2d');
    drawBlockIcon(c, 0, 0, 32, bid);
  });

  // 绑定合成按钮
  panel.querySelectorAll('.recipe-card[data-idx]').forEach(card => {
    card.addEventListener('click', () => {
      const idx = parseInt(card.dataset.idx);
      craftRecipe(RECIPES[idx]);
    });
  });

  // 关闭按钮
  const closeBtn = document.getElementById('craft-close-btn');
  if (closeBtn) {
    closeBtn.addEventListener('click', () => { game.craftingOpen = false; });
  }
  // 标题栏关闭按钮（✕）
  const closeX = document.getElementById('craft-close-x');
  if (closeX) {
    closeX.addEventListener('click', () => { game.craftingOpen = false; });
  }
}

function craftRecipe(r) {
  // 再次检查
  if (r.needs === 'workbench' && !hasCraftingStation('workbench')) { showToast('需要工作台！', 1000); return; }
  if (r.needs === 'furnace' && !hasCraftingStation('furnace')) { showToast('需要熔炉！', 1000); return; }
  for (const [id, count] of Object.entries(r.input)) {
    if ((game.inventory[parseInt(id)] || 0) < count) { showToast('材料不足！', 1000); return; }
  }

  // 消耗材料
  for (const [id, count] of Object.entries(r.input)) {
    removeItem(parseInt(id), count);
  }
  // 获得产物
  for (const [id, count] of Object.entries(r.output)) {
    addItem(parseInt(id), count);
  }
  sfx(r.needs === 'furnace' ? 'smelt' : 'craft');
  showToast(`合成成功：${r.name}！`, 1500);
  updateHotbar();
  game.craftingDirty = true;
}

// ==================== 背包界面 ====================
function drawInventory() {
  const overlay = document.getElementById('inventory-overlay');
  const panel = document.getElementById('inventory-panel');
  overlay.style.display = 'flex';

  const items = Object.entries(game.inventory).filter(([id, c]) => c > 0);

  let html = '<div class="inv-title"><span>🎒 背包</span><span class="inv-close-x" id="inv-close-x" title="关闭">✕</span></div>';

  if (items.length === 0) {
    html += '<div class="inv-empty">背包空空如也<br>去挖掘收集资源吧！</div>';
  } else {
    html += '<div class="inv-grid">';
    for (const [id, count] of items) {
      const blockId = parseInt(id);
      const block = BLOCKS[blockId];
      if (!block) continue;
      const inHotbar = game.hotbar.includes(blockId);
      const element = BLOCK_ELEMENTS[blockId];
      const elemInfo = element ? ELEMENT_INFO[element] : null;

      html += `<div class="inv-slot ${inHotbar ? 'in-hotbar' : ''}" data-id="${blockId}">`;
      if (elemInfo) {
        html += `<div class="inv-slot-elem" style="background:${elemInfo.color}"></div>`;
      }
      html += `<canvas class="inv-icon-canvas" width="32" height="32" data-block="${blockId}"></canvas>`;
      html += `<div class="inv-slot-name">${block.name}</div>`;
      html += `<div class="inv-slot-count">${count}</div>`;
      html += `<button class="inv-discard" data-id="${blockId}" title="丢弃 1 个">🗑</button>`;
      html += '</div>';
    }
    html += '</div>';
  }

  // 热栏展示
  html += '<div class="inv-hotbar-section">';
  html += '<div class="inv-hotbar-title">⬇ 热栏（点击背包物品切换到热栏）</div>';
  html += '<div class="inv-hotbar-grid">';
  for (let i = 0; i < 10; i++) {
    const blockId = game.hotbar[i];
    const isSelected = i === game.selectedSlot;
    html += `<div class="inv-hotbar-slot ${isSelected ? 'selected' : ''}" data-slot="${i}">`;
    html += `<span class="inv-hotbar-num">${i === 9 ? '0' : i + 1}</span>`;
    if (blockId > 0 && game.hotbarCounts[i] > 0) {
      html += `<canvas class="inv-hotbar-icon" width="32" height="32" data-block="${blockId}"></canvas>`;
    }
    html += '</div>';
  }
  html += '</div>';
  html += '</div>';

  html += '<div class="inv-close-btn" id="inv-close-btn">关闭背包 (E)</div>';

  panel.innerHTML = html;

  // 绘制物品图标
  panel.querySelectorAll('.inv-icon-canvas').forEach(cv => {
    const bid = parseInt(cv.dataset.block);
    const c = cv.getContext('2d');
    drawBlockIcon(c, 0, 0, 32, bid);
  });
  panel.querySelectorAll('.inv-hotbar-icon').forEach(cv => {
    const bid = parseInt(cv.dataset.block);
    const c = cv.getContext('2d');
    drawBlockIcon(c, 0, 0, 32, bid);
  });

  // 点击物品 → 切换到热栏
  panel.querySelectorAll('.inv-slot[data-id]').forEach(slot => {
    slot.addEventListener('click', () => {
      const blockId = parseInt(slot.dataset.id);
      toggleHotbarItem(blockId);
      game.inventoryDirty = true;
      drawInventory();
    });
  });

  // 丢弃按钮（手机/桌面通用）：点一下丢 1 个
  panel.querySelectorAll('.inv-discard[data-id]').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation(); // 不触发“切换热栏”
      const blockId = parseInt(btn.dataset.id);
      discardItem(blockId, 1);
    });
  });

  // 桌面右键丢弃：右键丢 1 个，Shift+右键清空
  panel.querySelectorAll('.inv-slot[data-id]').forEach(slot => {
    slot.addEventListener('contextmenu', (e) => {
      e.preventDefault();
      const blockId = parseInt(slot.dataset.id);
      const all = e.shiftKey ? Infinity : 1;
      discardItem(blockId, all);
    });
  });

  // 点击热栏槽 → 选中
  panel.querySelectorAll('.inv-hotbar-slot[data-slot]').forEach(slot => {
    slot.addEventListener('click', () => {
      const s = parseInt(slot.dataset.slot);
      if (game.hotbar[s] > 0) {
        game.selectedSlot = s;
        sfx('click');
        drawInventory();
      }
    });
  });

  // 关闭按钮
  const closeBtn = document.getElementById('inv-close-btn');
  if (closeBtn) {
    closeBtn.addEventListener('click', () => {
      game.inventoryOpen = false;
    });
  }
  // 标题栏关闭按钮（✕）
  const closeX = document.getElementById('inv-close-x');
  if (closeX) {
    closeX.addEventListener('click', () => { game.inventoryOpen = false; });
  }
}

// 将物品切换进/出热栏
function toggleHotbarItem(blockId) {
  const existingSlot = game.hotbar.indexOf(blockId);
  if (existingSlot >= 0) {
    // 已在热栏中 → 从热栏移除
    game.hotbar[existingSlot] = 0;
    game.hotbarCounts[existingSlot] = 0;
    sfx('click');
  } else {
    // 不在热栏 → 找空槽放入
    const emptySlot = game.hotbar.indexOf(0);
    if (emptySlot >= 0) {
      game.hotbar[emptySlot] = blockId;
      game.hotbarCounts[emptySlot] = game.inventory[blockId] || 0;
      sfx('pickup');
    } else {
      showToast('热栏已满！', 1000);
    }
  }
}

// ==================== 背包管理 ====================
function addItem(id, count) {
  game.inventory[id] = (game.inventory[id] || 0) + count;
  // 自动加入热栏
  let slot = game.hotbar.indexOf(id);
  if (slot === -1) {
    slot = game.hotbar.indexOf(0);
    if (slot !== -1) {
      game.hotbar[slot] = id;
    }
  }
  if (slot !== -1) {
    game.hotbarCounts[slot] = (game.hotbarCounts[slot] || 0) + count;
  }
  game.inventoryDirty = true;
  game.craftingDirty = true;
}

function removeItem(id, count) {
  if (!game.inventory[id]) return;
  game.inventory[id] -= count;
  if (game.inventory[id] < 0) game.inventory[id] = 0;
  // 从热栏扣除
  let remaining = count;
  for (let i = 0; i < game.hotbar.length && remaining > 0; i++) {
    if (game.hotbar[i] === id) {
      const take = Math.min(remaining, game.hotbarCounts[i]);
      game.hotbarCounts[i] -= take;
      remaining -= take;
      if (game.hotbarCounts[i] <= 0) game.hotbar[i] = 0;
    }
  }
  game.inventoryDirty = true;
  game.craftingDirty = true;
}

// 在玩家朝向 2 格处生成掉落物（用于丢弃/甩落）。硫磺弹会被标记为可引爆。
function dropAtFacing(id, count) {
  const p = game.player;
  const f = p.facing || 1;
  const tx = Math.floor((p.x + p.w / 2) / TILE) + f * 2;
  const ty = Math.floor((p.y + p.h / 2) / TILE);
  const x = tx * TILE + TILE / 2;
  const y = ty * TILE + TILE / 2;
  const isBomb = (id === 52);
  if (isBomb) {
    const n = Math.min(count, 16); // 限制同时引爆数量，避免卡顿
    for (let k = 0; k < n; k++) {
      game.droppedItems.push({
        x: x + (Math.random() - 0.5) * 14,
        y: y + (Math.random() - 0.5) * 14,
        id, count: 1,
        vx: (Math.random() - 0.5) * 2, vy: -2,
        life: 2000, noPickup: true, isBomb: true, fuse: 800,
      });
    }
  } else {
    game.droppedItems.push({ x, y, id, count, vx: 0, vy: 0, life: 60000 }); // 60 秒内可重新捡起
  }
}

// 丢弃物品：直接在玩家朝向 2 格处落地为可拾取掉落物（不再凭空消失）
// count 不传则丢弃 1 个；传 Infinity 则全部丢弃。硫磺弹丢弃后会引爆。
function discardItem(id, count) {
  const have = game.inventory[id] || 0;
  if (have <= 0) return;
  const isBomb = (id === 52);
  const maxN = isBomb ? 16 : have; // 硫磺弹限制单次引爆数量
  const n = Math.min(count == null ? 1 : count, have, maxN);
  removeItem(id, n);
  dropAtFacing(id, n);
  const name = BLOCKS[id] ? BLOCKS[id].name : '物品';
  showToast(isBomb ? `💣 丢弃 ${name} ×${n}（即将引爆）` : `🗑 丢弃 ${name} ×${n}`, 900);
  sfx('click');
  game.inventoryDirty = true;
  if (game.inventoryOpen) drawInventory();
}

// 甩落当前手持物品：从热栏扣 1 个，朝玩家面向 2 格处抛出为掉落物（可再拾取）
function dropSelected() {
  const slot = game.selectedSlot;
  const id = game.hotbar[slot];
  if (!id || game.hotbarCounts[slot] <= 0) return;
  const p = game.player;
  const f = p.facing || 1;
  const tx = Math.floor((p.x + p.w / 2) / TILE) + f * 2;
  const ty = Math.floor((p.y + p.h / 2) / TILE);
  removeItem(id, 1);
  const isBomb = (id === 52);
  game.droppedItems.push({
    x: tx * TILE + TILE / 2,
    y: ty * TILE + TILE / 2,
    id: id,
    count: 1,
    vx: f * 4,
    vy: -4,
    life: isBomb ? 2000 : 60000,
    noPickup: isBomb,
    isBomb: isBomb,
    fuse: isBomb ? 800 : 0,
  });
  sfx(isBomb ? 'lava' : 'drop', { pan: audioPan(p.x + p.w / 2) });
}

// 爆炸：摧毁半径内方块、按距离伤害玩家与敌人、产生粒子反馈
function explode(cx, cy, R) {
  const ctx0 = Math.floor(cx / TILE), cty0 = Math.floor(cy / TILE);
  for (let y = cty0 - R; y <= cty0 + R; y++) {
    for (let x = ctx0 - R; x <= ctx0 + R; x++) {
      if (x < 0 || y < 0 || x >= WORLD_W || y >= WORLD_H) continue;
      const d = Math.hypot(x - ctx0, y - cty0);
      if (d > R) continue;
      const t = getTile(x, y);
      if (t !== 0 && t !== 12 && t !== 63) { setTile(x, y, 0); syncBlockChange(x, y, 0); } // 液体保留，其余炸空
    }
  }
  // 玩家伤害（按距离衰减）
  const p = game.player;
  const pd = Math.hypot((p.x + p.w / 2) - cx, (p.y + p.h / 2) - cy);
  const reach = (R + 1) * TILE;
  if (pd < reach && p.invuln <= 0) {
    const dmg = Math.round(16 * (1 - pd / reach));
    if (dmg > 0) {
      p.health -= dmg;
      p.invuln = 800;
      p.lastDamageTime = performance.now();
      const ang = Math.atan2((p.y + p.h / 2) - cy, (p.x + p.w / 2) - cx);
      p.vx = Math.cos(ang) * 8; p.vy = Math.sin(ang) * 8 - 4;
      sfx('hurt');
    }
  }
  // 敌人伤害
  for (const e of game.enemies) {
    const ed = Math.hypot((e.x + e.w / 2) - cx, (e.y + e.h / 2) - cy);
    if (ed < reach) {
      e.health -= 60;
      if (e.health <= 0) sfx('enemyDie', { pan: audioPan(e.x + e.w / 2) });
      const ang = Math.atan2((e.y + e.h / 2) - cy, (e.x + e.w / 2) - cx);
      e.vx = Math.cos(ang) * 8; e.vy = Math.sin(ang) * 8 - 4;
    }
  }
  // 视觉反馈
  spawnParticles(cx, cy, '#ffcc44', 28);
  spawnParticles(cx, cy, '#ff5522', 18);
  spawnParticles(cx, cy, '#888888', 10);
  sfx('lava', { pan: audioPan(cx) });
}

// 睡床跳过夜晚：仅在夜晚可睡，睡后时间跳到早晨(time=0)
function sleepInBed() {
  if (game.time >= 0.5 && game.time < 0.95) {
    game.time = 0; // 跳到早晨
    showToast('💤 你睡了一觉，跳过了夜晚', 1500);
    sfx('click');
  } else {
    showToast('现在不是夜晚，无法入睡', 1200);
  }
}

function updateHotbar() {
  // 重建热栏数据
  const items = Object.entries(game.inventory).filter(([id, c]) => c > 0);
  game.hotbar = [0,0,0,0,0,0,0,0,0,0];
  game.hotbarCounts = [0,0,0,0,0,0,0,0,0,0];
  items.slice(0, 10).forEach(([id, count], i) => {
    game.hotbar[i] = parseInt(id);
    game.hotbarCounts[i] = count;
  });
  game.inventoryDirty = true;
  game.craftingDirty = true;
}

// ==================== UI 更新 ====================
function updatePlayerList() {
  const body = document.getElementById('player-list-body');
  const countEl = document.getElementById('player-count');
  if (!body || !countEl) return;

  const mp = game.multiplayer;
  let count = 0;
  let html = '';

  if (!mp.connected) {
    html = `<div class="player-list-item other"><span class="dot" style="background:#f80"></span>连接中...</div>`;
    countEl.textContent = '...';
    body.innerHTML = html;
    return;
  }

  // 自己
  if (game.nickname) {
    html += `<div class="player-list-item self"><span class="dot" style="background:#00d4ff"></span>${escapeHtml(game.nickname)} (我)</div>`;
    count++;
  }
  // 其他玩家
  for (const [id, rp] of mp.players) {
    if (id === mp.myId) continue;
    const nick = escapeHtml(rp.nickname || '玩家');
    const color = rp.hasPosition ? '#ff6b9d' : '#666';
    html += `<div class="player-list-item other"><span class="dot" style="background:${color}"></span>${nick}</div>`;
    count++;
  }

  body.innerHTML = html;
  countEl.textContent = count;
}

function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}

function updateUI() {
  // 在线玩家列表
  updatePlayerList();

  // 同步 body class（控制手机控件显隐）
  document.body.classList.toggle('crafting-open', game.craftingOpen);
  document.body.classList.toggle('inventory-open', game.inventoryOpen);
  document.body.classList.toggle('battle-open', game.battleOpen);

  const overlay = document.getElementById('crafting-overlay');
  if (!game.craftingOpen && overlay.style.display !== 'none') {
    overlay.style.display = 'none';
  } else if (game.craftingOpen) {
    if (game.craftingDirty || overlay.style.display === 'none') {
      overlay.style.display = 'flex';
      game.craftingDirty = false;
      drawCrafting();
    }
  }

  const invOverlay = document.getElementById('inventory-overlay');
  if (!game.inventoryOpen && invOverlay.style.display !== 'none') {
    invOverlay.style.display = 'none';
  } else if (game.inventoryOpen) {
    if (game.inventoryDirty || invOverlay.style.display === 'none') {
      invOverlay.style.display = 'flex';
      game.inventoryDirty = false;
      drawInventory();
    }
  }
}

// ==================== 卡牌对战系统 ====================
function openBattle(enemy) {
  game.battleTarget = enemy;
  game.battleCards = [];
  game.battleOpen = true;
  game.paused = true;
  game.battleAnimating = false;
  sfx('battle');
  drawBattle();
}

function closeBattle() {
  game.battleTarget = null;
  game.battleCards = [];
  game.battleOpen = false;
  game.battleAnimating = false;
  game.paused = false;
  game.battleCooldown = 500;
  const overlay = document.getElementById('battle-overlay');
  if (overlay) overlay.style.display = 'none';
}

// ==================== 元素发现系统 ====================
function showElementDiscovery(symbol) {
  const elem = PERIODIC_TABLE[symbol];
  if (!elem) return;

  game.elementPopupActive = true;
  const overlay = document.getElementById('element-overlay');
  const panel = document.getElementById('element-panel');
  if (!overlay || !panel) return;

  // 周期表分类颜色
  const catColors = {
    '非金属':       '#3acc5a',
    '过渡金属':     '#3a9bff',
    'post-transition': '#9b59b6',
    '类金属':       '#30d0d0',
  };
  const catColor = catColors[elem.category] || '#888';

  let html = '';
  html += '<div class="element-popup-header">';
  html += `<div class="element-discover-badge">🔬 新元素发现！</div>`;
  html += '</div>';

  html += '<div class="element-card-outer">';
  html += `<div class="element-card" style="border-color:${catColor};box-shadow:0 0 30px ${catColor}40">`;
  html += `<div class="element-number" style="color:${catColor}">${elem.number}</div>`;
  html += `<div class="element-symbol" style="color:${catColor}">${elem.symbol}</div>`;
  html += `<div class="element-name-cn">${elem.name}</div>`;
  html += `<div class="element-name-en">${elem.nameEn}</div>`;
  html += `<div class="element-mass">${elem.mass}</div>`;
  html += `</div>`;
  html += '</div>';

  html += '<div class="element-details">';
  html += `<div class="element-detail-row"><span class="detail-label">原子序数</span><span class="detail-val">${elem.number}</span></div>`;
  html += `<div class="element-detail-row"><span class="detail-label">元素符号</span><span class="detail-val" style="color:${catColor};font-weight:700">${elem.symbol}</span></div>`;
  html += `<div class="element-detail-row"><span class="detail-label">中文名称</span><span class="detail-val">${elem.name}</span></div>`;
  html += `<div class="element-detail-row"><span class="detail-label">英文名称</span><span class="detail-val">${elem.nameEn}</span></div>`;
  html += `<div class="element-detail-row"><span class="detail-label">相对原子质量</span><span class="detail-val">${elem.mass}</span></div>`;
  html += `<div class="element-detail-row"><span class="detail-label">元素分类</span><span class="detail-val" style="color:${catColor}">${elem.category}</span></div>`;
  html += `<div class="element-detail-row"><span class="detail-label">族 / 周期</span><span class="detail-val">第${elem.group}族 / 第${elem.period}周期</span></div>`;
  html += `<div class="element-detail-row"><span class="detail-label">电子构型</span><span class="detail-val" style="font-family:monospace;font-size:11px">${elem.config}</span></div>`;
  html += '</div>';

  html += `<div class="element-desc">${elem.desc}</div>`;

  // 已发现元素统计
  const total = Object.keys(PERIODIC_TABLE).length;
  const found = game.discoveredElements.size;
  html += `<div class="element-progress">已发现 ${found} / ${total} 种化学元素</div>`;

  html += '<div class="element-close-btn" id="element-close-btn">继续探索</div>';

  panel.innerHTML = html;
  overlay.style.display = 'flex';

  // 添加粒子庆祝效果
  const cx = game.cw / 2;
  const cy = game.ch / 2;
  for (let i = 0; i < 30; i++) {
    spawnParticles(cx, cy, catColor, 1);
  }
  sfx('discover');

  // 绑定关闭
  const closeBtn = document.getElementById('element-close-btn');
  if (closeBtn) {
    closeBtn.addEventListener('click', closeElementPopup);
  }
  overlay.addEventListener('click', function handler(e) {
    if (e.target === overlay) {
      closeElementPopup();
      overlay.removeEventListener('click', handler);
    }
  });
}

function closeElementPopup() {
  game.elementPopupActive = false;
  const overlay = document.getElementById('element-overlay');
  if (overlay) overlay.style.display = 'none';
}

function drawBattle() {
  const overlay = document.getElementById('battle-overlay');
  const panel = document.getElementById('battle-panel');
  if (!overlay || !panel) return;
  overlay.style.display = 'flex';

  const en = game.battleTarget;
  if (!en) { closeBattle(); return; }

  const enHpPct = Math.max(0, en.health / en.maxHealth);
  const pHpPct = Math.max(0, game.player.health / game.player.maxHealth);
  const enemyName = en.type === 'slime' ? '史莱姆' : '怪物';

  let html = '<div class="battle-title">⚔️ 元素对战</div>';

  // 敌人信息
  html += '<div class="battle-combatant">';
  html += `<span class="battle-combatant-name">🟢 ${enemyName}</span>`;
  html += `<div class="battle-hp-bar"><div class="battle-hp-fill" style="width:${enHpPct*100}%;background:#ff3333"></div><span class="battle-hp-text">${Math.ceil(en.health)}/${en.maxHealth}</span></div>`;
  html += '</div>';

  // 玩家信息
  html += '<div class="battle-combatant">';
  html += '<span class="battle-combatant-name">🧑 玩家</span>';
  html += `<div class="battle-hp-bar"><div class="battle-hp-fill" style="width:${pHpPct*100}%;background:#22cc44"></div><span class="battle-hp-text">${Math.ceil(game.player.health)}/${game.player.maxHealth}</span></div>`;
  html += '</div>';

  // 卡牌选择区
  html += '<div class="battle-section-title">📋 选择攻击卡牌（最多3种）</div>';
  html += '<div class="battle-cards">';

  let availableCards = 0;
  for (let i = 0; i < game.hotbar.length; i++) {
    const blockId = game.hotbar[i];
    const count = game.hotbarCounts[i];
    if (blockId === 0 || count <= 0) continue;
    availableCards++;
    const block = BLOCKS[blockId];
    const element = BLOCK_ELEMENTS[blockId];
    const elemInfo = element ? ELEMENT_INFO[element] : null;
    const selected = game.battleCards.includes(i);

    html += `<div class="battle-card ${selected ? 'selected' : ''}" data-slot="${i}" style="${selected ? 'border-color:' + (elemInfo ? elemInfo.color : '#00d4ff') : ''}">`;
    html += `<div class="battle-card-icon" style="background:${block.color}">${BLOCK_EMOJI[blockId] || '🧱'}</div>`;
    html += `<div class="battle-card-name">${block.name}</div>`;
    if (elemInfo) {
      html += `<div class="battle-card-elem" style="color:${elemInfo.color}">${elemInfo.icon} ${elemInfo.name}</div>`;
    } else {
      html += '<div class="battle-card-elem" style="color:#666">无属性</div>';
    }
    html += `<div class="battle-card-count">×${count}</div>`;
    html += '</div>';
  }

  if (availableCards === 0) {
    html += '<div class="battle-no-cards">背包中没有可用物品！<br>挖掘收集材料后再来挑战</div>';
  }
  html += '</div>';

  // 已选卡牌槽
  html += '<div class="battle-selected-area">';
  html += '<span class="battle-selected-label">已选卡牌：</span>';
  for (let s = 0; s < 3; s++) {
    if (s < game.battleCards.length) {
      const slot = game.battleCards[s];
      const blockId = game.hotbar[slot];
      const block = BLOCKS[blockId];
      const element = BLOCK_ELEMENTS[blockId];
      const elemInfo = element ? ELEMENT_INFO[element] : null;
      const borderColor = elemInfo ? elemInfo.color : '#666';
      html += `<div class="battle-selected-card" data-slot="${slot}" style="border-color:${borderColor}">`;
      html += `${BLOCK_EMOJI[blockId] || '🧱'} ${block.name}`;
      if (elemInfo) html += ` <span style="color:${elemInfo.color}">${elemInfo.icon}</span>`;
      html += '</div>';
    } else {
      html += '<div class="battle-selected-card empty">＋</div>';
    }
  }
  html += '</div>';

  // 元素反应检测
  const reaction = checkElementReaction();
  html += '<div class="battle-reaction">';
  if (reaction) {
    html += `<div class="reaction-found" style="border-color:${ELEMENT_INFO[reaction.a].color}">`;
    html += `✨ ${reaction.icon} <b>${reaction.name}</b> — ${reaction.desc}！<br>伤害 ×2`;
    html += '</div>';
  } else if (game.battleCards.length >= 2) {
    html += '<div class="reaction-none">⚪ 无元素反应，仅基础伤害</div>';
  } else if (game.battleCards.length === 1) {
    html += '<div class="reaction-hint">💡 再选1~2张卡牌可能触发元素反应</div>';
  } else {
    html += '<div class="reaction-hint">👆 点击上方卡牌选择攻击</div>';
  }
  html += '</div>';

  // 预计伤害
  if (game.battleCards.length > 0) {
    const baseDmg = game.battleCards.length * 10;
    const totalDmg = reaction ? baseDmg * 2 : baseDmg;
    html += `<div class="battle-damage">预计伤害：<b class="dmg-num">${totalDmg}</b>${reaction ? ' ✨含反应加成' : ''}</div>`;
  }

  // 按钮
  const canAttack = game.battleCards.length > 0 && !game.battleAnimating;
  const canPunch = !game.battleAnimating;
  html += '<div class="battle-buttons">';
  html += `<button class="battle-btn attack" ${canAttack ? '' : 'disabled'}>⚔️ 攻击</button>`;
  html += `<button class="battle-btn punch" ${canPunch ? '' : 'disabled'}>✊ 拳击(5)</button>`;
  html += `<button class="battle-btn flee" ${game.battleAnimating ? 'disabled' : ''}>🏃 逃跑</button>`;
  html += '</div>';

  // 元素反应速查
  html += '<details class="battle-cheatsheet"><summary>📖 元素反应速查</summary><div class="cheatsheet-grid">';
  for (const r of ELEMENT_REACTIONS) {
    const ea = ELEMENT_INFO[r.a];
    const eb = ELEMENT_INFO[r.b];
    html += `<div class="cheatsheet-item"><span style="color:${ea.color}">${ea.icon}${ea.name}</span> + <span style="color:${eb.color}">${eb.icon}${eb.name}</span> → <b>${r.icon} ${r.name}</b></div>`;
  }
  html += '</div></details>';

  panel.innerHTML = html;

  // 绑定事件
  panel.querySelectorAll('.battle-card[data-slot]').forEach(card => {
    card.addEventListener('click', () => {
      if (game.battleAnimating) return;
      const slot = parseInt(card.dataset.slot);
      toggleBattleCard(slot);
    });
  });
  panel.querySelectorAll('.battle-selected-card[data-slot]').forEach(card => {
    card.addEventListener('click', () => {
      if (game.battleAnimating) return;
      const slot = parseInt(card.dataset.slot);
      toggleBattleCard(slot);
    });
  });
  const atkBtn = panel.querySelector('.battle-btn.attack');
  if (atkBtn && !atkBtn.disabled) atkBtn.addEventListener('click', executeBattleAttack);
  const punchBtn = panel.querySelector('.battle-btn.punch');
  if (punchBtn && !punchBtn.disabled) punchBtn.addEventListener('click', executePunch);
  const fleeBtn = panel.querySelector('.battle-btn.flee');
  if (fleeBtn && !fleeBtn.disabled) fleeBtn.addEventListener('click', () => {
    closeBattle();
    showToast('逃跑成功！', 1000);
  });
}

function toggleBattleCard(slot) {
  const idx = game.battleCards.indexOf(slot);
  if (idx >= 0) {
    game.battleCards.splice(idx, 1);
  } else if (game.battleCards.length < 3) {
    game.battleCards.push(slot);
  }
  sfx('click');
  drawBattle();
}

function checkElementReaction() {
  if (game.battleCards.length < 2) return null;
  const elements = game.battleCards
    .map(slot => BLOCK_ELEMENTS[game.hotbar[slot]])
    .filter(e => e);
  for (let i = 0; i < elements.length; i++) {
    for (let j = i + 1; j < elements.length; j++) {
      const a = elements[i];
      const b = elements[j];
      for (const r of ELEMENT_REACTIONS) {
        if ((r.a === a && r.b === b) || (r.a === b && r.b === a)) {
          return r;
        }
      }
    }
  }
  return null;
}

function executeBattleAttack() {
  if (game.battleCards.length === 0 || game.battleAnimating) return;
  const en = game.battleTarget;
  if (!en) return;

  game.battleAnimating = true;

  // 计算伤害
  const baseDmg = game.battleCards.length * 10;
  const reaction = checkElementReaction();
  const totalDmg = reaction ? baseDmg * 2 : baseDmg;

  // 消耗物品
  game.battleCards.forEach(slot => {
    const blockId = game.hotbar[slot];
    removeItem(blockId, 1);
  });

  sfx('attack');

  // 粒子效果
  const ex = en.x + en.w / 2;
  const ey = en.y + en.h / 2;
  if (reaction) {
    spawnParticles(ex, ey, '#ffaa00', 20);
    spawnParticles(ex, ey, ELEMENT_INFO[reaction.a].color, 15);
    showToast(`✨ ${reaction.name}！伤害×2 → ${totalDmg}`, 1500);
  } else {
    spawnParticles(ex, ey, '#88ff44', 12);
    showToast(`攻击造成 ${totalDmg} 伤害`, 1000);
  }

  // 清空选牌
  game.battleCards = [];
  updateHotbar();

  // 判定：伤害 >= 怪物当前血量 → 击杀
  if (totalDmg >= en.health) {
    en.health = 0;
    drawBattle(); // 先显示血条归零

    setTimeout(() => {
      spawnParticles(ex, ey, '#44ff00', 25);
      game.droppedItems.push({ x: en.x, y: en.y, id: 7, count: 1, vy: -4, life: 600 });
      showToast('🎉 击败敌人！+1 煤矿', 1500);
      if (window.Sound) Sound.play('enemyDie', { pan: audioPan(ex) });
      const idx = game.enemies.indexOf(en);
      if (idx >= 0) game.enemies.splice(idx, 1);
      closeBattle();
    }, 800);
    return;
  }

  // 否则：怪物存活，扣血后反击玩家
  en.health -= totalDmg;
  drawBattle(); // 显示怪物扣血后的血条

  setTimeout(() => {
    if (!game.battleOpen || !game.battleTarget) { return; }
    const counterDmg = 6 + Math.floor(Math.random() * 6);
    game.player.health -= counterDmg;
    if (game.player.health < 0) game.player.health = 0;
    game.player.invuln = 800;
    game.player.lastDamageTime = performance.now();
    sfx('hurt');
    spawnParticles(
      game.player.x + game.player.w / 2,
      game.player.y + game.player.h / 2,
      '#ff3333', 10
    );
    showToast(`💥 敌人反击！-${counterDmg} HP`, 1000);
    drawBattle();

    if (game.player.health <= 0) {
      setTimeout(() => { closeBattle(); respawn(); }, 800);
      return;
    }

    // 准备下一轮
    game.battleAnimating = false;
    drawBattle();
  }, 700);
}

// 拳击：固定5伤害，不消耗物品
function executePunch() {
  if (game.battleAnimating) return;
  const en = game.battleTarget;
  if (!en) return;

  game.battleAnimating = true;
  const totalDmg = 5;
  sfx('attack');

  const ex = en.x + en.w / 2;
  const ey = en.y + en.h / 2;
  spawnParticles(ex, ey, '#aaaaaa', 8);
  showToast(`👊 拳击！造成 ${totalDmg} 伤害`, 1000);

  game.battleCards = [];
  drawBattle();

  if (totalDmg >= en.health) {
    en.health = 0;
    drawBattle();
    setTimeout(() => {
      spawnParticles(ex, ey, '#44ff00', 25);
      game.droppedItems.push({ x: en.x, y: en.y, id: 7, count: 1, vy: -4, life: 600 });
      showToast('🎉 击败敌人！+1 煤矿', 1500);
      const idx = game.enemies.indexOf(en);
      if (idx >= 0) game.enemies.splice(idx, 1);
      closeBattle();
    }, 800);
    return;
  }

  en.health -= totalDmg;
  drawBattle();

  setTimeout(() => {
    if (!game.battleOpen || !game.battleTarget) { return; }
    const counterDmg = 6 + Math.floor(Math.random() * 6);
    game.player.health -= counterDmg;
    if (game.player.health < 0) game.player.health = 0;
    game.player.invuln = 800;
    game.player.lastDamageTime = performance.now();
    sfx('hurt');
    spawnParticles(
      game.player.x + game.player.w / 2,
      game.player.y + game.player.h / 2,
      '#ff3333', 10
    );
    showToast(`💥 敌人反击！-${counterDmg} HP`, 1000);
    drawBattle();

    if (game.player.health <= 0) {
      setTimeout(() => { closeBattle(); respawn(); }, 800);
      return;
    }

    game.battleAnimating = false;
    drawBattle();
  }, 700);
}

// ==================== 工具函数 ====================
function lerp(a, b, t) { return a + (b - a) * t; }

let toastEl = null;
let toastTimer = null;
function showToast(msg, duration = 2000) {
  if (!toastEl) {
    toastEl = document.getElementById('game-toast');
  }
  toastEl.textContent = msg;
  toastEl.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toastEl.classList.remove('show'), duration);
}

// ==================== 音效 ====================
// 统一接入 audio.js 的 Sound 引擎（总线 / 程序化合成 / 空间化 / 动态音乐）
function sfx(type, opts) {
  if (window.Sound) Sound.play(type, opts || {});
}

// 根据世界 X 坐标相对玩家计算声像 [-1,1]（屏幕空间立体声定位）
function audioPan(worldX) {
  const p = game.player;
  if (!p) return 0;
  const range = (game.cw || 800) * 0.6;
  return Math.max(-1, Math.min(1, (worldX - (p.x + p.w / 2)) / range));
}

// ==================== 联机系统 ====================

function isWeChatMiniProgram() {
  return /miniProgram/i.test(navigator.userAgent) || 
         window.__wxjs_environment === 'miniprogram';
}

// 连接 WebSocket 服务器
function connectMultiplayer() {
  if (game.multiplayer.ws && game.multiplayer.ws.readyState <= 1) {
    game.multiplayer.ws.close();
  }
  game.multiplayer.kicked = false;

  const wsUrl = location.protocol === 'https:'
    ? `wss://${location.host}/ws`
    : `ws://${location.hostname}:8080`;

  showToast('正在连接服务器...', 3000);
  console.log('[联机] 尝试连接:', wsUrl, '环境:', isWeChatMiniProgram() ? '微信小程序' : '浏览器');

  try {
    const ws = new WebSocket(wsUrl);
    game.multiplayer.ws = ws;
    game.multiplayer.connected = false;

    let connected = false;

    ws.onopen = () => {
      connected = true;
      game.multiplayer.connected = true;
      game.multiplayer.reconnectDelay = 0;
      console.log('[联机] WebSocket已连接, 发送join:', game.nickname);
      ws.send(JSON.stringify({ type: 'join', nickname: game.nickname || '玩家' }));
      showToast('已连接', 1500);
    };

    ws.onmessage = (e) => {
      let msg;
      try { msg = JSON.parse(e.data); } catch { return; }
      handleMultiplayerMessage(msg);
    };

    ws.onclose = () => {
      if (game.multiplayer.ws !== ws) return;
      console.log('[联机] 连接关闭, connected=', connected);
      const wasConnected = game.multiplayer.connected;
      game.multiplayer.connected = false;
      game.multiplayer.myId = null;
      game.multiplayer.players.clear();
      if (game.multiplayer.kicked) {
        game.multiplayer.kicked = false;
        return;
      }
      // 微信小程序 WebSocket 可能直接失败，回退到 HTTP 轮询
      if (!connected && isWeChatMiniProgram()) {
        console.log('[联机] 微信环境 WebSocket 失败，尝试 HTTP 轮询');
        showToast('WebSocket 不可用，切换 HTTP 模式...', 3000);
        startHttpPolling();
        return;
      }
      if (wasConnected) showToast('已断开连接，正在重连...', 2500);
      game.multiplayer.reconnectDelay = (game.multiplayer.reconnectDelay || 0) + 3000;
      setTimeout(() => {
        if (!game.multiplayer.connected) connectMultiplayer();
      }, Math.min(game.multiplayer.reconnectDelay, 15000));
    };

    ws.onerror = (e) => {
      console.log('[联机] WebSocket 错误:', e);
    };

    // 5秒内没连上，微信环境自动切换
    setTimeout(() => {
      if (!connected && !game.multiplayer.connected && isWeChatMiniProgram()) {
        console.log('[联机] 5秒内未连接，微信环境切换 HTTP 模式');
        try { ws.close(); } catch(e) {}
      }
    }, 5000);

  } catch (e) {
    console.warn('WebSocket 创建失败:', e);
    game.multiplayer.connected = false;
    if (isWeChatMiniProgram()) {
      showToast('WebSocket 不可用，使用 HTTP 模式...', 3000);
      startHttpPolling();
    }
  }
}

// HTTP 轮询模式（微信小程序备选）
function startHttpPolling() {
  const baseUrl = location.protocol === 'https:'
    ? `${location.protocol}//${location.host}`
    : `${location.protocol}//${location.hostname}:8080`;
  
  let myId = null;
  let pollTimer = null;
  let sendTimer = null;
  game.multiplayer.httpMode = true;

  async function httpPost(path, data) {
    try {
      const res = await fetch(baseUrl + path, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });
      return await res.json();
    } catch (e) {
      console.warn('[HTTP] 请求失败:', path, e);
      return null;
    }
  }

  async function join() {
    const res = await httpPost('/api/join', { nickname: game.nickname || '玩家' });
    if (res) {
      myId = res.id;
      game.multiplayer.myId = myId;
      game.multiplayer.connected = true;
      // 用服务端种子重建世界（与 WebSocket 模式一致）
      if (typeof res.seed === 'number' && res.seed !== game.worldSeed) {
        console.log('[HTTP] 用服务端种子重建世界:', res.seed);
        setupWorld(res.seed);
      }
      console.log('[HTTP] 已加入, id=', myId, '在线:', (res.players || []).length);
      for (const p of (res.players || [])) {
        game.multiplayer.players.set(p.id, {
          nickname: p.nickname, x: p.x, y: p.y, rx: p.x, ry: p.y,
          vx: p.vx, vy: p.vy, facing: p.facing,
          walkPhase: p.walkPhase, health: p.health, hasPosition: true,
        });
      }
      showToast('已连接 (HTTP模式)', 2000);
    }
  }

  async function poll() {
    if (!game.multiplayer.connected || !myId) return;
    const data = await httpPost('/api/poll', { id: myId });
    if (!data) return;
    for (const msg of (data.messages || [])) {
      handleMultiplayerMessage(msg);
    }
    // 更新其他玩家列表（跳过自己）
    if (data.players) {
      for (const [id, p] of game.multiplayer.players) {
        if (id === myId) continue;
        if (!data.players.find(pl => pl.id === id)) {
          game.multiplayer.players.delete(id);
        }
      }
      for (const p of data.players) {
        if (p.id === myId) continue;
        if (!game.multiplayer.players.has(p.id)) {
          game.multiplayer.players.set(p.id, {
            nickname: p.nickname, x: p.x, y: p.y, rx: p.x, ry: p.y,
            vx: p.vx, vy: p.vy, facing: p.facing,
            walkPhase: p.walkPhase, health: p.health, hasPosition: true,
          });
        }
      }
    }
  }

  async function sendPosition() {
    if (!game.multiplayer.connected || !myId) return;
    const p = game.player;
    await httpPost('/api/move', {
      id: myId,
      x: p.x, y: p.y, vx: p.vx, vy: p.vy,
      facing: p.facing, walkPhase: p.walkPhase, health: p.health,
    });
  }

  join();
  pollTimer = setInterval(poll, 500);
  sendTimer = setInterval(sendPosition, 100);

  game.multiplayer.httpSend = sendPosition;
  game.multiplayer.httpPoll = poll;
}

// 处理服务器消息
function handleMultiplayerMessage(msg) {
  const mp = game.multiplayer;
  switch (msg.type) {
    case 'welcome':
      mp.myId = msg.id;
      // 用服务端下发的种子重建世界，确保与同房间的其他玩家世界完全一致
      if (typeof msg.seed === 'number' && msg.seed !== game.worldSeed) {
        console.log('[联机] 用服务端种子重建世界:', msg.seed);
        setupWorld(msg.seed);
        showToast('联机世界种子: ' + msg.seed, 2500);
      }
      console.log('[联机] 收到welcome, myId=', msg.id, '在线玩家数=', (msg.players || []).length);
      for (const p of (msg.players || [])) {
        mp.players.set(p.id, {
          nickname: p.nickname,
          x: p.x, y: p.y, rx: p.x, ry: p.y,
          vx: p.vx, vy: p.vy, facing: p.facing,
          walkPhase: p.walkPhase, health: p.health,
          hasPosition: true,
        });
        console.log('[联机] 已加入玩家:', p.nickname, 'id=', p.id);
      }
      break;

    case 'join':
      console.log('[联机] 新玩家加入:', msg.nickname, 'id=', msg.id);
      mp.players.set(msg.id, {
        nickname: msg.nickname,
        x: 0, y: 0, rx: 0, ry: 0,
        vx: 0, vy: 0, facing: 1, walkPhase: 0, health: 100,
        hasPosition: false,
      });
      showToast(`${msg.nickname} 加入了游戏`, 1500);
      break;

    case 'leave': {
      const rp = mp.players.get(msg.id);
      if (rp) {
        showToast(`${rp.nickname} 离开了游戏`, 1500);
        mp.players.delete(msg.id);
      }
      break;
    }

    case 'move': {
      let rp = mp.players.get(msg.id);
      if (!rp) {
        rp = { nickname: '玩家', x: msg.x, y: msg.y, hasPosition: false };
        mp.players.set(msg.id, rp);
      }
      rp.rx = msg.x;
      rp.ry = msg.y;
      rp.vx = msg.vx;
      rp.vy = msg.vy;
      rp.facing = msg.facing;
      rp.walkPhase = msg.walkPhase;
      rp.health = msg.health;
      if (!rp.hasPosition) {
        rp.x = msg.x;
        rp.y = msg.y;
        rp.hasPosition = true;
      }
      break;
    }

    case 'block':
      // 应用其他玩家的方块变更
      setTile(msg.tx, msg.ty, msg.tileId);
      if (msg.tileId === 0) {
        spawnParticles(msg.tx * TILE + TILE / 2, msg.ty * TILE + TILE / 2, '#aaa', 6);
      } else {
        spawnParticles(msg.tx * TILE + TILE / 2, msg.ty * TILE + TILE / 2, '#fff', 4);
      }
      break;

    case 'kick':
      game.multiplayer.kicked = true;
      showToast(msg.reason || '你已被踢出', 4000);
      break;
  }
}

// 发送方块变更给服务器
function syncBlockChange(tx, ty, tileId) {
  const mp = game.multiplayer;
  if (!mp.connected) return;
  if (mp.ws && mp.ws.readyState === 1) {
    mp.ws.send(JSON.stringify({ type: 'block', tx, ty, tileId }));
  } else if (mp.httpMode && mp.myId !== null) {
    fetch(`${location.protocol}//${location.hostname}:8080/api/block`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id: mp.myId, tx, ty, tileId }),
    }).catch(() => {});
  }
}

// 更新远程玩家（插值平滑移动）
function updateRemotePlayers(dt) {
  const mp = game.multiplayer;
  const lerpFactor = 0.25;
  const dts = dt / 16.67;
  for (const [id, rp] of mp.players) {
    if (id === mp.myId || !rp.hasPosition) continue;
    // 位置插值
    rp.x += (rp.rx - rp.x) * lerpFactor;
    rp.y += (rp.ry - rp.y) * lerpFactor;
    // 走路动画推进
    if (Math.abs(rp.vx) > 0.5) {
      rp.walkPhase += dts * 0.3;
    }
  }
}

// 绘制其他联机玩家
function drawOtherPlayers(ctx) {
  const mp = game.multiplayer;
  for (const [id, rp] of mp.players) {
    if (id === mp.myId || !rp.hasPosition) continue;

    const sx = rp.x - game.camX;
    const sy = rp.y - game.camY;
    const w = 18, h = 36;

    // 屏幕外跳过
    if (sx < -60 || sx > game.cw + 60 || sy < -60 || sy > game.ch + 60) continue;

    ctx.save();

    // 走路动画
    const walkOffset = Math.abs(rp.vx) > 0.5 ? Math.sin(rp.walkPhase * 10) * 2 : 0;

    // 身体（粉红色区分其他玩家）
    ctx.fillStyle = '#b83a6a';
    ctx.fillRect(sx + 2, sy + 10 + walkOffset, w - 4, h - 14);

    // 头
    ctx.fillStyle = '#e8b888';
    ctx.fillRect(sx + 3, sy, w - 6, 12);

    // 头发
    ctx.fillStyle = '#3a2a1a';
    ctx.fillRect(sx + 3, sy, w - 6, 4);

    // 眼睛
    ctx.fillStyle = '#222';
    if (rp.facing > 0) {
      ctx.fillRect(sx + 9, sy + 6, 2, 2);
    } else {
      ctx.fillRect(sx + 7, sy + 6, 2, 2);
    }

    // 腿
    ctx.fillStyle = '#8a2a4a';
    ctx.fillRect(sx + 2, sy + h - 6 + walkOffset, 6, 6);
    ctx.fillRect(sx + w - 8, sy + h - 6 - walkOffset, 6, 6);

    ctx.restore();

    // 头顶用户名
    ctx.font = 'bold 11px sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    const tw = ctx.measureText(rp.nickname).width;
    const nx = sx + w / 2;
    const ny = sy - 14;
    ctx.fillStyle = 'rgba(0,0,0,0.6)';
    ctx.fillRect(nx - tw / 2 - 4, ny - 8, tw + 8, 16);
    ctx.fillStyle = '#fff';
    ctx.fillText(rp.nickname, nx, ny);

    // 血条（受伤时显示）
    if (rp.health < 100) {
      ctx.fillStyle = 'rgba(0,0,0,0.5)';
      ctx.fillRect(sx, sy - 30, w, 3);
      ctx.fillStyle = '#ff3333';
      ctx.fillRect(sx, sy - 30, w * (rp.health / 100), 3);
    }
  }
}

// ==================== 启动 ====================
window.addEventListener('load', () => {
  const params = new URLSearchParams(location.search);
  const urlNick = params.get('nickname');
  const ov = document.getElementById('nickname-overlay');
  const input = document.getElementById('nickname-input');
  const btn = document.getElementById('nickname-confirm');

  function startGame(nick) {
    const name = (nick || '').trim();
    if (!name) { if (input) input.focus(); return; }
    game.nickname = name.slice(0, 16);
    if (btn) btn.blur();
    if (ov) ov.classList.add('hidden');
    init();
  }

  if (urlNick && urlNick.trim()) {
    startGame(urlNick);
  } else {
    if (input) input.focus();
    if (btn) btn.addEventListener('click', () => startGame(input ? input.value : ''));
    if (input) input.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') startGame(input.value);
    });
  }
});

})();
