/**
 * 像素沙盒联机服务端
 * 支持 WebSocket 和 HTTP 轮询双模式
 * 
 * 宝塔/1Panel 部署：
 *   1. 将 server/ 目录上传到服务器
 *   2. cd server && npm install
 *   3. node server.js  (或用 pm2: pm2 start server.js --name pixel-sandbox)
 *   4. Nginx 反向代理配置（加到网站配置的 server 块内）：
 *
 *   location /ws {
 *       proxy_pass http://127.0.0.1:8080;
 *       proxy_http_version 1.1;
 *       proxy_set_header Upgrade $http_upgrade;
 *       proxy_set_header Connection "upgrade";
 *       proxy_set_header Host $host;
 *       proxy_read_timeout 86400;
 *   }
 *
 *   location /api/ {
 *       proxy_pass http://127.0.0.1:8080;
 *   }
 */
const WebSocket = require('ws');
const http = require('http');

const PORT = process.env.PORT || 8080;
// 世界种子：固定值，保证所有客户端（含联机）世界一致
const WORLD_SEED = 7777;
const IDLE_TIMEOUT = 60000;

const players = new Map(); // id -> { ws, nickname, x, y, vx, vy, facing, walkPhase, health, lastActive, messages: [] }
let nextId = 1;

function broadcast(msg, exceptId) {
  const data = JSON.stringify(msg);
  for (const [id, p] of players) {
    if (id !== exceptId && p.ws && p.ws.readyState === WebSocket.OPEN) {
      p.ws.send(data);
    }
    // HTTP 模式玩家需要把消息存入队列
    if (id !== exceptId && !p.ws) {
      p.messages = p.messages || [];
      p.messages.push(msg);
    }
  }
}

function sendTo(id, msg) {
  const p = players.get(id);
  if (!p) return;
  if (p.ws && p.ws.readyState === WebSocket.OPEN) {
    p.ws.send(JSON.stringify(msg));
  } else {
    p.messages = p.messages || [];
    p.messages.push(msg);
  }
}

function getPlayerList(excludeId) {
  const list = [];
  for (const [id, p] of players) {
    if (id !== excludeId) {
      list.push({
        id, nickname: p.nickname,
        x: p.x, y: p.y, vx: p.vx, vy: p.vy,
        facing: p.facing, walkPhase: p.walkPhase, health: p.health,
      });
    }
  }
  return list;
}

// HTTP 服务器（同时处理 API 和 WebSocket 升级）
const server = http.createServer((req, res) => {
  // CORS
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    res.writeHead(200);
    res.end();
    return;
  }

  const url = req.url.split('?')[0];
  
  if (req.method === 'POST') {
    let body = '';
    req.on('data', chunk => body += chunk);
    req.on('end', () => {
      let data;
      try { data = JSON.parse(body); } catch {
        res.writeHead(400); res.end('Invalid JSON'); return;
      }
      handleHttpApi(url, data, res);
    });
  } else {
    res.writeHead(404);
    res.end('Not Found');
  }
});

function handleHttpApi(path, data, res) {
  switch (path) {
    case '/api/join': {
      const nickname = String(data.nickname || '玩家').trim().slice(0, 16);
      const id = nextId++;
      players.set(id, {
        ws: null, nickname,
        x: 0, y: 0, vx: 0, vy: 0, facing: 1, walkPhase: 0, health: 100,
        lastActive: Date.now(), messages: [],
      });
      broadcast({ type: 'join', id, nickname }, id);
      console.log(`[HTTP join] id=${id} nickname=${nickname} (${players.size} online)`);
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ id, seed: WORLD_SEED, players: getPlayerList(id) }));
      break;
    }
    case '/api/move': {
      const p = players.get(data.id);
      if (!p) { res.writeHead(404); res.end('Not found'); return; }
      p.x = data.x; p.y = data.y;
      p.vx = data.vx; p.vy = data.vy;
      p.facing = data.facing; p.walkPhase = data.walkPhase;
      p.health = data.health;
      p.lastActive = Date.now();
      broadcast({ type: 'move', id: data.id, ...data }, data.id);
      res.writeHead(200); res.end('OK');
      break;
    }
    case '/api/block': {
      const p = players.get(data.id);
      if (p) p.lastActive = Date.now();
      broadcast({ type: 'block', id: data.id, tx: data.tx, ty: data.ty, tileId: data.tileId }, data.id);
      res.writeHead(200); res.end('OK');
      break;
    }
    case '/api/poll': {
      const p = players.get(data.id);
      if (!p) { res.writeHead(404); res.end('Not found'); return; }
      p.lastActive = Date.now();
      // 返回积压的消息和当前玩家列表
      const messages = p.messages || [];
      p.messages = [];
      const playerList = getPlayerList(data.id);
      // 如果玩家列表显示需要自己
      playerList.unshift({
        id: data.id, nickname: p.nickname,
        x: p.x, y: p.y, vx: p.vx, vy: p.vy,
        facing: p.facing, walkPhase: p.walkPhase, health: p.health,
      });
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ messages, players: playerList }));
      break;
    }
    default:
      res.writeHead(404); res.end('Not Found');
  }
}

// WebSocket 服务器绑定到 HTTP server
const wss = new WebSocket.Server({ server });

wss.on('connection', (ws) => {
  const id = nextId++;
  console.log(`[connect] id=${id}`);

  ws.on('message', (raw) => {
    let msg;
    try { msg = JSON.parse(raw); } catch { return; }

    // 任何消息都视为活跃
    const p = players.get(id);
    if (p) p.lastActive = Date.now();

    switch (msg.type) {
      case 'join': {
        const nickname = String(msg.nickname || '玩家').trim().slice(0, 16);
        players.set(id, {
          ws, nickname,
          x: 0, y: 0, vx: 0, vy: 0, facing: 1, walkPhase: 0, health: 100,
          lastActive: Date.now(), messages: [],
        });

        // 发送欢迎消息：自己的ID、世界种子、当前在线玩家列表
        const playerList = [];
        for (const [pid, p] of players) {
          if (pid !== id) {
            playerList.push({
              id: pid, nickname: p.nickname,
              x: p.x, y: p.y, vx: p.vx, vy: p.vy,
              facing: p.facing, walkPhase: p.walkPhase, health: p.health,
            });
          }
        }
        sendTo(id, { type: 'welcome', id, seed: WORLD_SEED, players: playerList });

        // 通知其他人有新玩家加入
        broadcast({ type: 'join', id, nickname }, id);
        console.log(`[join] id=${id} nickname=${nickname} (${players.size} online)`);
        break;
      }
      case 'move': {
        const p = players.get(id);
        if (!p) return;
        p.x = msg.x; p.y = msg.y;
        p.vx = msg.vx; p.vy = msg.vy;
        p.facing = msg.facing; p.walkPhase = msg.walkPhase;
        p.health = msg.health;
        p.lastActive = Date.now();
        broadcast({ type: 'move', id, ...msg }, id);
        break;
      }
      case 'block': {
        const p = players.get(id);
        if (p) p.lastActive = Date.now();
        // 转发方块变更给其他玩家
        broadcast({ type: 'block', id, tx: msg.tx, ty: msg.ty, tileId: msg.tileId }, id);
        break;
      }
    }
  });

  ws.on('close', () => {
    if (players.has(id)) {
      const p = players.get(id);
      players.delete(id);
      broadcast({ type: 'leave', id });
      console.log(`[leave] id=${id} nickname=${p.nickname} (${players.size} online)`);
    }
  });

  ws.on('error', () => {
    if (players.has(id)) {
      players.delete(id);
      broadcast({ type: 'leave', id });
    }
  });
});

// 启动服务器
server.listen(PORT, () => {
  console.log(`✅ 像素沙盒联机服务端已启动，端口 ${PORT}`);
  console.log(`   世界种子: ${WORLD_SEED}`);
  console.log(`   无操作超时: ${IDLE_TIMEOUT / 1000}秒`);
  console.log(`   HTTP API: /api/join, /api/move, /api/block, /api/poll`);
});

// 定时检查无操作玩家，超时则踢出
setInterval(() => {
  const now = Date.now();
  for (const [id, p] of players) {
    if (now - p.lastActive > IDLE_TIMEOUT) {
      console.log(`[timeout] 踢出 id=${id} nickname=${p.nickname} (无操作${Math.round((now - p.lastActive) / 1000)}秒)`);
      // WebSocket 玩家发送 kick 消息
      if (p.ws) {
        try {
          p.ws.send(JSON.stringify({ type: 'kick', reason: '无操作超时，已被自动踢出' }));
          p.ws.close();
        } catch (e) {}
      }
      players.delete(id);
      broadcast({ type: 'leave', id });
    }
  }
}, 10000);
