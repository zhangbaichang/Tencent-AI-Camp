/**
 * 像素沙盒 - 主游戏引擎
 * 玩家物理 / 渲染 / 挖掘建造 / 合成 / 敌人 / 昼夜 / UI
 */
(function() {
'use strict';

const { TILE, WORLD_W, WORLD_H, GRAVITY, MAX_FALL, PLAYER_SPEED, JUMP_FORCE, REACH } = window.GAME_CONST;
const BLOCKS = window.BLOCKS;
const RECIPES = window.RECIPES;
const WorldGen = window.WorldGen;
const getBlockShade = window.getBlockShade;
const BLOCK_ELEMENTS = window.BLOCK_ELEMENTS;
const ELEMENT_INFO = window.ELEMENT_INFO;
const ELEMENT_REACTIONS = window.ELEMENT_REACTIONS;
const PERIODIC_TABLE = window.PERIODIC_TABLE;
const ORE_ELEMENT_MAP = window.ORE_ELEMENT_MAP;

// ==================== 游戏状态 ====================
const game = {
  canvas: null, ctx: null,
  lightCanvas: null, lightCtx: null,
  world: null, surface: null,
  camX: 0, camY: 0,
  cw: 0, ch: 0,
  keys: {},
  mouse: { x: 0, y: 0, worldX: 0, worldY: 0, left: false, right: false },
  player: null,
  enemies: [],
  particles: [],
  droppedItems: [],
  inventory: {},
  hotbar: [0,0,0,0,0,0,0,0,0,0], // 方块ID
  hotbarCounts: [0,0,0,0,0,0,0,0,0,0],
  selectedSlot: 0,
  hoveredSlot: -1,
  time: 0.15, // 0~1 一天
  dayLength: 120, // 秒
  mining: { target: null, progress: 0, x:0, y:0 },
  craftingOpen: false,
  craftingDirty: true,
  craftingMode: 'hand', // 'hand' | 'workbench' | 'furnace'
  inventoryOpen: false,
  inventoryDirty: true,
  paused: false,
  fps: 0,
  showMap: false,
  // 卡牌对战
  battleTarget: null,
  battleCards: [],       // 已选热栏槽位索引（最多3个）
  battleOpen: false,
  battleCooldown: 0,
  battleAnimating: false, // 攻击动画进行中
  discoveredElements: new Set(), // 已发现的化学元素符号
  elementPopupActive: false, // 周期表弹窗是否显示
  regenAccum: 0, // 血量回复累积
  // 手机触屏输入
  touchInput: {
    moveX: 0,       // 摇杆: -1/0/1
    jump: false,    // 跳跃按钮
    mine: false,    // 挖掘按钮(持续)
    place: false,   // 放置按钮(单次)
    tap: false,     // 画布点击(单次,用于敌人交互)
    isTouch: false, // 是否触屏设备
  },
};

// ==================== 初始化 ====================
function init() {
  game.canvas = document.getElementById('game-canvas');
  game.ctx = game.canvas.getContext('2d');
  resizeCanvas();
  window.addEventListener('resize', resizeCanvas);

  // 检测触屏设备 / 移动端
  // 说明：微信 web-view 在真机上 UA 始终为手机端且具备触屏，原检测即可命中；
  // 这里追加 UA 兜底，确保任何边缘环境（如开发者工具、个别 WebView 版本）
  // 都能强制启用移动控件（虚拟摇杆/操作按钮），不改变任何游戏逻辑。
  var _ua = navigator.userAgent || '';
  var _isMobileUA = /Mobile|Android|iPhone|iPod|iPad|MicroMessenger/i.test(_ua);
  if (_isMobileUA || 'ontouchstart' in window || navigator.maxTouchPoints > 0) {
    game.touchInput.isTouch = true;
    document.body.classList.add('touch-device');
  }

  // 生成世界
  const seed = Math.random() * 10000 | 0;
  const w = WorldGen.generateWorld(WORLD_W, WORLD_H, seed);
  game.world = w.world;
  game.surface = w.surfaceHeight;

  // 创建玩家（在地表中央）
  const spawnX = (WORLD_W >> 1) * TILE;
  const spawnY = (w.surfaceHeight[WORLD_W >> 1] - 2) * TILE;
  game.player = {
    x: spawnX, y: spawnY - 36,
    vx: 0, vy: 0,
    w: 18, h: 36,
    onGround: false,
    health: 100, maxHealth: 100,
    invuln: 0,
    lastDamageTime: 0,
    facing: 1,
    mining: false,
    walkPhase: 0,
  };

  // 给玩家一些初始物品
  game.inventory[4] = 10; // 10木头
  game.inventory[15] = 5; // 5火把
  game.inventory[13] = 20; // 20木板
  updateHotbar();
  game.hotbar[0] = 15; game.hotbarCounts[0] = 5;
  game.hotbar[1] = 4;  game.hotbarCounts[1] = 10;
  game.hotbar[2] = 13; game.hotbarCounts[2] = 20;

  // 事件
  bindEvents();
  // 手机控件
  bindMobileControls();

  // 隐藏加载画面
  setTimeout(() => {
    const ls = document.getElementById('loading-screen');
    if (ls) ls.classList.add('hide');
  }, 800);

  // 启动游戏循环
  let lastTime = performance.now();
  let frameCount = 0, fpsTime = 0;
  function loop(now) {
    const dt = Math.min(50, now - lastTime);
    lastTime = now;
    frameCount++;
    fpsTime += dt;
    if (fpsTime > 500) { game.fps = Math.round(frameCount * 1000 / fpsTime); frameCount = 0; fpsTime = 0; }
    if (!game.paused) update(dt);
    render();
    requestAnimationFrame(loop);
  }
  requestAnimationFrame(loop);

  showToast('欢迎来到像素沙盒世界！', 2000);
}

function resizeCanvas() {
  game.cw = game.canvas.width = game.canvas.clientWidth;
  game.ch = game.canvas.height = game.canvas.clientHeight;
}

// 方块图标 emoji
const BLOCK_EMOJI = {
  0:'', 1:'🌿', 2:'🟤', 3:'🪨', 4:'🪵', 5:'🍃', 6:'🏖️', 7:'⚫', 8:'🟠',
  9:'⚙️', 10:'🟡', 11:'💎', 12:'💧', 13:'🟧', 14:'🧱', 15:'🔥', 16:'🪟',
  17:'🔨', 18:'🏺', 19:'🟫', 20:'⬜', 21:'🟨', 22:'🟥', 23:'❄️', 24:'🧊', 25:'⬛',
  26:'🚪', 27:'📦', 28:'🚧', 29:'🔩', 30:'🟮', 31:'🔷', 32:'🏮', 33:'📚', 34:'⛓️', 35:'🔵',
  36:'⚪', 37:'🔮', 38:'🟩', 39:'🟦', 40:'🟡', 41:'💎',
  42:'⬜', 43:'💠', 44:'🟢', 45:'🔷', 46:'🧊',
  47:'🟠', 48:'🔇', 49:'🟨', 50:'🔍', 51:'🔌', 52:'💣', 53:'🧪', 54:'🔷', 55:'🔋',
  56:'⛏️', 57:'⛏️', 58:'⛏️',
};

// ==================== 世界操作 ====================
function getTile(tx, ty) {
  if (tx < 0 || tx >= WORLD_W || ty < 0 || ty >= WORLD_H) return 0;
  return game.world[ty * WORLD_W + tx];
}

function setTile(tx, ty, id) {
  if (tx < 0 || tx >= WORLD_W || ty < 0 || ty >= WORLD_H) return;
  game.world[ty * WORLD_W + tx] = id;
}

function isSolid(tx, ty) {
  const id = getTile(tx, ty);
  return BLOCKS[id] && BLOCKS[id].solid;
}

function getTileLight(tx, ty) {
  const id = getTile(tx, ty);
  return BLOCKS[id] ? BLOCKS[id].light : 0;
}

// 检查附近是否有工作台/熔炉
function hasCraftingStation(type) {
  const px = game.player.x / TILE | 0;
  const py = game.player.y / TILE | 0;
  for (let dx = -4; dx <= 4; dx++) {
    for (let dy = -4; dy <= 4; dy++) {
      const id = getTile(px + dx, py + dy);
      if (type === 'workbench' && id === 17) return true;
      if (type === 'furnace' && id === 18) return true;
    }
  }
  return false;
}

// ==================== 物理与碰撞 ====================
function moveEntity(e, dt) {
  const dts = dt / 16.67; // 标准化到60fps步长

  // X轴移动
  e.x += e.vx * dts;
  collideAxis(e, 'x');

  // Y轴移动
  e.vy += GRAVITY * dts;
  if (e.vy > MAX_FALL) e.vy = MAX_FALL;
  e.y += e.vy * dts;
  e.onGround = false;
  collideAxis(e, 'y');
}

function collideAxis(e, axis) {
  const minTx = Math.floor(e.x / TILE);
  const maxTx = Math.floor((e.x + e.w - 1) / TILE);
  const minTy = Math.floor(e.y / TILE);
  const maxTy = Math.floor((e.y + e.h - 1) / TILE);

  for (let ty = minTy; ty <= maxTy; ty++) {
    for (let tx = minTx; tx <= maxTx; tx++) {
      if (!isSolid(tx, ty)) continue;

      const tileLeft = tx * TILE;
      const tileTop = ty * TILE;
      const tileRight = tileLeft + TILE;
      const tileBottom = tileTop + TILE;

      if (axis === 'x') {
        if (e.vx > 0) { e.x = tileLeft - e.w; e.vx = 0; }
        else if (e.vx < 0) { e.x = tileRight; e.vx = 0; }
      } else {
        if (e.vy > 0) { e.y = tileTop - e.h; e.vy = 0; e.onGround = true; }
        else if (e.vy < 0) { e.y = tileBottom; e.vy = 0; }
      }
    }
  }

  // 世界边界
  if (e.x < 0) { e.x = 0; e.vx = 0; }
  if (e.x + e.w > WORLD_W * TILE) { e.x = WORLD_W * TILE - e.w; e.vx = 0; }
  if (e.y < 0) { e.y = 0; e.vy = 0; }
  if (e.y > WORLD_H * TILE) { e.y = 0; e.vy = 0; e.health = 0; } // 掉出世界
}

// ==================== 输入处理 ====================
function bindEvents() {
  window.addEventListener('keydown', e => {
    game.keys[e.code] = true;
    // 对战时只允许 Escape（但动画期间禁止退出）
    if (game.battleOpen) {
      if (e.code === 'Escape' && !game.battleAnimating) closeBattle();
      return;
    }
    // 热栏选择
    if (e.code.startsWith('Digit')) {
      const n = parseInt(e.code.slice(5));
      game.selectedSlot = (n === 0) ? 9 : n - 1;
    }
    if (e.code === 'KeyE') {
      game.inventoryOpen = !game.inventoryOpen;
      if (game.inventoryOpen) game.craftingOpen = false;
      game.inventoryDirty = true;
    }
    if (e.code === 'Tab') {
      e.preventDefault();
      if (!game.craftingOpen) {
        game.craftingOpen = true;
        game.craftingMode = 'hand';
      } else if (game.craftingMode !== 'hand') {
        game.craftingMode = 'hand';
      } else {
        game.craftingOpen = false;
      }
      if (game.craftingOpen) game.inventoryOpen = false;
      game.craftingDirty = true;
    }
    if (e.code === 'Escape') { game.craftingOpen = false; game.inventoryOpen = false; }
    if (e.code === 'KeyM') { game.showMap = !game.showMap; }
  });
  window.addEventListener('keyup', e => { game.keys[e.code] = false; });

  game.canvas.addEventListener('mousemove', e => {
    const rect = game.canvas.getBoundingClientRect();
    game.mouse.x = e.clientX - rect.left;
    game.mouse.y = e.clientY - rect.top;
    // 计算世界坐标
    game.mouse.worldX = game.camX + game.mouse.x;
    game.mouse.worldY = game.camY + game.mouse.y;
    // 热栏悬停检测
    const slotSize = 40, gap = 4;
    const totalW = 10 * slotSize + 9 * gap;
    const startX = (game.cw - totalW) / 2;
    const hotY = game.ch - slotSize - 16;
    if (game.mouse.y >= hotY && game.mouse.y <= hotY + slotSize) {
      const relX = game.mouse.x - startX;
      if (relX >= 0 && relX < totalW) {
        game.hoveredSlot = Math.floor(relX / (slotSize + gap));
        if (game.hoveredSlot < 0 || game.hoveredSlot > 9) game.hoveredSlot = -1;
      } else {
        game.hoveredSlot = -1;
      }
    } else {
      game.hoveredSlot = -1;
    }
  });

  game.canvas.addEventListener('mousedown', e => {
    e.preventDefault();
    // 热栏点击选择
    if (e.button === 0) {
      const slotSize = 44, gap = 4;
      const totalW = 10 * slotSize + 9 * gap;
      const startX = (game.cw - totalW) / 2;
      const hotY = game.ch - slotSize - 14;
      if (game.mouse.y >= hotY && game.mouse.y <= hotY + slotSize) {
        const relX = game.mouse.x - startX;
        if (relX >= 0 && relX < totalW) {
          const slot = Math.floor(relX / (slotSize + gap));
          if (slot >= 0 && slot <= 9 && game.hotbar[slot] > 0) {
            game.selectedSlot = slot;
            sfx('click');
            return;
          }
        }
      }
    }
    if (e.button === 0) game.mouse.left = true;
    if (e.button === 2) game.mouse.right = true;
  });
  game.canvas.addEventListener('mouseup', e => {
    if (e.button === 0) game.mouse.left = false;
    if (e.button === 2) game.mouse.right = false;
  });
  game.canvas.addEventListener('contextmenu', e => e.preventDefault());

  // 触屏支持
  game.canvas.addEventListener('touchstart', e => {
    e.preventDefault();
    const t = e.touches[0];
    const rect = game.canvas.getBoundingClientRect();
    game.mouse.x = t.clientX - rect.left;
    game.mouse.y = t.clientY - rect.top;
    game.mouse.worldX = game.camX + game.mouse.x;
    game.mouse.worldY = game.camY + game.mouse.y;
    // 触屏设备：用 tap 标记，挖掘由按钮控制
    if (game.touchInput.isTouch) {
      game.touchInput.tap = true;
    } else {
      game.mouse.left = true;
    }
  });
  game.canvas.addEventListener('touchmove', e => {
    e.preventDefault();
    const t = e.touches[0];
    const rect = game.canvas.getBoundingClientRect();
    game.mouse.x = t.clientX - rect.left;
    game.mouse.y = t.clientY - rect.top;
    game.mouse.worldX = game.camX + game.mouse.x;
    game.mouse.worldY = game.camY + game.mouse.y;
  });
  game.canvas.addEventListener('touchend', e => {
    e.preventDefault();
    if (game.touchInput.isTouch) {
      game.touchInput.tap = false;
    } else {
      game.mouse.left = false;
    }
  });

  // 合成界面点击
  document.getElementById('crafting-overlay').addEventListener('click', e => {
    if (e.target.id === 'crafting-overlay') game.craftingOpen = false;
  });

  // 背包界面点击
  document.getElementById('inventory-overlay').addEventListener('click', e => {
    if (e.target.id === 'inventory-overlay') game.inventoryOpen = false;
  });

  // 对战面板点击外部关闭
  const battleOverlay = document.getElementById('battle-overlay');
  if (battleOverlay) {
    battleOverlay.addEventListener('click', e => {
      if (e.target.id === 'battle-overlay' && !game.battleAnimating) {
        closeBattle();
      }
    });
  }
}

// ==================== 手机触屏控件 ====================
function bindMobileControls() {
  // ---- 虚拟摇杆 ----
  const joyBase = document.getElementById('joystick-base');
  const joyKnob = document.getElementById('joystick-knob');
  let joyActive = false;
  let joyCenterX = 0, joyCenterY = 0;

  function joyStart(e) {
    e.preventDefault();
    joyActive = true;
    joyBase.classList.add('active');
    const rect = joyBase.getBoundingClientRect();
    joyCenterX = rect.left + rect.width / 2;
    joyCenterY = rect.top + rect.height / 2;
    joyMove(e);
  }

  function joyMove(e) {
    if (!joyActive) return;
    e.preventDefault();
    const t = e.touches ? e.touches[0] : e;
    let dx = t.clientX - joyCenterX;
    let dy = t.clientY - joyCenterY;
    const dist = Math.sqrt(dx * dx + dy * dy);
    const maxR = 45;
    if (dist > maxR) {
      dx = (dx / dist) * maxR;
      dy = (dy / dist) * maxR;
    }
    joyKnob.style.transform = `translate(calc(-50% + ${dx}px), calc(-50% + ${dy}px))`;
    // 水平移动：超过死区才触发
    const deadzone = 12;
    if (Math.abs(dx) > deadzone) {
      game.touchInput.moveX = dx > 0 ? 1 : -1;
    } else {
      game.touchInput.moveX = 0;
    }
  }

  function joyEnd(e) {
    e.preventDefault();
    joyActive = false;
    joyBase.classList.remove('active');
    joyKnob.style.transform = 'translate(-50%, -50%)';
    game.touchInput.moveX = 0;
  }

  joyBase.addEventListener('touchstart', joyStart, { passive: false });
  joyBase.addEventListener('touchmove', joyMove, { passive: false });
  joyBase.addEventListener('touchend', joyEnd, { passive: false });
  joyBase.addEventListener('touchcancel', joyEnd, { passive: false });
  // 鼠标也支持（测试用）
  joyBase.addEventListener('mousedown', joyStart);
  window.addEventListener('mousemove', e => { if (joyActive) joyMove(e); });
  window.addEventListener('mouseup', e => { if (joyActive) joyEnd(e); });

  // ---- 跳跃按钮 ----
  const btnJump = document.getElementById('btn-jump');
  function jumpStart(e) {
    e.preventDefault();
    e.stopPropagation();
    game.touchInput.jump = true;
    btnJump.classList.add('pressed');
  }
  function jumpEnd(e) {
    e.preventDefault();
    e.stopPropagation();
    game.touchInput.jump = false;
    btnJump.classList.remove('pressed');
  }
  btnJump.addEventListener('touchstart', jumpStart, { passive: false });
  btnJump.addEventListener('touchend', jumpEnd, { passive: false });
  btnJump.addEventListener('touchcancel', jumpEnd, { passive: false });
  btnJump.addEventListener('mousedown', jumpStart);
  btnJump.addEventListener('mouseup', jumpEnd);
  btnJump.addEventListener('mouseleave', jumpEnd);

  // ---- 挖掘按钮（持续按住）----
  const btnMine = document.getElementById('btn-mine');
  function mineStart(e) {
    e.preventDefault();
    e.stopPropagation();
    game.touchInput.mine = true;
    btnMine.classList.add('pressed');
  }
  function mineEnd(e) {
    e.preventDefault();
    e.stopPropagation();
    game.touchInput.mine = false;
    btnMine.classList.remove('pressed');
  }
  btnMine.addEventListener('touchstart', mineStart, { passive: false });
  btnMine.addEventListener('touchend', mineEnd, { passive: false });
  btnMine.addEventListener('touchcancel', mineEnd, { passive: false });
  btnMine.addEventListener('mousedown', mineStart);
  btnMine.addEventListener('mouseup', mineEnd);
  btnMine.addEventListener('mouseleave', mineEnd);

  // ---- 放置按钮（单次触发）----
  const btnPlace = document.getElementById('btn-place');
  function placeTap(e) {
    e.preventDefault();
    e.stopPropagation();
    game.touchInput.place = true;
    btnPlace.classList.add('pressed');
    setTimeout(() => btnPlace.classList.remove('pressed'), 150);
  }
  btnPlace.addEventListener('touchstart', placeTap, { passive: false });
  btnPlace.addEventListener('mousedown', placeTap);

  // ---- 背包按钮 ----
  const btnInv = document.getElementById('btn-inventory');
  btnInv.addEventListener('touchstart', e => {
    e.preventDefault();
    e.stopPropagation();
    game.inventoryOpen = !game.inventoryOpen;
    if (game.inventoryOpen) game.craftingOpen = false;
    game.inventoryDirty = true;
    sfx('click');
  }, { passive: false });
  btnInv.addEventListener('click', e => {
    e.stopPropagation();
  });

  // ---- 合成按钮 ----
  const btnCraft = document.getElementById('btn-craft');
  btnCraft.addEventListener('touchstart', e => {
    e.preventDefault();
    e.stopPropagation();
    if (!game.craftingOpen) {
      game.craftingOpen = true;
      game.craftingMode = 'hand';
    } else if (game.craftingMode !== 'hand') {
      game.craftingMode = 'hand';
    } else {
      game.craftingOpen = false;
    }
    if (game.craftingOpen) game.inventoryOpen = false;
    game.craftingDirty = true;
    sfx('click');
  }, { passive: false });
  btnCraft.addEventListener('click', e => {
    e.stopPropagation();
  });

  // ---- 热栏触屏选择 ----
  game.canvas.addEventListener('touchstart', e => {
    if (!game.touchInput.isTouch) return;
    // 如果触摸在控件上则跳过
    const target = e.target;
    if (target.closest('#mobile-controls')) return;
    // 热栏区域检测
    const rect = game.canvas.getBoundingClientRect();
    const tx = e.touches[0].clientX - rect.left;
    const ty = e.touches[0].clientY - rect.top;
    const slotSize = 44, gap = 4;
    const totalW = 10 * slotSize + 9 * gap;
    const startX = (game.cw - totalW) / 2;
    const hotY = game.ch - slotSize - 20; // 触屏热栏位置
    if (ty >= hotY && ty <= hotY + slotSize) {
      const relX = tx - startX;
      if (relX >= 0 && relX < totalW) {
        const slot = Math.floor(relX / (slotSize + gap));
        if (slot >= 0 && slot <= 9 && game.hotbar[slot] > 0) {
          game.selectedSlot = slot;
          sfx('click');
          e.preventDefault();
          return;
        }
      }
    }
  }, { passive: false });
}

// ==================== 玩家更新 ====================
function updatePlayer(dt) {
  const p = game.player;
  const dts = dt / 16.67;

  // 移动
  let moveX = 0;
  if (game.keys['KeyA'] || game.keys['ArrowLeft']) moveX -= 1;
  if (game.keys['KeyD'] || game.keys['ArrowRight']) moveX += 1;
  // 手机摇杆
  if (moveX === 0 && game.touchInput.moveX !== 0) moveX = game.touchInput.moveX;

  if (moveX !== 0) {
    p.vx = moveX * PLAYER_SPEED;
    p.facing = moveX;
    p.walkPhase += dts * 0.3;
  } else {
    p.vx *= 0.7;
    if (Math.abs(p.vx) < 0.1) p.vx = 0;
    p.walkPhase = 0;
  }

  // 跳跃
  if ((game.keys['KeyW'] || game.keys['Space'] || game.keys['ArrowUp'] || game.touchInput.jump) && p.onGround) {
    p.vy = -JUMP_FORCE;
    p.onGround = false;
    sfx('jump');
  }

  // 物理
  moveEntity(p, dt);

  // 掉落伤害
  if (p.vy === 0 && !p.onGround) {
    // 检查是否是落地
  }
  if (p.invuln > 0) p.invuln -= dt;

  // 血量自动回复：受伤4秒后开始，每800ms回复2HP
  if (p.health < p.maxHealth && p.invuln <= 0) {
    const timeSinceDamage = performance.now() - (p.lastDamageTime || 0);
    if (timeSinceDamage > 4000) {
      game.regenAccum += dt;
      if (game.regenAccum >= 800) {
        game.regenAccum = 0;
        p.health = Math.min(p.maxHealth, p.health + 2);
        if (Math.random() < 0.4) {
          spawnParticles(p.x + p.w / 2, p.y + 4, '#22ff44', 2);
        }
      }
    }
  }

  // 死亡
  if (p.health <= 0) {
    respawn();
  }

  // 挖掘/放置/对战
  const px = Math.floor((p.x + p.w / 2) / TILE);
  const py = Math.floor((p.y + p.h / 2) / TILE);

  // 手机触屏挖掘：自动寻找面前的方块
  if (game.touchInput.isTouch && game.touchInput.mine && !game.battleOpen) {
    // 优先：面前同高度
    let aimTx = px + p.facing;
    let aimTy = Math.floor((p.y + p.h / 2) / TILE);
    // 如果面前同高度是空气，尝试脚下（挖地道）
    if (getTile(aimTx, aimTy) === 0) {
      const feetTy = Math.floor((p.y + p.h - 1) / TILE);
      if (getTile(aimTx, feetTy) !== 0) {
        aimTy = feetTy;
      } else {
        // 尝试头顶（挖天花板）
        const headTy = Math.floor(p.y / TILE);
        if (getTile(aimTx, headTy) !== 0) {
          aimTy = headTy;
        }
      }
    }
    game.mouse.worldX = aimTx * TILE + TILE / 2;
    game.mouse.worldY = aimTy * TILE + TILE / 2;
    game.mouse.left = true;
  } else if (game.touchInput.isTouch && !game.touchInput.mine) {
    // 挖掘按钮松开时清除
    game.mouse.left = false;
  }
  // 手机触屏放置：单次触发
  if (game.touchInput.isTouch && game.touchInput.place && !game.battleOpen) {
    let aimTx = px + p.facing;
    let aimTy = Math.floor((p.y + p.h / 2) / TILE);
    // 如果面前被占，尝试脚下
    if (getTile(aimTx, aimTy) !== 0) {
      const feetTy = Math.floor((p.y + p.h + 2) / TILE);
      if (getTile(aimTx, feetTy) === 0) aimTy = feetTy;
    }
    game.mouse.worldX = aimTx * TILE + TILE / 2;
    game.mouse.worldY = aimTy * TILE + TILE / 2;
    game.mouse.right = true;
    game.touchInput.place = false; // 单次触发后清除
  }

  const tx = Math.floor(game.mouse.worldX / TILE);
  const ty = Math.floor(game.mouse.worldY / TILE);
  const dist = Math.abs(tx - px) + Math.abs(ty - py);

  if (game.battleCooldown > 0) game.battleCooldown -= dt;

  // 点击敌人 → 开启卡牌对战（优先于挖掘）
  let clickedEnemy = false;
  const tapActive = game.mouse.left || (game.touchInput.isTouch && game.touchInput.tap);
  if (tapActive && !game.battleOpen && game.battleCooldown <= 0) {
    for (const en of game.enemies) {
      const ex = en.x + en.w / 2;
      const ey = en.y + en.h / 2;
      if (Math.abs(game.mouse.worldX - ex) < en.w &&
          Math.abs(game.mouse.worldY - ey) < en.h && dist <= REACH) {
        openBattle(en);
        game.mouse.left = false;
        game.touchInput.tap = false;
        clickedEnemy = true;
        break;
      }
    }
  }

  // 挖掘（未点中敌人时）
  // 触屏设备：挖掘只通过按钮触发
  const mineActive = game.touchInput.isTouch ? (game.touchInput.mine && game.mouse.left) : game.mouse.left;
  if (!clickedEnemy && mineActive && dist <= REACH && !game.battleOpen) {
    handleMining(tx, ty, dt);
  } else if (!game.battleOpen && !mineActive) {
    game.mining.target = null;
    game.mining.progress = 0;
  }

  // 触屏点击工作站打开UI
  if (game.touchInput.isTouch && game.touchInput.tap && !clickedEnemy && !game.battleOpen) {
    const tapTile = getTile(tx, ty);
    if (tapTile === 17 && dist <= REACH) {
      game.craftingOpen = true;
      game.craftingMode = 'workbench';
      game.craftingDirty = true;
      game.inventoryOpen = false;
      game.touchInput.tap = false;
      sfx('click');
    } else if (tapTile === 18 && dist <= REACH) {
      game.craftingOpen = true;
      game.craftingMode = 'furnace';
      game.craftingDirty = true;
      game.inventoryOpen = false;
      game.touchInput.tap = false;
      sfx('click');
    }
  }

  // 右键：打开工作站UI 或 放置方块
  if (game.mouse.right && !game.battleOpen) {
    const targetTile = getTile(tx, ty);
    if (targetTile === 17 && dist <= REACH) {
      game.craftingOpen = true;
      game.craftingMode = 'workbench';
      game.craftingDirty = true;
      game.inventoryOpen = false;
      game.mouse.right = false;
      sfx('click');
    } else if (targetTile === 18 && dist <= REACH) {
      game.craftingOpen = true;
      game.craftingMode = 'furnace';
      game.craftingDirty = true;
      game.inventoryOpen = false;
      game.mouse.right = false;
      sfx('click');
    } else if (dist <= REACH && dist > 0) {
      handlePlacing(tx, ty);
      game.mouse.right = false;
    }
    // 触屏放置兜底清除
    if (game.touchInput.isTouch) game.mouse.right = false;
  }
}

function handleMining(tx, ty, dt) {
  const tileId = getTile(tx, ty);
  if (tileId === 0) return;
  const block = BLOCKS[tileId];
  if (!block || block.hardness === 0) return;

  // 工具需求检查
  const requiredTier = block.tool || 0;
  const equippedToolId = game.hotbar[game.selectedSlot];
  const equippedTool = equippedToolId > 0 ? BLOCKS[equippedToolId] : null;
  const toolTier = (equippedTool && equippedTool.toolTier) ? equippedTool.toolTier : 0;

  if (requiredTier > 0 && toolTier < requiredTier) {
    const toolNames = ['', '木镐', '石镐', '铁镐'];
    if (!game.mining.toolWarnTimer || performance.now() - game.mining.toolWarnTimer > 1500) {
      showToast(`需要${toolNames[requiredTier]}或更好的工具！`, 1500);
      game.mining.toolWarnTimer = performance.now();
    }
    game.mining.target = null;
    game.mining.progress = 0;
    return;
  }

  // 工具加速：有工具时挖掘更快
  const speedMul = toolTier > 0 ? 1 + toolTier * 0.4 : 1;

  const targetKey = tx + ',' + ty;
  if (game.mining.target !== targetKey) {
    game.mining.target = targetKey;
    game.mining.progress = 0;
    game.mining.x = tx;
    game.mining.y = ty;
  }

  game.mining.progress += dt * speedMul;
  // 粒子
  if (Math.random() < 0.3) {
    spawnParticles(tx * TILE + TILE / 2, ty * TILE + TILE / 2, block.shade || block.color, 2);
  }

  if (game.mining.progress >= block.hardness * 8) {
    // 挖掘完成
    const dropId = block.drop || tileId;
    addItem(dropId, 1);
    setTile(tx, ty, 0);
    spawnParticles(tx * TILE + TILE / 2, ty * TILE + TILE / 2, block.color, 12);
    sfx('break');
    game.mining.target = null;
    game.mining.progress = 0;

    // 元素发现检测
    const elementSymbol = ORE_ELEMENT_MAP[tileId];
    if (elementSymbol && !game.discoveredElements.has(elementSymbol)) {
      game.discoveredElements.add(elementSymbol);
      showElementDiscovery(elementSymbol);
    }

    // 掉落树干时破坏上方树叶
    if (tileId === 4) {
      for (let dy = 1; dy <= 5; dy++) {
        if (getTile(tx, ty - dy) === 5) {
          setTile(tx, ty - dy, 0);
          spawnParticles(tx * TILE + TILE / 2, (ty - dy) * TILE + TILE / 2, '#2d6b1e', 6);
        }
      }
    }
  }
}

function handlePlacing(tx, ty) {
  // 目标位置必须是空气
  if (getTile(tx, ty) !== 0) return;

  // 检查相邻是否有固体方块（不能凭空放）
  let hasNeighbor = false;
  if (isSolid(tx - 1, ty)) hasNeighbor = true;
  if (isSolid(tx + 1, ty)) hasNeighbor = true;
  if (isSolid(tx, ty - 1)) hasNeighbor = true;
  if (isSolid(tx, ty + 1)) hasNeighbor = true;
  if (!hasNeighbor) return;

  // 不能放在玩家身上
  const p = game.player;
  const pTx = Math.floor(p.x / TILE);
  const pTy = Math.floor(p.y / TILE);
  const pTx2 = Math.floor((p.x + p.w - 1) / TILE);
  const pTy2 = Math.floor((p.y + p.h - 1) / TILE);
  if (tx >= pTx && tx <= pTx2 && ty >= pTy && ty <= pTy2) {
    if (BLOCKS[game.hotbar[game.selectedSlot]] && BLOCKS[game.hotbar[game.selectedSlot]].solid) return;
  }

  const slot = game.selectedSlot;
  const blockId = game.hotbar[slot];
  if (blockId === 0 || game.hotbarCounts[slot] <= 0) return;

  // 工具不能放置
  const placeBlock = BLOCKS[blockId];
  if (placeBlock && placeBlock.tool) {
    showToast('工具不能放置，请选择方块', 800);
    return;
  }

  setTile(tx, ty, blockId);
  removeItem(blockId, 1);
  sfx('place');
}

// ==================== 敌人系统 ====================
function updateEnemies(dt) {
  const dts = dt / 16.67;

  // 夜晚生成敌人
  if (game.time > 0.5 && game.time < 0.95 && game.enemies.length < 8 && Math.random() < 0.005) {
    spawnEnemy();
  }

  for (let i = game.enemies.length - 1; i >= 0; i--) {
    const e = game.enemies[i];

    // AI：朝玩家移动
    const p = game.player;
    const dx = p.x - e.x;
    const dist = Math.abs(dx);

    if (dist < 200 && dist > 20) {
      e.vx = (dx > 0 ? 1 : -1) * 1.5;
    } else {
      e.vx *= 0.9;
    }

    // 跳跃（如果在地面碰到障碍）
    if (e.onGround && Math.abs(e.vx) > 0.5 && isSolid(
      Math.floor((e.x + (e.vx > 0 ? e.w + 2 : -2)) / TILE),
      Math.floor((e.y + e.h - 2) / TILE)
    )) {
      e.vy = -7;
    }

    // 物理
    moveEntity(e, dt);

    // 碰撞玩家
    if (Math.abs(p.x - e.x) < (p.w + e.w) / 2 + 4 &&
        Math.abs(p.y - e.y) < (p.h + e.h) / 2 + 4) {
      if (p.invuln <= 0) {
        p.health -= 8;
        p.invuln = 800;
        p.lastDamageTime = performance.now();
        p.vx = (p.x < e.x ? -5 : 5);
        p.vy = -6;
        sfx('hurt');
      }
    }

    // 删除死亡/掉出世界
    if (e.health <= 0 || e.y > WORLD_H * TILE) {
      game.enemies.splice(i, 1);
    }

    e.animPhase = (e.animPhase || 0) + dts * 0.15;
  }

  // 白天清除敌人
  if (game.time < 0.05 || game.time > 0.95) {
    if (game.enemies.length > 0 && Math.random() < 0.02) {
      game.enemies.pop();
    }
  }
}

function spawnEnemy() {
  const p = game.player;
  // 在玩家附近但屏幕外生成
  const side = Math.random() < 0.5 ? -1 : 1;
  const dist = (game.cw / TILE / 2 + 3) * TILE;
  let x = p.x + side * dist;
  // 找到地表
  const tx = Math.floor(x / TILE);
  x = tx * TILE;
  let y = 0;
  for (let ty = 0; ty < WORLD_H; ty++) {
    if (isSolid(tx, ty)) { y = (ty - 2) * TILE; break; }
  }

  game.enemies.push({
    x: Math.max(0, Math.min(WORLD_W * TILE - 30, x)),
    y: y,
    vx: 0, vy: 0,
    w: 24, h: 24,
    onGround: false,
    health: 30, maxHealth: 30,
    animPhase: 0,
    type: 'slime',
  });
}

// ==================== 掉落物系统 ====================
function updateDroppedItems(dt) {
  const dts = dt / 16.67;
  const p = game.player;

  for (let i = game.droppedItems.length - 1; i >= 0; i--) {
    const item = game.droppedItems[i];
    item.vy += GRAVITY * dts;
    if (item.vy > MAX_FALL) item.vy = MAX_FALL;
    item.y += item.vy * dts;
    item.x += item.vx * dts;
    item.vx *= 0.9;

    // 碰撞
    const tx = Math.floor(item.x / TILE);
    const ty = Math.floor((item.y + 8) / TILE);
    if (isSolid(tx, ty)) {
      item.y = ty * TILE - 8;
      item.vy = 0;
    }

    item.life -= dt;

    // 拾取
    const dx = (p.x + p.w / 2) - (item.x + 4);
    const dy = (p.y + p.h / 2) - (item.y + 4);
    if (Math.abs(dx) < 24 && Math.abs(dy) < 24 && item.life < 550) {
      addItem(item.id, item.count);
      game.droppedItems.splice(i, 1);
      sfx('pickup');
      continue;
    }

    if (item.life <= 0) game.droppedItems.splice(i, 1);
  }
}

// ==================== 粒子系统 ====================
function spawnParticles(x, y, color, count) {
  for (let i = 0; i < count; i++) {
    game.particles.push({
      x, y,
      vx: (Math.random() - 0.5) * 6,
      vy: (Math.random() - 0.5) * 6 - 2,
      life: 0.5 + Math.random() * 0.5,
      maxLife: 0.5 + Math.random() * 0.5,
      size: 2 + Math.random() * 4,
      color,
      gravity: 0.3,
    });
  }
}

function updateParticles(dt) {
  const dts = dt / 16.67;
  for (let i = game.particles.length - 1; i >= 0; i--) {
    const p = game.particles[i];
    p.vy += p.gravity * dts;
    p.x += p.vx * dts;
    p.y += p.vy * dts;
    p.vx *= 0.96;
    p.life -= dt / 1000;
    if (p.life <= 0) game.particles.splice(i, 1);
  }
}

// ==================== 主更新循环 ====================
function update(dt) {
  // 昼夜
  game.time += dt / 1000 / game.dayLength;
  if (game.time >= 1) game.time = 0;

  updatePlayer(dt);
  updateEnemies(dt);
  updateDroppedItems(dt);
  updateParticles(dt);

  // 摄像机跟随
  const targetCamX = game.player.x + game.player.w / 2 - game.cw / 2;
  const targetCamY = game.player.y + game.player.h / 2 - game.ch / 2;
  game.camX += (targetCamX - game.camX) * 0.1;
  game.camY += (targetCamY - game.camY) * 0.1;
  game.camX = Math.max(0, Math.min(WORLD_W * TILE - game.cw, game.camX));
  game.camY = Math.max(0, Math.min(WORLD_H * TILE - game.ch, game.camY));

  // 更新鼠标世界坐标
  game.mouse.worldX = game.camX + game.mouse.x;
  game.mouse.worldY = game.camY + game.mouse.y;

  // 更新UI
  updateUI();
}

function respawn() {
  const p = game.player;
  const spawnTx = WORLD_W >> 1;
  p.x = spawnTx * TILE;
  p.y = (game.surface[spawnTx] - 2) * TILE - p.h;
  p.vx = 0; p.vy = 0;
  p.health = p.maxHealth;
  p.invuln = 2000;
  game.enemies = [];
  showToast('重生中...', 2000);
}

// ==================== 渲染系统 ====================
function render() {
  const ctx = game.ctx;

  // 天空
  drawSky(ctx);

  // 地图
  drawTiles(ctx);

  // 掉落物
  drawDroppedItems(ctx);

  // 敌人
  drawEnemies(ctx);

  // 玩家
  drawPlayer(ctx);

  // 粒子
  drawParticles(ctx);

  // 光照
  drawLighting(ctx);

  // 挖掘进度
  drawMiningProgress(ctx);

  // 鼠标指示
  drawMouseTarget(ctx);

  // UI
  drawUI(ctx);
}

function drawSky(ctx) {
  // 昼夜颜色
  const t = game.time;
  let r, g, b;
  if (t < 0.1) { // 黎明
    const k = t / 0.1;
    r = lerp(20, 100, k); g = lerp(20, 160, k); b = lerp(60, 220, k);
  } else if (t < 0.4) { // 白天
    r = 100; g = 160; b = 220;
  } else if (t < 0.5) { // 黄昏
    const k = (t - 0.4) / 0.1;
    r = lerp(100, 200, k); g = lerp(160, 100, k); b = lerp(220, 60, k);
  } else if (t < 0.6) { // 暮色
    const k = (t - 0.5) / 0.1;
    r = lerp(200, 20, k); g = lerp(100, 20, k); b = lerp(60, 60, k);
  } else { // 夜晚
    r = 15; g = 15; b = 40;
  }

  ctx.fillStyle = `rgb(${r|0},${g|0},${b|0})`;
  ctx.fillRect(0, 0, game.cw, game.ch);

  // 太阳/月亮
  const sunX = game.cw * (t * 2 - 0.5);
  const sunY = game.ch * 0.15 + Math.sin(t * Math.PI) * -30;
  if (t < 0.5) {
    ctx.fillStyle = `rgba(255,240,100,0.8)`;
    ctx.beginPath();
    ctx.arc(sunX, Math.max(20, sunY), 25, 0, Math.PI * 2);
    ctx.fill();
  } else {
    const moonX = game.cw * ((t - 0.5) * 2 - 0.5);
    ctx.fillStyle = `rgba(200,200,220,0.8)`;
    ctx.beginPath();
    ctx.arc(moonX, Math.max(20, sunY), 18, 0, Math.PI * 2);
    ctx.fill();
  }

  // 星星（夜晚）
  if (t > 0.55) {
    const starAlpha = Math.min(1, (t - 0.55) / 0.1);
    ctx.fillStyle = `rgba(255,255,255,${starAlpha * 0.6})`;
    for (let i = 0; i < 50; i++) {
      const sx = (i * 73 + 13) % game.cw;
      const sy = (i * 37 + 7) % (game.ch * 0.5);
      ctx.fillRect(sx, sy, 1.5, 1.5);
    }
  }
}

function drawTiles(ctx) {
  const startTx = Math.max(0, Math.floor(game.camX / TILE));
  const endTx = Math.min(WORLD_W - 1, Math.ceil((game.camX + game.cw) / TILE));
  const startTy = Math.max(0, Math.floor(game.camY / TILE));
  const endTy = Math.min(WORLD_H - 1, Math.ceil((game.camY + game.ch) / TILE));

  for (let ty = startTy; ty <= endTy; ty++) {
    for (let tx = startTx; tx <= endTx; tx++) {
      const id = getTile(tx, ty);
      if (id === 0) continue;

      const block = BLOCKS[id];
      const sx = Math.floor(tx * TILE - game.camX);
      const sy = Math.floor(ty * TILE - game.camY);

      // 主色
      ctx.fillStyle = block.color;
      ctx.fillRect(sx, sy, TILE, TILE);

      // 纹理变化
      const shade = getBlockShade(id, tx, ty);
      if (shade && shade.variation !== 0) {
        const v = shade.variation;
        if (v > 0) {
          ctx.fillStyle = `rgba(255,255,255,${Math.abs(v)})`;
        } else {
          ctx.fillStyle = `rgba(0,0,0,${Math.abs(v)})`;
        }
        ctx.fillRect(sx, sy, TILE, TILE);
      }

      // 矿石高光（特殊方块）
      if (id >= 7 && id <= 11 || id >= 36 && id <= 41) {
        ctx.fillStyle = block.shade;
        // 矿石斑点
        const h = ((tx * 73856093) ^ (ty * 19349663)) & 0xffff;
        for (let s = 0; s < 3; s++) {
          const ox = ((h >> (s * 5)) & 0x1f) % (TILE - 6);
          const oy = ((h >> (s * 3)) & 0x1f) % (TILE - 6);
          ctx.fillRect(sx + ox, sy + oy, 4, 4);
        }
        // 新矿石额外光效
        if (id === 37) { // 银矿闪光
          ctx.fillStyle = 'rgba(255,255,255,0.3)';
          ctx.fillRect(sx + 6, sy + 6, 2, 2);
        }
        if (id === 40) { // 硫矿黄色脉
          ctx.fillStyle = '#e8e040';
          ctx.fillRect(sx + 4, sy + TILE - 6, TILE - 8, 2);
        }
      }

      // 方块边缘
      ctx.strokeStyle = `rgba(0,0,0,0.15)`;
      ctx.lineWidth = 1;
      ctx.strokeRect(sx + 0.5, sy + 0.5, TILE - 1, TILE - 1);

      // 草地顶部
      if (id === 1) {
        ctx.fillStyle = '#5fb850';
        ctx.fillRect(sx, sy, TILE, 3);
      }
      // 雪地顶部
      if (id === 23) {
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(sx, sy, TILE, 2);
      }
      // 火把
      if (id === 15) {
        ctx.fillStyle = '#6d4423';
        ctx.fillRect(sx + TILE/2 - 2, sy + TILE/4, 4, TILE * 3/4);
        ctx.fillStyle = '#ffcc40';
        ctx.beginPath();
        ctx.arc(sx + TILE/2, sy + TILE/4, 5, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#ff8800';
        ctx.beginPath();
        ctx.arc(sx + TILE/2, sy + TILE/4, 3, 0, Math.PI * 2);
        ctx.fill();
      }
      // 水面波纹
      if (id === 12) {
        ctx.fillStyle = 'rgba(100,180,255,0.3)';
        ctx.fillRect(sx, sy, TILE, 2);
      }
      // 灯笼（光源）
      if (id === 32) {
        ctx.fillStyle = '#ffcc40';
        ctx.beginPath();
        ctx.arc(sx + TILE/2, sy + TILE/2, 6, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#ff8800';
        ctx.beginPath();
        ctx.arc(sx + TILE/2, sy + TILE/2, 4, 0, Math.PI * 2);
        ctx.fill();
      }
      // 木门
      if (id === 26) {
        ctx.fillStyle = '#6a4a20';
        ctx.fillRect(sx + 3, sy + 3, TILE - 6, TILE - 6);
        ctx.fillStyle = '#3a2a10';
        ctx.fillRect(sx + TILE - 8, sy + TILE/2 - 2, 3, 4);
      }
      // 箱子
      if (id === 27) {
        ctx.fillStyle = '#5a3a1a';
        ctx.fillRect(sx, sy + TILE/3, TILE, 2);
        ctx.fillStyle = '#3a2a10';
        ctx.fillRect(sx + TILE/2 - 2, sy + TILE/2 - 2, 4, 4);
      }
      // 木栅栏
      if (id === 28) {
        ctx.fillStyle = '#4a2e15';
        ctx.fillRect(sx + 3, sy, 3, TILE);
        ctx.fillRect(sx + TILE/2, sy, 3, TILE);
        ctx.fillRect(sx + TILE - 6, sy, 3, TILE);
      }
      // 书架
      if (id === 33) {
        ctx.fillStyle = '#5a3a1a';
        ctx.fillRect(sx, sy + TILE/3, TILE, 1);
        ctx.fillRect(sx, sy + (TILE*2)/3, TILE, 1);
        ctx.fillStyle = '#aa3333';
        ctx.fillRect(sx + 3, sy + 4, 3, TILE/3 - 6);
        ctx.fillStyle = '#3333aa';
        ctx.fillRect(sx + TILE/2, sy + 4, 3, TILE/3 - 6);
        ctx.fillStyle = '#33aa33';
        ctx.fillRect(sx + 3, sy + TILE/3 + 3, 3, TILE/3 - 6);
      }
    }
  }
}

function drawPlayer(ctx) {
  const p = game.player;
  const sx = p.x - game.camX;
  const sy = p.y - game.camY;

  // 无敌闪烁
  if (p.invuln > 0 && Math.floor(p.invuln / 100) % 2 === 0) return;

  ctx.save();

  // 走路动画
  const walkOffset = p.onGround && Math.abs(p.vx) > 0.5 ? Math.sin(p.walkPhase * 10) * 2 : 0;
  const armSwing = p.onGround && Math.abs(p.vx) > 0.5 ? Math.sin(p.walkPhase * 10) * 8 : 0;

  // 身体
  ctx.fillStyle = '#3a6ab8';
  ctx.fillRect(sx + 2, sy + 10 + walkOffset, p.w - 4, p.h - 14);

  // 头
  ctx.fillStyle = '#e8b888';
  ctx.fillRect(sx + 3, sy, p.w - 6, 12);

  // 头发
  ctx.fillStyle = '#3a2a1a';
  ctx.fillRect(sx + 3, sy, p.w - 6, 4);

  // 眼睛
  ctx.fillStyle = '#222';
  if (p.facing > 0) {
    ctx.fillRect(sx + 9, sy + 6, 2, 2);
  } else {
    ctx.fillRect(sx + 7, sy + 6, 2, 2);
  }

  // 手臂（挖掘时挥动）
  let armY = sy + 12 + walkOffset;
  if (game.mining.target) {
    armY += Math.sin(performance.now() * 0.03) * 4;
  }
  ctx.fillStyle = '#e8b888';
  ctx.fillRect(sx + (p.facing > 0 ? p.w - 4 : 0), armY, 4, 10);

  // 腿
  ctx.fillStyle = '#2a4a8a';
  const legOffset = walkOffset;
  ctx.fillRect(sx + 2, sy + p.h - 6 + legOffset, 6, 6);
  ctx.fillRect(sx + p.w - 8, sy + p.h - 6 - legOffset, 6, 6);

  ctx.restore();
}

function drawEnemies(ctx) {
  for (const e of game.enemies) {
    const sx = e.x - game.camX;
    const sy = e.y - game.camY;

    // 弹性变形
    const sq = Math.sin(e.animPhase * 10) * 2;
    const w = e.w + sq;
    const h = e.h - sq;

    // 身体
    ctx.fillStyle = '#44cc44';
    ctx.fillRect(sx + (e.w - w) / 2, sy + (e.h - h), w, h);

    // 眼睛
    ctx.fillStyle = '#222';
    ctx.fillRect(sx + 6, sy + 8, 4, 4);
    ctx.fillRect(sx + e.w - 10, sy + 8, 4, 4);

    // 嘴
    ctx.fillStyle = '#226622';
    ctx.fillRect(sx + 8, sy + 16, e.w - 16, 2);

    // 血条
    if (e.health < e.maxHealth) {
      ctx.fillStyle = 'rgba(0,0,0,0.5)';
      ctx.fillRect(sx, sy - 6, e.w, 3);
      ctx.fillStyle = '#ff3333';
      ctx.fillRect(sx, sy - 6, e.w * (e.health / e.maxHealth), 3);
    }
  }
}

function drawDroppedItems(ctx) {
  for (const item of game.droppedItems) {
    const block = BLOCKS[item.id];
    if (!block) continue;
    const sx = item.x - game.camX;
    const sy = item.y - game.camY;
    const bob = Math.sin(performance.now() * 0.005 + item.x) * 3;
    ctx.fillStyle = block.color;
    ctx.fillRect(sx, sy + bob, 8, 8);
    ctx.strokeStyle = 'rgba(255,255,255,0.4)';
    ctx.strokeRect(sx + 0.5, sy + bob + 0.5, 7, 7);
  }
}

function drawParticles(ctx) {
  for (const p of game.particles) {
    const alpha = Math.max(0, p.life / p.maxLife);
    ctx.globalAlpha = alpha;
    ctx.fillStyle = p.color;
    ctx.fillRect(p.x - game.camX, p.y - game.camY, p.size, p.size);
  }
  ctx.globalAlpha = 1;
}

function drawLighting(ctx) {
  const t = game.time;
  let darkness = 0;

  // 夜晚暗度
  if (t > 0.5 && t < 0.95) {
    if (t < 0.6) darkness = (t - 0.5) / 0.1 * 0.5;
    else if (t < 0.85) darkness = 0.5;
    else darkness = (0.95 - t) / 0.1 * 0.5;
  }

  // 玩家在地下时加暗
  const p = game.player;
  const pTy = Math.floor((p.y + p.h / 2) / TILE);
  const surface = game.surface[Math.floor(p.x / TILE)] || WORLD_H * 0.35;
  if (pTy > surface + 3) {
    const depth = (pTy - surface) / 20;
    darkness = Math.max(darkness, Math.min(0.75, depth * 0.3 + 0.3));
  }

  // 即使白天也收集光源位置（用于暖色光晕）
  const lightSources = [];
  const startTx = Math.max(0, Math.floor(game.camX / TILE) - 1);
  const endTx = Math.min(WORLD_W, Math.ceil((game.camX + game.cw) / TILE) + 1);
  const startTy = Math.max(0, Math.floor(game.camY / TILE) - 1);
  const endTy = Math.min(WORLD_H, Math.ceil((game.camY + game.ch) / TILE) + 1);
  for (let ty = startTy; ty <= endTy; ty++) {
    for (let tx = startTx; tx <= endTx; tx++) {
      const tileId = getTile(tx, ty);
      const block = BLOCKS[tileId];
      if (!block || !block.light || block.light === 0) continue;
      lightSources.push({
        x: tx * TILE + TILE / 2 - game.camX,
        y: ty * TILE + TILE / 2 - game.camY,
        radius: block.light,
        id: tileId,
      });
    }
  }

  // 暖色光晕（始终绘制，让火把/灯笼有温暖氛围）
  ctx.save();
  ctx.globalCompositeOperation = 'lighter';
  const now = performance.now();
  for (const src of lightSources) {
    // 火焰闪烁
    let flicker = 1;
    if (src.id === 15 || src.id === 32 || src.id === 18) {
      flicker = 0.82 + Math.sin(now * 0.012 + src.x * 0.1) * 0.06 + Math.sin(now * 0.028 + src.y * 0.07) * 0.04 + (Math.random() - 0.5) * 0.08;
    }
    const r = TILE * src.radius * flicker;
    const glowAlpha = src.id === 15 ? 0.18 : src.id === 32 ? 0.22 : 0.12;
    const grad = ctx.createRadialGradient(src.x, src.y, 0, src.x, src.y, r);
    grad.addColorStop(0, `rgba(255,180,60,${glowAlpha * flicker})`);
    grad.addColorStop(0.3, `rgba(255,120,30,${glowAlpha * 0.5 * flicker})`);
    grad.addColorStop(1, 'rgba(255,80,0,0)');
    ctx.fillStyle = grad;
    ctx.fillRect(src.x - r, src.y - r, r * 2, r * 2);
  }
  ctx.restore();

  if (darkness < 0.01) return;

  // 创建暗层
  ctx.save();
  ctx.fillStyle = `rgba(5,5,20,${darkness})`;
  ctx.fillRect(0, 0, game.cw, game.ch);

  // 在玩家周围开光
  ctx.globalCompositeOperation = 'destination-out';
  const pSx = p.x + p.w / 2 - game.camX;
  const pSy = p.y + p.h / 2 - game.camY;
  const lightR = TILE * 5;
  const grad = ctx.createRadialGradient(pSx, pSy, 0, pSx, pSy, lightR);
  grad.addColorStop(0, `rgba(0,0,0,${darkness})`);
  grad.addColorStop(0.5, `rgba(0,0,0,${darkness * 0.5})`);
  grad.addColorStop(1, 'rgba(0,0,0,0)');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, game.cw, game.ch);

  // 火把/灯笼等光源 — 在暗层中开光（带闪烁）
  for (const src of lightSources) {
    let flicker = 1;
    if (src.id === 15 || src.id === 32 || src.id === 18) {
      flicker = 0.82 + Math.sin(now * 0.012 + src.x * 0.1) * 0.06 + Math.sin(now * 0.028 + src.y * 0.07) * 0.04 + (Math.random() - 0.5) * 0.08;
    }
    const r = TILE * src.radius * flicker;
    const lg = ctx.createRadialGradient(src.x, src.y, 0, src.x, src.y, r);
    lg.addColorStop(0, `rgba(0,0,0,${darkness})`);
    lg.addColorStop(0.3, `rgba(0,0,0,${darkness * 0.6})`);
    lg.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = lg;
    ctx.fillRect(src.x - r, src.y - r, r * 2, r * 2);
  }

  ctx.globalCompositeOperation = 'source-over';
  ctx.restore();
}

function drawMiningProgress(ctx) {
  if (!game.mining.target) return;
  const tx = game.mining.x;
  const ty = game.mining.y;
  const block = BLOCKS[getTile(tx, ty)];
  if (!block) return;

  const sx = tx * TILE - game.camX;
  const sy = ty * TILE - game.camY;
  const prog = game.mining.progress / (block.hardness * 8);

  // 裂纹
  ctx.fillStyle = `rgba(0,0,0,${prog * 0.5})`;
  ctx.fillRect(sx, sy, TILE, TILE);

  // 裂纹线条
  ctx.strokeStyle = `rgba(0,0,0,${prog * 0.8})`;
  ctx.lineWidth = 1;
  if (prog > 0.2) {
    ctx.beginPath();
    ctx.moveTo(sx + 4, sy + 4);
    ctx.lineTo(sx + TILE - 4, sy + TILE - 4);
    ctx.moveTo(sx + TILE - 4, sy + 4);
    ctx.lineTo(sx + 4, sy + TILE - 4);
    ctx.stroke();
  }
  if (prog > 0.5) {
    ctx.beginPath();
    ctx.moveTo(sx, sy + TILE / 2);
    ctx.lineTo(sx + TILE, sy + TILE / 2);
    ctx.moveTo(sx + TILE / 2, sy);
    ctx.lineTo(sx + TILE / 2, sy + TILE);
    ctx.stroke();
  }
}

function drawMouseTarget(ctx) {
  const tx = Math.floor(game.mouse.worldX / TILE);
  const ty = Math.floor(game.mouse.worldY / TILE);
  const p = game.player;
  const px = Math.floor((p.x + p.w / 2) / TILE);
  const py = Math.floor((p.y + p.h / 2) / TILE);
  const dist = Math.abs(tx - px) + Math.abs(ty - py);
  if (dist > REACH) return;

  const tileId = getTile(tx, ty);
  const sx = tx * TILE - game.camX;
  const sy = ty * TILE - game.camY;

  // 检查工具需求
  const block = BLOCKS[tileId];
  let canMine = true;
  if (block && block.tool) {
    const equippedId = game.hotbar[game.selectedSlot];
    const eqBlock = equippedId > 0 ? BLOCKS[equippedId] : null;
    const toolTier = (eqBlock && eqBlock.toolTier) ? eqBlock.toolTier : 0;
    if (toolTier < block.tool) canMine = false;
  }

  if (tileId === 0) {
    ctx.strokeStyle = 'rgba(100,255,100,0.5)';
  } else if (!canMine) {
    ctx.strokeStyle = 'rgba(255,80,80,0.7)';
  } else {
    ctx.strokeStyle = 'rgba(255,255,255,0.5)';
  }
  ctx.lineWidth = 2;
  ctx.strokeRect(sx, sy, TILE, TILE);

  // 显示工具需求
  if (!canMine && block) {
    const tierNames = ['', '木镐', '石镐', '铁镐'];
    ctx.fillStyle = 'rgba(255,80,80,0.9)';
    ctx.font = 'bold 9px sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(`需要${tierNames[block.tool]}`, sx + TILE / 2, sy - 6);
  }
}

// ==================== UI ====================
function drawUI(ctx) {
  // 生命值
  const healthBarW = 200;
  const healthBarH = 18;
  ctx.fillStyle = 'rgba(0,0,0,0.6)';
  ctx.fillRect(10, 10, healthBarW + 4, healthBarH + 4);
  ctx.fillStyle = '#1a1a2e';
  ctx.fillRect(12, 12, healthBarW, healthBarH);
  const hpct = game.player.health / game.player.maxHealth;
  ctx.fillStyle = hpct > 0.5 ? '#22cc44' : (hpct > 0.25 ? '#ccaa22' : '#cc3333');
  ctx.fillRect(12, 12, healthBarW * hpct, healthBarH);
  ctx.fillStyle = '#fff';
  ctx.font = 'bold 12px sans-serif';
  ctx.textAlign = 'center';
  ctx.fillText(`❤ ${Math.ceil(game.player.health)} / ${game.player.maxHealth}`, 12 + healthBarW / 2, 12 + 13);

  // 血量回复指示
  const timeSinceDamage = performance.now() - (game.player.lastDamageTime || 0);
  if (game.player.health < game.player.maxHealth && timeSinceDamage > 4000 && game.player.invuln <= 0) {
    const pulse = 0.4 + Math.sin(performance.now() * 0.005) * 0.3;
    ctx.strokeStyle = `rgba(34,255,68,${pulse})`;
    ctx.lineWidth = 2;
    ctx.strokeRect(10, 10, healthBarW + 4, healthBarH + 4);
    ctx.fillStyle = `rgba(34,255,68,${pulse})`;
    ctx.font = 'bold 9px sans-serif';
    ctx.textAlign = 'left';
    ctx.fillText('＋回复中', 12 + healthBarW + 10, 24);
  }

  // 装备工具显示
  const equippedId = game.hotbar[game.selectedSlot];
  if (equippedId > 0) {
    const eqBlock = BLOCKS[equippedId];
    if (eqBlock && eqBlock.toolTier) {
      const tierNames = ['', '木镐', '石镐', '铁镐'];
      ctx.fillStyle = 'rgba(0,0,0,0.5)';
      ctx.fillRect(10, 36, 130, 20);
      ctx.fillStyle = '#ffaa44';
      ctx.font = 'bold 11px sans-serif';
      ctx.textAlign = 'left';
      ctx.textBaseline = 'middle';
      ctx.fillText(`⛏️ ${tierNames[eqBlock.toolTier]} Lv.${eqBlock.toolTier}`, 16, 47);
    }
  }

  // 昼夜指示
  const timeText = game.time < 0.5 ? `☀ 白天` : `🌙 夜晚`;
  ctx.fillStyle = 'rgba(0,0,0,0.5)';
  ctx.fillRect(game.cw - 120, 10, 110, 22);
  ctx.fillStyle = '#fff';
  ctx.font = '12px sans-serif';
  ctx.textAlign = 'left';
  ctx.fillText(timeText, game.cw - 110, 25);

  // 已发现元素计数
  const totalElements = Object.keys(PERIODIC_TABLE).length;
  const foundCount = game.discoveredElements.size;
  ctx.fillStyle = 'rgba(0,0,0,0.5)';
  ctx.fillRect(game.cw - 120, 36, 110, 22);
  ctx.fillStyle = '#88ffcc';
  ctx.font = 'bold 11px sans-serif';
  ctx.textAlign = 'left';
  ctx.fillText(`🔬 ${foundCount}/${totalElements} 元素`, game.cw - 110, 51);

  // FPS
  ctx.fillStyle = 'rgba(0,0,0,0.4)';
  ctx.fillRect(game.cw - 60, game.ch - 24, 50, 18);
  ctx.fillStyle = '#88ff88';
  ctx.font = '11px monospace';
  ctx.fillText(`${game.fps}fps`, game.cw - 55, game.ch - 11);

  // 热栏
  drawHotbar(ctx);

  // 操作提示
  if (game.time === 0 || performance.now() < 8000) {
    ctx.fillStyle = 'rgba(0,0,0,0.6)';
    ctx.fillRect(game.cw / 2 - 180, game.ch - 60, 360, 36);
    ctx.fillStyle = '#fff';
    ctx.font = '11px sans-serif';
    ctx.textAlign = 'center';
    if (game.touchInput.isTouch) {
      ctx.fillText('摇杆移动 | ⬆️跳跃 | ⛏️挖掘(面前方块) | 🧱放置 | 点怪对战', game.cw / 2, game.ch - 42);
      ctx.fillText('🎒背包 | 🔧合成 | 点击热栏选栏 | 右键工作台/熔炉打开UI', game.cw / 2, game.ch - 28);
    } else {
      ctx.fillText('A/D移动 | W/空格跳跃 | 左键挖掘 | 右键放置/使用工作站 | 1-0选栏 | E背包 | Tab合成', game.cw / 2, game.ch - 42);
      ctx.fillText('右键工作台/熔炉打开独立UI | 挖矿获得材料合成工具 | 挖掘新矿石发现化学元素', game.cw / 2, game.ch - 28);
    }
  }
}

function drawHotbar(ctx) {
  const slotSize = 44;
  const gap = 4;
  const totalW = 10 * slotSize + 9 * gap;
  const startX = (game.cw - totalW) / 2;
  // 触屏设备热栏上移，避免与摇杆/按钮重叠
  const y = game.ch - slotSize - (game.touchInput.isTouch ? 20 : 14);

  for (let i = 0; i < 10; i++) {
    const x = startX + i * (slotSize + gap);
    const isSelected = i === game.selectedSlot;
    const isHovered = i === game.hoveredSlot;

    // 背景
    ctx.fillStyle = isSelected ? 'rgba(0,212,255,0.25)' : (isHovered ? 'rgba(255,255,255,0.12)' : 'rgba(0,0,0,0.55)');
    ctx.fillRect(x, y, slotSize, slotSize);

    // 边框
    ctx.strokeStyle = isSelected ? '#00d4ff' : (isHovered ? 'rgba(255,255,255,0.5)' : 'rgba(255,255,255,0.2)');
    ctx.lineWidth = isSelected ? 2.5 : 1.5;
    ctx.strokeRect(x + 1, y + 1, slotSize - 2, slotSize - 2);

    // 方块图标
    const blockId = game.hotbar[i];
    if (blockId > 0 && game.hotbarCounts[i] > 0) {
      const iconSize = 28;
      const iconX = x + (slotSize - iconSize) / 2;
      const iconY = y + (slotSize - iconSize) / 2 - 2;
      drawBlockIcon(ctx, iconX, iconY, iconSize, blockId);

      // 元素指示器
      const element = BLOCK_ELEMENTS[blockId];
      if (element) {
        const elemInfo = ELEMENT_INFO[element];
        ctx.fillStyle = elemInfo.color;
        ctx.beginPath();
        ctx.arc(x + 7, y + 7, 4, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = 'rgba(0,0,0,0.4)';
        ctx.lineWidth = 1;
        ctx.stroke();
      }

      // 数量
      const count = game.hotbarCounts[i];
      if (count > 0) {
        ctx.fillStyle = 'rgba(0,0,0,0.75)';
        ctx.fillRect(x + slotSize - 20, y + slotSize - 16, 18, 14);
        ctx.fillStyle = '#fff';
        ctx.font = 'bold 11px sans-serif';
        ctx.textAlign = 'right';
        ctx.textBaseline = 'middle';
        ctx.fillText(count, x + slotSize - 4, y + slotSize - 9);
      }
    }

    // 槽位号
    ctx.fillStyle = isSelected ? 'rgba(0,212,255,0.9)' : 'rgba(255,255,255,0.35)';
    ctx.font = 'bold 9px sans-serif';
    ctx.textAlign = 'left';
    ctx.textBaseline = 'top';
    ctx.fillText(i === 9 ? '0' : String(i + 1), x + 4, y + 4);
  }

  // 悬停提示
  if (game.hoveredSlot >= 0) {
    const blockId = game.hotbar[game.hoveredSlot];
    if (blockId > 0 && game.hotbarCounts[game.hoveredSlot] > 0) {
      const block = BLOCKS[blockId];
      const element = BLOCK_ELEMENTS[blockId];
      const elemInfo = element ? ELEMENT_INFO[element] : null;
      let tipText = block.name;
      if (elemInfo) tipText += ` [${elemInfo.icon}${elemInfo.name}]`;
      if (block.toolTier) {
        const tierNames = ['', '木镐', '石镐', '铁镐'];
        tipText += ` [⛏ Lv.${block.toolTier} ${tierNames[block.toolTier]}]`;
      }
      tipText += ` x${game.hotbarCounts[game.hoveredSlot]}`;

      ctx.font = 'bold 12px sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      const tipW = ctx.measureText(tipText).width + 20;
      const tipX = startX + game.hoveredSlot * (slotSize + gap) + slotSize / 2;
      const tipY = y - 30;

      ctx.fillStyle = 'rgba(0,0,0,0.85)';
      ctx.fillRect(tipX - tipW / 2, tipY - 12, tipW, 24);
      ctx.strokeStyle = 'rgba(0,212,255,0.4)';
      ctx.lineWidth = 1;
      ctx.strokeRect(tipX - tipW / 2 + 0.5, tipY - 11.5, tipW - 1, 23);
      ctx.fillStyle = '#e0e8f0';
      ctx.fillText(tipText, tipX, tipY);
    }
  }

  // 工作站提示
  const hasWB = hasCraftingStation('workbench');
  const hasFN = hasCraftingStation('furnace');
  if (hasWB || hasFN) {
    let stText = '';
    if (hasWB) stText += '🔨 工作台(右键打开)';
    if (hasWB && hasFN) stText += '  ';
    if (hasFN) stText += '🔥 熔炉(右键打开)';
    ctx.fillStyle = 'rgba(0,0,0,0.6)';
    ctx.fillRect(startX, y - 24, ctx.measureText(stText).width + 20, 20);
    ctx.fillStyle = '#88ff88';
    ctx.font = 'bold 11px sans-serif';
    ctx.textAlign = 'left';
    ctx.textBaseline = 'middle';
    ctx.fillText(stText, startX + 8, y - 14);
  }
}

// 绘制方块像素图标（热栏/合成界面通用）
function drawBlockIcon(ctx, x, y, size, blockId) {
  const block = BLOCKS[blockId];
  if (!block || !block.color) return;

  const s = size;
  // 底色
  ctx.fillStyle = block.color;
  ctx.fillRect(x, y, s, s);

  const shade = block.shade || block.color;
  const id = blockId;

  // 根据方块类型绘制不同的像素纹理
  if (id === 4) {
    // 原木：年轮纹理
    ctx.fillStyle = shade;
    ctx.fillRect(x, y + 2, s, 2);
    ctx.fillRect(x, y + s - 4, s, 2);
    ctx.fillStyle = 'rgba(0,0,0,0.2)';
    ctx.fillRect(x + s/2 - 1, y + 4, 2, s - 8);
  } else if (id === 3) {
    // 石头：随机斑点
    ctx.fillStyle = shade;
    ctx.fillRect(x + 3, y + 4, 4, 3);
    ctx.fillRect(x + s - 8, y + 6, 3, 4);
    ctx.fillRect(x + 5, y + s - 8, 4, 3);
  } else if (id === 2) {
    // 泥土：深色颗粒
    ctx.fillStyle = shade;
    ctx.fillRect(x + 2, y + 3, 3, 3);
    ctx.fillRect(x + s - 6, y + 5, 3, 2);
    ctx.fillRect(x + 4, y + s - 6, 2, 3);
  } else if (id === 1) {
    // 草地：绿色顶部
    ctx.fillStyle = '#5fb850';
    ctx.fillRect(x, y, s, 4);
    ctx.fillStyle = shade;
    ctx.fillRect(x + 3, y + s - 4, 3, 3);
  } else if (id === 6) {
    // 沙子：亮点
    ctx.fillStyle = 'rgba(255,255,200,0.4)';
    ctx.fillRect(x + 2, y + 3, 2, 2);
    ctx.fillRect(x + s - 5, y + 5, 2, 2);
    ctx.fillRect(x + 4, y + s - 4, 2, 2);
  } else if (id === 13) {
    // 木板：水平纹路
    ctx.fillStyle = shade;
    ctx.fillRect(x, y + s/3, s, 1);
    ctx.fillRect(x, y + (s*2)/3, s, 1);
    ctx.fillStyle = 'rgba(0,0,0,0.15)';
    ctx.fillRect(x + s/2, y, 1, s/3);
    ctx.fillRect(x + s/3, y + s/3, 1, s/3);
  } else if (id >= 7 && id <= 11) {
    // 矿石：矿脉亮点
    ctx.fillStyle = shade;
    ctx.fillRect(x + 3, y + 4, 4, 4);
    ctx.fillRect(x + s - 7, y + 6, 3, 3);
    ctx.fillRect(x + 5, y + s - 8, 3, 3);
    if (id === 11) {
      ctx.fillStyle = 'rgba(255,255,255,0.5)';
      ctx.fillRect(x + 4, y + 5, 2, 2);
    }
  } else if (id === 15) {
    // 火把
    ctx.fillStyle = '#6d4423';
    ctx.fillRect(x + s/2 - 2, y + s/3, 4, s * 2/3);
    ctx.fillStyle = '#ffcc40';
    ctx.beginPath();
    ctx.arc(x + s/2, y + s/3, 5, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#ff8800';
    ctx.beginPath();
    ctx.arc(x + s/2, y + s/3, 3, 0, Math.PI * 2);
    ctx.fill();
  } else if (id === 17) {
    // 工作台：网格
    ctx.fillStyle = shade;
    ctx.fillRect(x, y, s, 3);
    ctx.fillRect(x, y + s/2, s, 1);
    ctx.fillRect(x + s/2, y + 3, 1, s - 3);
  } else if (id === 18) {
    // 熔炉：开口
    ctx.fillStyle = shade;
    ctx.fillRect(x, y, s, 3);
    ctx.fillStyle = '#ff6600';
    ctx.fillRect(x + s/3, y + s/3, s/3, s/3);
  } else if (id === 16) {
    // 玻璃：高光
    ctx.fillStyle = 'rgba(255,255,255,0.3)';
    ctx.fillRect(x + 2, y + 2, 3, s - 4);
  } else if (id === 14 || id === 22) {
    // 砖块/石砖：砖缝
    ctx.fillStyle = shade;
    ctx.fillRect(x, y + s/2, s, 1);
    ctx.fillRect(x + s/2, y, 1, s/2);
    ctx.fillRect(x + s/4, y + s/2, 1, s/2);
  } else if (id === 12) {
    // 水：波纹
    ctx.fillStyle = 'rgba(100,180,255,0.4)';
    ctx.fillRect(x, y + 2, s, 2);
    ctx.fillRect(x, y + s/2, s, 1);
  } else if (id === 23) {
    // 雪：白点
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(x, y, s, 3);
  } else if (id === 24) {
    // 冰：裂纹
    ctx.fillStyle = 'rgba(255,255,255,0.3)';
    ctx.fillRect(x + 2, y + 3, 4, 1);
    ctx.fillRect(x + s - 6, y + s - 4, 4, 1);
  } else if (id === 25) {
    // 黑曜石：紫色斑点
    ctx.fillStyle = '#3a1a4e';
    ctx.fillRect(x + 3, y + 4, 3, 3);
    ctx.fillRect(x + s - 6, y + s - 7, 3, 3);
  } else if (id === 26) {
    // 木门
    ctx.fillStyle = shade;
    ctx.fillRect(x + 2, y + 2, s - 4, s - 4);
    ctx.fillStyle = '#5a3a1a';
    ctx.fillRect(x + s - 8, y + s/2 - 1, 3, 3);
  } else if (id === 27) {
    // 箱子
    ctx.fillStyle = shade;
    ctx.fillRect(x, y + s/3, s, 2);
    ctx.fillStyle = '#5a3a1a';
    ctx.fillRect(x + s/2 - 2, y + s/2 - 1, 4, 3);
  } else if (id === 28) {
    // 栅栏
    ctx.fillStyle = shade;
    ctx.fillRect(x + 2, y, 2, s);
    ctx.fillRect(x + s/2 - 1, y, 2, s);
    ctx.fillRect(x + s - 4, y, 2, s);
    ctx.fillRect(x, y + s/3, s, 2);
    ctx.fillRect(x, y + (s*2)/3, s, 2);
  } else if (id === 29 || id === 30 || id === 34) {
    // 金属砖：光泽
    ctx.fillStyle = 'rgba(255,255,255,0.3)';
    ctx.fillRect(x + 2, y + 2, s - 4, 2);
    ctx.fillStyle = shade;
    ctx.fillRect(x, y + s - 3, s, 3);
  } else if (id === 31 || id === 35) {
    // 晶体砖：闪光
    ctx.fillStyle = 'rgba(255,255,255,0.5)';
    ctx.fillRect(x + 3, y + 3, 3, 3);
    ctx.fillRect(x + s - 6, y + s - 6, 2, 2);
    ctx.fillStyle = shade;
    ctx.fillRect(x, y + s/2, s, 1);
  } else if (id === 32) {
    // 灯笼
    ctx.fillStyle = '#6d4423';
    ctx.fillRect(x + 2, y, s - 4, 3);
    ctx.fillRect(x + 2, y + s - 3, s - 4, 3);
    ctx.fillStyle = '#ffcc40';
    ctx.beginPath();
    ctx.arc(x + s/2, y + s/2, s/3, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#ff8800';
    ctx.beginPath();
    ctx.arc(x + s/2, y + s/2, s/4, 0, Math.PI * 2);
    ctx.fill();
  } else if (id === 33) {
    // 书架
    ctx.fillStyle = shade;
    ctx.fillRect(x, y + s/3, s, 1);
    ctx.fillRect(x, y + (s*2)/3, s, 1);
    ctx.fillStyle = '#aa3333';
    ctx.fillRect(x + 3, y + 4, 3, s/3 - 6);
    ctx.fillStyle = '#3333aa';
    ctx.fillRect(x + s/2, y + 4, 3, s/3 - 6);
    ctx.fillStyle = '#33aa33';
    ctx.fillRect(x + 3, y + s/3 + 3, 3, s/3 - 6);
  } else if (id === 19 || id === 20 || id === 21) {
    // 锭块：金属光泽
    ctx.fillStyle = 'rgba(255,255,255,0.25)';
    ctx.fillRect(x + 2, y + 2, s - 4, 2);
    ctx.fillStyle = shade;
    ctx.fillRect(x, y + s - 4, s, 4);
  } else if (id === 5) {
    // 树叶
    ctx.fillStyle = shade;
    ctx.fillRect(x + 3, y + 3, 3, 3);
    ctx.fillRect(x + s - 6, y + 5, 3, 3);
    ctx.fillRect(x + 5, y + s - 6, 3, 2);
  } else if (id >= 36 && id <= 41) {
    // 新矿石：矿脉亮点
    ctx.fillStyle = shade;
    ctx.fillRect(x + 3, y + 4, 4, 4);
    ctx.fillRect(x + s - 7, y + 6, 3, 3);
    ctx.fillRect(x + 5, y + s - 8, 3, 3);
    if (id === 37) { // 银矿白光
      ctx.fillStyle = 'rgba(255,255,255,0.5)';
      ctx.fillRect(x + 4, y + 5, 2, 2);
    }
    if (id === 40) { // 硫矿黄色
      ctx.fillStyle = '#e8e040';
      ctx.fillRect(x + 4, y + s - 5, s - 8, 2);
    }
    if (id === 41) { // 石英透明感
      ctx.fillStyle = 'rgba(255,255,255,0.4)';
      ctx.fillRect(x + 4, y + 5, 2, 2);
      ctx.fillRect(x + s - 6, y + s - 7, 2, 2);
    }
  } else if (id >= 42 && id <= 46) {
    // 新冶炼锭块
    ctx.fillStyle = 'rgba(255,255,255,0.2)';
    ctx.fillRect(x + 2, y + 2, s - 4, 2);
    ctx.fillStyle = shade;
    ctx.fillRect(x, y + s - 4, s, 4);
    if (id === 43) { // 银锭高光
      ctx.fillStyle = 'rgba(255,255,255,0.4)';
      ctx.fillRect(x + 4, y + 4, 3, 2);
    }
  } else if (id === 47) {
    // 青铜块
    ctx.fillStyle = shade;
    ctx.fillRect(x, y + s/2, s, 1);
    ctx.fillStyle = 'rgba(255,180,80,0.3)';
    ctx.fillRect(x + 2, y + 2, s - 4, 2);
  } else if (id === 48) {
    // 焊料块
    ctx.fillStyle = shade;
    ctx.fillRect(x + 2, y + 2, 3, 3);
    ctx.fillRect(x + s - 5, y + s - 5, 3, 3);
  } else if (id === 49) {
    // 琥珀金
    ctx.fillStyle = 'rgba(255,255,200,0.4)';
    ctx.fillRect(x + 3, y + 3, 3, 3);
    ctx.fillRect(x + s - 6, y + s - 6, 2, 2);
  } else if (id === 50) {
    // 透镜
    ctx.fillStyle = 'rgba(255,255,255,0.4)';
    ctx.beginPath();
    ctx.arc(x + s/2, y + s/2, s/3, 0, Math.PI * 2);
    ctx.fill();
  } else if (id === 51) {
    // 导电板
    ctx.fillStyle = shade;
    ctx.fillRect(x + 2, y + 2, 3, 3);
    ctx.fillRect(x + s - 5, y + 2, 3, 3);
    ctx.fillStyle = 'rgba(0,200,255,0.3)';
    ctx.fillRect(x + 5, y + s/2 - 1, s - 10, 2);
  } else if (id === 52) {
    // 硫磺弹
    ctx.fillStyle = shade;
    ctx.beginPath();
    ctx.arc(x + s/2, y + s/2, s/3, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#ff6600';
    ctx.fillRect(x + s/2 - 1, y + 2, 2, 4);
  } else if (id === 53) {
    // 毒药瓶
    ctx.fillStyle = shade;
    ctx.fillRect(x + s/3, y, s/3, 4);
    ctx.fillStyle = block.color;
    ctx.beginPath();
    ctx.arc(x + s/2, y + s/2 + 2, s/3, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = 'rgba(155,89,182,0.5)';
    ctx.fillRect(x + 4, y + s/2, 3, 2);
  } else if (id === 54) {
    // 半导体
    ctx.fillStyle = shade;
    ctx.fillRect(x + 2, y + s/2 - 1, s - 4, 2);
    ctx.fillStyle = 'rgba(0,255,100,0.3)';
    ctx.fillRect(x + 3, y + 3, 3, 3);
    ctx.fillStyle = 'rgba(255,0,0,0.3)';
    ctx.fillRect(x + s - 6, y + s - 6, 3, 3);
  } else if (id === 55) {
    // 电池组
    ctx.fillStyle = shade;
    ctx.fillRect(x, y + 2, s, s - 4);
    ctx.fillStyle = '#ff3333';
    ctx.fillRect(x + 2, y + 4, s/2 - 2, s - 8);
    ctx.fillStyle = '#3333ff';
    ctx.fillRect(x + s/2, y + 4, s/2 - 2, s - 8);
    ctx.fillStyle = '#888';
    ctx.fillRect(x + s/2 - 1, y, 2, 3);
  } else if (id === 56 || id === 57 || id === 58) {
    // 镐子工具
    // 颜色根据等级变化
    const headColors = { 56:'#9a6b3a', 57:'#7a7a80', 58:'#c0c0c8' };
    const headDark = { 56:'#6d4423', 57:'#5a5a5f', 58:'#909098' };
    const hc = headColors[id];
    const hd = headDark[id];
    // 手柄
    ctx.fillStyle = '#6d4423';
    ctx.fillRect(x + s/2 - 1, y + s/3, 3, s * 2/3);
    // 镐头
    ctx.fillStyle = hc;
    ctx.fillRect(x + 2, y + 2, s - 4, 5);
    ctx.fillStyle = hd;
    ctx.fillRect(x + 2, y + 5, s - 4, 2);
    // 高光
    ctx.fillStyle = 'rgba(255,255,255,0.3)';
    ctx.fillRect(x + 3, y + 3, s - 6, 1);
  }

  // 边框
  ctx.strokeStyle = 'rgba(0,0,0,0.3)';
  ctx.lineWidth = 1;
  ctx.strokeRect(x + 0.5, y + 0.5, s - 1, s - 1);
}

// ==================== 合成界面 ====================
function drawCrafting() {
  const overlay = document.getElementById('crafting-overlay');
  const panel = document.getElementById('crafting-panel');
  overlay.style.display = 'flex';

  // 设置面板样式
  panel.className = '';
  panel.classList.add('mode-' + game.craftingMode);

  const mode = game.craftingMode;
  const modeConfig = {
    'hand':      { title: '✋ 手工合成', icon: '✋', needStation: false },
    'workbench': { title: '🔨 工作台', icon: '🔨', needStation: true, station: 'workbench' },
    'furnace':   { title: '🔥 熔炉', icon: '🔥', needStation: true, station: 'furnace' },
  };
  const cfg = modeConfig[mode] || modeConfig['hand'];

  const hasStation = cfg.needStation ? hasCraftingStation(cfg.station) : true;

  // 筛选当前模式的配方
  const needKey = mode === 'hand' ? 'none' : mode;
  const filteredRecipes = RECIPES.filter(r => r.needs === needKey);

  let html = `<div class="craft-title">${cfg.title}</div>`;

  if (cfg.needStation) {
    html += `<div class="craft-stations">`;
    html += `<span class="station-badge ${hasStation ? 'active' : 'inactive'}">${cfg.icon} ${cfg.station === 'workbench' ? '工作台' : '熔炉'} ${hasStation ? '✓ 附近' : '✗ 不在附近'}</span>`;
    html += `</div>`;
  }

  if (filteredRecipes.length === 0) {
    html += '<div class="craft-empty">暂无可用配方</div>';
  } else {
    html += '<div class="craft-list">';

    for (const r of filteredRecipes) {
      const outId = parseInt(Object.keys(r.output)[0]);
      const outCount = r.output[outId];
      const outBlock = BLOCKS[outId];
      let inputs = '';
      let canCraft = hasStation;
      for (const [id, count] of Object.entries(r.input)) {
        const b = BLOCKS[parseInt(id)];
        const have = game.inventory[parseInt(id)] || 0;
        const enough = have >= count;
        if (!enough) canCraft = false;
        inputs += `<span class="recipe-item ${enough ? '' : 'missing'}">${b.name}×${count}</span>`;
      }

      // 化学方程式
      let chemHtml = '';
      if (r.chem) {
        chemHtml = `<div class="recipe-chem">⚗ ${r.chem}</div>`;
      }

      // 工具需求提示
      let toolHtml = '';
      if (outBlock && outBlock.toolTier) {
        const tierNames = ['', '木镐', '石镐', '铁镐'];
        toolHtml = `<div class="recipe-tool-req">⛏ 挖掘等级 ${outBlock.toolTier}（${tierNames[outBlock.toolTier]}）</div>`;
      }

      html += `
        <div class="recipe-card ${canCraft ? '' : 'dimmed'}" data-idx="${RECIPES.indexOf(r)}">
          <canvas class="recipe-icon-canvas" width="32" height="32" data-block="${outId}"></canvas>
          <div class="recipe-info">
            <div class="recipe-name">${r.name} ×${outCount}</div>
            <div class="recipe-inputs">${inputs}</div>
            ${chemHtml}
            ${toolHtml}
          </div>
          <div class="recipe-btn ${canCraft ? '' : 'disabled'}">${canCraft ? '合成' : '🔒'}</div>
        </div>`;
    }

    html += '</div>';
  }

  html += `<div class="craft-close-btn" id="craft-close-btn">关闭 (Tab/Esc)</div>`;

  panel.innerHTML = html;

  // 绘制配方图标
  panel.querySelectorAll('.recipe-icon-canvas').forEach(cv => {
    const bid = parseInt(cv.dataset.block);
    const c = cv.getContext('2d');
    drawBlockIcon(c, 0, 0, 32, bid);
  });

  // 绑定合成按钮
  panel.querySelectorAll('.recipe-card[data-idx]').forEach(card => {
    card.addEventListener('click', () => {
      const idx = parseInt(card.dataset.idx);
      craftRecipe(RECIPES[idx]);
    });
  });

  // 关闭按钮
  const closeBtn = document.getElementById('craft-close-btn');
  if (closeBtn) {
    closeBtn.addEventListener('click', () => { game.craftingOpen = false; });
  }
}

function craftRecipe(r) {
  // 再次检查
  if (r.needs === 'workbench' && !hasCraftingStation('workbench')) { showToast('需要工作台！', 1000); return; }
  if (r.needs === 'furnace' && !hasCraftingStation('furnace')) { showToast('需要熔炉！', 1000); return; }
  for (const [id, count] of Object.entries(r.input)) {
    if ((game.inventory[parseInt(id)] || 0) < count) { showToast('材料不足！', 1000); return; }
  }

  // 消耗材料
  for (const [id, count] of Object.entries(r.input)) {
    removeItem(parseInt(id), count);
  }
  // 获得产物
  for (const [id, count] of Object.entries(r.output)) {
    addItem(parseInt(id), count);
  }
  sfx('craft');
  showToast(`合成成功：${r.name}！`, 1500);
  updateHotbar();
  game.craftingDirty = true;
}

// ==================== 背包界面 ====================
function drawInventory() {
  const overlay = document.getElementById('inventory-overlay');
  const panel = document.getElementById('inventory-panel');
  overlay.style.display = 'flex';

  const items = Object.entries(game.inventory).filter(([id, c]) => c > 0);

  let html = '<div class="inv-title">🎒 背包</div>';

  if (items.length === 0) {
    html += '<div class="inv-empty">背包空空如也<br>去挖掘收集资源吧！</div>';
  } else {
    html += '<div class="inv-grid">';
    for (const [id, count] of items) {
      const blockId = parseInt(id);
      const block = BLOCKS[blockId];
      if (!block) continue;
      const inHotbar = game.hotbar.includes(blockId);
      const element = BLOCK_ELEMENTS[blockId];
      const elemInfo = element ? ELEMENT_INFO[element] : null;

      html += `<div class="inv-slot ${inHotbar ? 'in-hotbar' : ''}" data-id="${blockId}">`;
      if (elemInfo) {
        html += `<div class="inv-slot-elem" style="background:${elemInfo.color}"></div>`;
      }
      html += `<canvas class="inv-icon-canvas" width="32" height="32" data-block="${blockId}"></canvas>`;
      html += `<div class="inv-slot-name">${block.name}</div>`;
      html += `<div class="inv-slot-count">${count}</div>`;
      html += '</div>';
    }
    html += '</div>';
  }

  // 热栏展示
  html += '<div class="inv-hotbar-section">';
  html += '<div class="inv-hotbar-title">⬇ 热栏（点击背包物品切换到热栏）</div>';
  html += '<div class="inv-hotbar-grid">';
  for (let i = 0; i < 10; i++) {
    const blockId = game.hotbar[i];
    const isSelected = i === game.selectedSlot;
    html += `<div class="inv-hotbar-slot ${isSelected ? 'selected' : ''}" data-slot="${i}">`;
    html += `<span class="inv-hotbar-num">${i === 9 ? '0' : i + 1}</span>`;
    if (blockId > 0 && game.hotbarCounts[i] > 0) {
      html += `<canvas class="inv-hotbar-icon" width="32" height="32" data-block="${blockId}"></canvas>`;
    }
    html += '</div>';
  }
  html += '</div>';
  html += '</div>';

  html += '<div class="inv-close-btn" id="inv-close-btn">关闭背包 (E)</div>';

  panel.innerHTML = html;

  // 绘制物品图标
  panel.querySelectorAll('.inv-icon-canvas').forEach(cv => {
    const bid = parseInt(cv.dataset.block);
    const c = cv.getContext('2d');
    drawBlockIcon(c, 0, 0, 32, bid);
  });
  panel.querySelectorAll('.inv-hotbar-icon').forEach(cv => {
    const bid = parseInt(cv.dataset.block);
    const c = cv.getContext('2d');
    drawBlockIcon(c, 0, 0, 32, bid);
  });

  // 点击物品 → 切换到热栏
  panel.querySelectorAll('.inv-slot[data-id]').forEach(slot => {
    slot.addEventListener('click', () => {
      const blockId = parseInt(slot.dataset.id);
      toggleHotbarItem(blockId);
      game.inventoryDirty = true;
      drawInventory();
    });
  });

  // 点击热栏槽 → 选中
  panel.querySelectorAll('.inv-hotbar-slot[data-slot]').forEach(slot => {
    slot.addEventListener('click', () => {
      const s = parseInt(slot.dataset.slot);
      if (game.hotbar[s] > 0) {
        game.selectedSlot = s;
        sfx('click');
        drawInventory();
      }
    });
  });

  // 关闭按钮
  const closeBtn = document.getElementById('inv-close-btn');
  if (closeBtn) {
    closeBtn.addEventListener('click', () => {
      game.inventoryOpen = false;
    });
  }
}

// 将物品切换进/出热栏
function toggleHotbarItem(blockId) {
  const existingSlot = game.hotbar.indexOf(blockId);
  if (existingSlot >= 0) {
    // 已在热栏中 → 从热栏移除
    game.hotbar[existingSlot] = 0;
    game.hotbarCounts[existingSlot] = 0;
    sfx('click');
  } else {
    // 不在热栏 → 找空槽放入
    const emptySlot = game.hotbar.indexOf(0);
    if (emptySlot >= 0) {
      game.hotbar[emptySlot] = blockId;
      game.hotbarCounts[emptySlot] = game.inventory[blockId] || 0;
      sfx('pickup');
    } else {
      showToast('热栏已满！', 1000);
    }
  }
}

// ==================== 背包管理 ====================
function addItem(id, count) {
  game.inventory[id] = (game.inventory[id] || 0) + count;
  // 自动加入热栏
  let slot = game.hotbar.indexOf(id);
  if (slot === -1) {
    slot = game.hotbar.indexOf(0);
    if (slot !== -1) {
      game.hotbar[slot] = id;
    }
  }
  if (slot !== -1) {
    game.hotbarCounts[slot] = (game.hotbarCounts[slot] || 0) + count;
  }
  game.inventoryDirty = true;
  game.craftingDirty = true;
}

function removeItem(id, count) {
  if (!game.inventory[id]) return;
  game.inventory[id] -= count;
  if (game.inventory[id] < 0) game.inventory[id] = 0;
  // 从热栏扣除
  let remaining = count;
  for (let i = 0; i < game.hotbar.length && remaining > 0; i++) {
    if (game.hotbar[i] === id) {
      const take = Math.min(remaining, game.hotbarCounts[i]);
      game.hotbarCounts[i] -= take;
      remaining -= take;
      if (game.hotbarCounts[i] <= 0) game.hotbar[i] = 0;
    }
  }
  game.inventoryDirty = true;
  game.craftingDirty = true;
}

function updateHotbar() {
  // 重建热栏数据
  const items = Object.entries(game.inventory).filter(([id, c]) => c > 0);
  game.hotbar = [0,0,0,0,0,0,0,0,0,0];
  game.hotbarCounts = [0,0,0,0,0,0,0,0,0,0];
  items.slice(0, 10).forEach(([id, count], i) => {
    game.hotbar[i] = parseInt(id);
    game.hotbarCounts[i] = count;
  });
  game.inventoryDirty = true;
  game.craftingDirty = true;
}

// ==================== UI 更新 ====================
function updateUI() {
  // 同步 body class（控制手机控件显隐）
  document.body.classList.toggle('crafting-open', game.craftingOpen);
  document.body.classList.toggle('inventory-open', game.inventoryOpen);
  document.body.classList.toggle('battle-open', game.battleOpen);

  const overlay = document.getElementById('crafting-overlay');
  if (!game.craftingOpen && overlay.style.display !== 'none') {
    overlay.style.display = 'none';
  } else if (game.craftingOpen) {
    if (game.craftingDirty || overlay.style.display === 'none') {
      overlay.style.display = 'flex';
      game.craftingDirty = false;
      drawCrafting();
    }
  }

  const invOverlay = document.getElementById('inventory-overlay');
  if (!game.inventoryOpen && invOverlay.style.display !== 'none') {
    invOverlay.style.display = 'none';
  } else if (game.inventoryOpen) {
    if (game.inventoryDirty || invOverlay.style.display === 'none') {
      invOverlay.style.display = 'flex';
      game.inventoryDirty = false;
      drawInventory();
    }
  }
}

// ==================== 卡牌对战系统 ====================
function openBattle(enemy) {
  game.battleTarget = enemy;
  game.battleCards = [];
  game.battleOpen = true;
  game.paused = true;
  game.battleAnimating = false;
  sfx('battle');
  drawBattle();
}

function closeBattle() {
  game.battleTarget = null;
  game.battleCards = [];
  game.battleOpen = false;
  game.battleAnimating = false;
  game.paused = false;
  game.battleCooldown = 500;
  const overlay = document.getElementById('battle-overlay');
  if (overlay) overlay.style.display = 'none';
}

// ==================== 元素发现系统 ====================
function showElementDiscovery(symbol) {
  const elem = PERIODIC_TABLE[symbol];
  if (!elem) return;

  game.elementPopupActive = true;
  const overlay = document.getElementById('element-overlay');
  const panel = document.getElementById('element-panel');
  if (!overlay || !panel) return;

  // 周期表分类颜色
  const catColors = {
    '非金属':       '#3acc5a',
    '过渡金属':     '#3a9bff',
    'post-transition': '#9b59b6',
    '类金属':       '#30d0d0',
  };
  const catColor = catColors[elem.category] || '#888';

  let html = '';
  html += '<div class="element-popup-header">';
  html += `<div class="element-discover-badge">🔬 新元素发现！</div>`;
  html += '</div>';

  html += '<div class="element-card-outer">';
  html += `<div class="element-card" style="border-color:${catColor};box-shadow:0 0 30px ${catColor}40">`;
  html += `<div class="element-number" style="color:${catColor}">${elem.number}</div>`;
  html += `<div class="element-symbol" style="color:${catColor}">${elem.symbol}</div>`;
  html += `<div class="element-name-cn">${elem.name}</div>`;
  html += `<div class="element-name-en">${elem.nameEn}</div>`;
  html += `<div class="element-mass">${elem.mass}</div>`;
  html += `</div>`;
  html += '</div>';

  html += '<div class="element-details">';
  html += `<div class="element-detail-row"><span class="detail-label">原子序数</span><span class="detail-val">${elem.number}</span></div>`;
  html += `<div class="element-detail-row"><span class="detail-label">元素符号</span><span class="detail-val" style="color:${catColor};font-weight:700">${elem.symbol}</span></div>`;
  html += `<div class="element-detail-row"><span class="detail-label">中文名称</span><span class="detail-val">${elem.name}</span></div>`;
  html += `<div class="element-detail-row"><span class="detail-label">英文名称</span><span class="detail-val">${elem.nameEn}</span></div>`;
  html += `<div class="element-detail-row"><span class="detail-label">相对原子质量</span><span class="detail-val">${elem.mass}</span></div>`;
  html += `<div class="element-detail-row"><span class="detail-label">元素分类</span><span class="detail-val" style="color:${catColor}">${elem.category}</span></div>`;
  html += `<div class="element-detail-row"><span class="detail-label">族 / 周期</span><span class="detail-val">第${elem.group}族 / 第${elem.period}周期</span></div>`;
  html += `<div class="element-detail-row"><span class="detail-label">电子构型</span><span class="detail-val" style="font-family:monospace;font-size:11px">${elem.config}</span></div>`;
  html += '</div>';

  html += `<div class="element-desc">${elem.desc}</div>`;

  // 已发现元素统计
  const total = Object.keys(PERIODIC_TABLE).length;
  const found = game.discoveredElements.size;
  html += `<div class="element-progress">已发现 ${found} / ${total} 种化学元素</div>`;

  html += '<div class="element-close-btn" id="element-close-btn">继续探索</div>';

  panel.innerHTML = html;
  overlay.style.display = 'flex';

  // 添加粒子庆祝效果
  const cx = game.cw / 2;
  const cy = game.ch / 2;
  for (let i = 0; i < 30; i++) {
    spawnParticles(cx, cy, catColor, 1);
  }
  sfx('discover');

  // 绑定关闭
  const closeBtn = document.getElementById('element-close-btn');
  if (closeBtn) {
    closeBtn.addEventListener('click', closeElementPopup);
  }
  overlay.addEventListener('click', function handler(e) {
    if (e.target === overlay) {
      closeElementPopup();
      overlay.removeEventListener('click', handler);
    }
  });
}

function closeElementPopup() {
  game.elementPopupActive = false;
  const overlay = document.getElementById('element-overlay');
  if (overlay) overlay.style.display = 'none';
}

function drawBattle() {
  const overlay = document.getElementById('battle-overlay');
  const panel = document.getElementById('battle-panel');
  if (!overlay || !panel) return;
  overlay.style.display = 'flex';

  const en = game.battleTarget;
  if (!en) { closeBattle(); return; }

  const enHpPct = Math.max(0, en.health / en.maxHealth);
  const pHpPct = Math.max(0, game.player.health / game.player.maxHealth);
  const enemyName = en.type === 'slime' ? '史莱姆' : '怪物';

  let html = '<div class="battle-title">⚔️ 元素对战</div>';

  // 敌人信息
  html += '<div class="battle-combatant">';
  html += `<span class="battle-combatant-name">🟢 ${enemyName}</span>`;
  html += `<div class="battle-hp-bar"><div class="battle-hp-fill" style="width:${enHpPct*100}%;background:#ff3333"></div><span class="battle-hp-text">${Math.ceil(en.health)}/${en.maxHealth}</span></div>`;
  html += '</div>';

  // 玩家信息
  html += '<div class="battle-combatant">';
  html += '<span class="battle-combatant-name">🧑 玩家</span>';
  html += `<div class="battle-hp-bar"><div class="battle-hp-fill" style="width:${pHpPct*100}%;background:#22cc44"></div><span class="battle-hp-text">${Math.ceil(game.player.health)}/${game.player.maxHealth}</span></div>`;
  html += '</div>';

  // 卡牌选择区
  html += '<div class="battle-section-title">📋 选择攻击卡牌（最多3种）</div>';
  html += '<div class="battle-cards">';

  let availableCards = 0;
  for (let i = 0; i < game.hotbar.length; i++) {
    const blockId = game.hotbar[i];
    const count = game.hotbarCounts[i];
    if (blockId === 0 || count <= 0) continue;
    availableCards++;
    const block = BLOCKS[blockId];
    const element = BLOCK_ELEMENTS[blockId];
    const elemInfo = element ? ELEMENT_INFO[element] : null;
    const selected = game.battleCards.includes(i);

    html += `<div class="battle-card ${selected ? 'selected' : ''}" data-slot="${i}" style="${selected ? 'border-color:' + (elemInfo ? elemInfo.color : '#00d4ff') : ''}">`;
    html += `<div class="battle-card-icon" style="background:${block.color}">${BLOCK_EMOJI[blockId] || '🧱'}</div>`;
    html += `<div class="battle-card-name">${block.name}</div>`;
    if (elemInfo) {
      html += `<div class="battle-card-elem" style="color:${elemInfo.color}">${elemInfo.icon} ${elemInfo.name}</div>`;
    } else {
      html += '<div class="battle-card-elem" style="color:#666">无属性</div>';
    }
    html += `<div class="battle-card-count">×${count}</div>`;
    html += '</div>';
  }

  if (availableCards === 0) {
    html += '<div class="battle-no-cards">背包中没有可用物品！<br>挖掘收集材料后再来挑战</div>';
  }
  html += '</div>';

  // 已选卡牌槽
  html += '<div class="battle-selected-area">';
  html += '<span class="battle-selected-label">已选卡牌：</span>';
  for (let s = 0; s < 3; s++) {
    if (s < game.battleCards.length) {
      const slot = game.battleCards[s];
      const blockId = game.hotbar[slot];
      const block = BLOCKS[blockId];
      const element = BLOCK_ELEMENTS[blockId];
      const elemInfo = element ? ELEMENT_INFO[element] : null;
      const borderColor = elemInfo ? elemInfo.color : '#666';
      html += `<div class="battle-selected-card" data-slot="${slot}" style="border-color:${borderColor}">`;
      html += `${BLOCK_EMOJI[blockId] || '🧱'} ${block.name}`;
      if (elemInfo) html += ` <span style="color:${elemInfo.color}">${elemInfo.icon}</span>`;
      html += '</div>';
    } else {
      html += '<div class="battle-selected-card empty">＋</div>';
    }
  }
  html += '</div>';

  // 元素反应检测
  const reaction = checkElementReaction();
  html += '<div class="battle-reaction">';
  if (reaction) {
    html += `<div class="reaction-found" style="border-color:${ELEMENT_INFO[reaction.a].color}">`;
    html += `✨ ${reaction.icon} <b>${reaction.name}</b> — ${reaction.desc}！<br>伤害 ×2`;
    html += '</div>';
  } else if (game.battleCards.length >= 2) {
    html += '<div class="reaction-none">⚪ 无元素反应，仅基础伤害</div>';
  } else if (game.battleCards.length === 1) {
    html += '<div class="reaction-hint">💡 再选1~2张卡牌可能触发元素反应</div>';
  } else {
    html += '<div class="reaction-hint">👆 点击上方卡牌选择攻击</div>';
  }
  html += '</div>';

  // 预计伤害
  if (game.battleCards.length > 0) {
    const baseDmg = game.battleCards.length * 10;
    const totalDmg = reaction ? baseDmg * 2 : baseDmg;
    html += `<div class="battle-damage">预计伤害：<b class="dmg-num">${totalDmg}</b>${reaction ? ' ✨含反应加成' : ''}</div>`;
  }

  // 按钮
  const canAttack = game.battleCards.length > 0 && !game.battleAnimating;
  const canPunch = !game.battleAnimating;
  html += '<div class="battle-buttons">';
  html += `<button class="battle-btn attack" ${canAttack ? '' : 'disabled'}>⚔️ 攻击</button>`;
  html += `<button class="battle-btn punch" ${canPunch ? '' : 'disabled'}>✊ 拳击(5)</button>`;
  html += `<button class="battle-btn flee" ${game.battleAnimating ? 'disabled' : ''}>🏃 逃跑</button>`;
  html += '</div>';

  // 元素反应速查
  html += '<details class="battle-cheatsheet"><summary>📖 元素反应速查</summary><div class="cheatsheet-grid">';
  for (const r of ELEMENT_REACTIONS) {
    const ea = ELEMENT_INFO[r.a];
    const eb = ELEMENT_INFO[r.b];
    html += `<div class="cheatsheet-item"><span style="color:${ea.color}">${ea.icon}${ea.name}</span> + <span style="color:${eb.color}">${eb.icon}${eb.name}</span> → <b>${r.icon} ${r.name}</b></div>`;
  }
  html += '</div></details>';

  panel.innerHTML = html;

  // 绑定事件
  panel.querySelectorAll('.battle-card[data-slot]').forEach(card => {
    card.addEventListener('click', () => {
      if (game.battleAnimating) return;
      const slot = parseInt(card.dataset.slot);
      toggleBattleCard(slot);
    });
  });
  panel.querySelectorAll('.battle-selected-card[data-slot]').forEach(card => {
    card.addEventListener('click', () => {
      if (game.battleAnimating) return;
      const slot = parseInt(card.dataset.slot);
      toggleBattleCard(slot);
    });
  });
  const atkBtn = panel.querySelector('.battle-btn.attack');
  if (atkBtn && !atkBtn.disabled) atkBtn.addEventListener('click', executeBattleAttack);
  const punchBtn = panel.querySelector('.battle-btn.punch');
  if (punchBtn && !punchBtn.disabled) punchBtn.addEventListener('click', executePunch);
  const fleeBtn = panel.querySelector('.battle-btn.flee');
  if (fleeBtn && !fleeBtn.disabled) fleeBtn.addEventListener('click', () => {
    closeBattle();
    showToast('逃跑成功！', 1000);
  });
}

function toggleBattleCard(slot) {
  const idx = game.battleCards.indexOf(slot);
  if (idx >= 0) {
    game.battleCards.splice(idx, 1);
  } else if (game.battleCards.length < 3) {
    game.battleCards.push(slot);
  }
  sfx('click');
  drawBattle();
}

function checkElementReaction() {
  if (game.battleCards.length < 2) return null;
  const elements = game.battleCards
    .map(slot => BLOCK_ELEMENTS[game.hotbar[slot]])
    .filter(e => e);
  for (let i = 0; i < elements.length; i++) {
    for (let j = i + 1; j < elements.length; j++) {
      const a = elements[i];
      const b = elements[j];
      for (const r of ELEMENT_REACTIONS) {
        if ((r.a === a && r.b === b) || (r.a === b && r.b === a)) {
          return r;
        }
      }
    }
  }
  return null;
}

function executeBattleAttack() {
  if (game.battleCards.length === 0 || game.battleAnimating) return;
  const en = game.battleTarget;
  if (!en) return;

  game.battleAnimating = true;

  // 计算伤害
  const baseDmg = game.battleCards.length * 10;
  const reaction = checkElementReaction();
  const totalDmg = reaction ? baseDmg * 2 : baseDmg;

  // 消耗物品
  game.battleCards.forEach(slot => {
    const blockId = game.hotbar[slot];
    removeItem(blockId, 1);
  });

  sfx('attack');

  // 粒子效果
  const ex = en.x + en.w / 2;
  const ey = en.y + en.h / 2;
  if (reaction) {
    spawnParticles(ex, ey, '#ffaa00', 20);
    spawnParticles(ex, ey, ELEMENT_INFO[reaction.a].color, 15);
    showToast(`✨ ${reaction.name}！伤害×2 → ${totalDmg}`, 1500);
  } else {
    spawnParticles(ex, ey, '#88ff44', 12);
    showToast(`攻击造成 ${totalDmg} 伤害`, 1000);
  }

  // 清空选牌
  game.battleCards = [];
  updateHotbar();

  // 判定：伤害 >= 怪物当前血量 → 击杀
  if (totalDmg >= en.health) {
    en.health = 0;
    drawBattle(); // 先显示血条归零

    setTimeout(() => {
      spawnParticles(ex, ey, '#44ff00', 25);
      game.droppedItems.push({ x: en.x, y: en.y, id: 7, count: 1, vy: -4, life: 600 });
      showToast('🎉 击败敌人！+1 煤矿', 1500);
      const idx = game.enemies.indexOf(en);
      if (idx >= 0) game.enemies.splice(idx, 1);
      closeBattle();
    }, 800);
    return;
  }

  // 否则：怪物存活，扣血后反击玩家
  en.health -= totalDmg;
  drawBattle(); // 显示怪物扣血后的血条

  setTimeout(() => {
    if (!game.battleOpen || !game.battleTarget) { return; }
    const counterDmg = 6 + Math.floor(Math.random() * 6);
    game.player.health -= counterDmg;
    if (game.player.health < 0) game.player.health = 0;
    game.player.invuln = 800;
    game.player.lastDamageTime = performance.now();
    sfx('hurt');
    spawnParticles(
      game.player.x + game.player.w / 2,
      game.player.y + game.player.h / 2,
      '#ff3333', 10
    );
    showToast(`💥 敌人反击！-${counterDmg} HP`, 1000);
    drawBattle();

    if (game.player.health <= 0) {
      setTimeout(() => { closeBattle(); respawn(); }, 800);
      return;
    }

    // 准备下一轮
    game.battleAnimating = false;
    drawBattle();
  }, 700);
}

// 拳击：固定5伤害，不消耗物品
function executePunch() {
  if (game.battleAnimating) return;
  const en = game.battleTarget;
  if (!en) return;

  game.battleAnimating = true;
  const totalDmg = 5;
  sfx('attack');

  const ex = en.x + en.w / 2;
  const ey = en.y + en.h / 2;
  spawnParticles(ex, ey, '#aaaaaa', 8);
  showToast(`👊 拳击！造成 ${totalDmg} 伤害`, 1000);

  game.battleCards = [];
  drawBattle();

  if (totalDmg >= en.health) {
    en.health = 0;
    drawBattle();
    setTimeout(() => {
      spawnParticles(ex, ey, '#44ff00', 25);
      game.droppedItems.push({ x: en.x, y: en.y, id: 7, count: 1, vy: -4, life: 600 });
      showToast('🎉 击败敌人！+1 煤矿', 1500);
      const idx = game.enemies.indexOf(en);
      if (idx >= 0) game.enemies.splice(idx, 1);
      closeBattle();
    }, 800);
    return;
  }

  en.health -= totalDmg;
  drawBattle();

  setTimeout(() => {
    if (!game.battleOpen || !game.battleTarget) { return; }
    const counterDmg = 6 + Math.floor(Math.random() * 6);
    game.player.health -= counterDmg;
    if (game.player.health < 0) game.player.health = 0;
    game.player.invuln = 800;
    game.player.lastDamageTime = performance.now();
    sfx('hurt');
    spawnParticles(
      game.player.x + game.player.w / 2,
      game.player.y + game.player.h / 2,
      '#ff3333', 10
    );
    showToast(`💥 敌人反击！-${counterDmg} HP`, 1000);
    drawBattle();

    if (game.player.health <= 0) {
      setTimeout(() => { closeBattle(); respawn(); }, 800);
      return;
    }

    game.battleAnimating = false;
    drawBattle();
  }, 700);
}

// ==================== 工具函数 ====================
function lerp(a, b, t) { return a + (b - a) * t; }

let toastEl = null;
let toastTimer = null;
function showToast(msg, duration = 2000) {
  if (!toastEl) {
    toastEl = document.getElementById('game-toast');
  }
  toastEl.textContent = msg;
  toastEl.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toastEl.classList.remove('show'), duration);
}

// ==================== 音效 ====================
let audioCtx = null;
function getAudio() {
  if (!audioCtx) {
    try { audioCtx = new (window.AudioContext || window.webkitAudioContext)(); }
    catch(e) { return null; }
  }
  return audioCtx;
}

function sfx(type) {
  const ctx = getAudio();
  if (!ctx) return;
  const osc = ctx.createOscillator();
  const gain = ctx.createGain();
  const sounds = {
    jump:   { f:400, d:0.08, t:'square', v:0.05 },
    break:  { f:200, d:0.1, t:'sawtooth', v:0.08 },
    place:  { f:500, d:0.06, t:'square', v:0.06 },
    hurt:   { f:150, d:0.15, t:'sawtooth', v:0.1 },
    pickup: { f:700, d:0.08, t:'sine', v:0.08 },
    craft:  { f:600, d:0.12, t:'triangle', v:0.08 },
    attack: { f:300, d:0.15, t:'sawtooth', v:0.1 },
    battle: { f:250, d:0.2, t:'triangle', v:0.08 },
    click:  { f:800, d:0.04, t:'square', v:0.04 },
    discover: { f:880, d:0.3, t:'triangle', v:0.12 },
  };
  const s = sounds[type] || sounds.break;
  osc.type = s.t;
  osc.frequency.value = s.f;
  gain.gain.setValueAtTime(s.v, ctx.currentTime);
  gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + s.d);
  osc.connect(gain);
  gain.connect(ctx.destination);
  osc.start();
  osc.stop(ctx.currentTime + s.d);
}

// ==================== 启动 ====================
window.addEventListener('load', () => {
  init();
});

})();
