const config = require('../../utils/config');

Page({
  data: {
    url: '',
  },

  onLoad(options) {
    // 把启动参数（如分享带回来的 invite）透传给 H5，便于做邀请奖励/回流统计
    const extra = [];
    extra.push('from=mp');
    if (options && options.invite) extra.push('invite=' + encodeURIComponent(options.invite));

    const base = config.GAME_URL;
    const sep = base.indexOf('?') > -1 ? '&' : '?';
    this.setData({ url: base + sep + extra.join('&') });
  },

  // ---- 获客核心：转发到好友/群 ----
  onShareAppMessage() {
    return {
      title: config.SHARE.title,
      path: config.SHARE.path,
      imageUrl: config.SHARE.imageUrl || '',
    };
  },

  // 转发到朋友圈
  onShareTimeline() {
    return {
      title: config.SHARE.timelineTitle,
      query: '',
      imageUrl: config.SHARE.imageUrl || '',
    };
  },

  // 接收 H5 通过 wx.miniProgram.postMessage 发来的消息
  // （注意：消息不会实时触发，仅在特定时机如分享、后退、组件销毁时回传）
  handleMessage(e) {
    const data = e.detail && e.detail.data;
    // 预留：例如 H5 通知小程序调起支付、保存图片等原生能力
    // 示例：if (data && data[0] && data[0].action === 'saveImage') { ... }
    console.log('[web-view message]', data);
  },
});
