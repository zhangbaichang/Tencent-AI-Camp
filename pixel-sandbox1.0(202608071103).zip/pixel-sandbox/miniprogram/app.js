/**
 * 像素沙盒 - 微信小程序入口
 * 策略：web-view 套壳，游戏逻辑零改动，全部复用现有 H5。
 */
App({
  globalData: {
    scene: null,   // 进入场景值
    query: {},      // 启动参数
    userInfo: null, // 预留：如需登录态可在此扩展
  },

  onLaunch(options) {
    // 记录来源场景，便于后续做分享回流/数据埋点
    this.globalData.scene = options.scene;
    this.globalData.query = options.query || {};
    // 例：分享带 invite 参数 → query.invite
  },
});
