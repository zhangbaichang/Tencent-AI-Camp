/**
 * 环境与游戏地址配置
 *
 * 重要：
 *  - 生产环境 GAME_URL 必须是 HTTPS，且该域名必须在小程序后台
 *    「开发管理 - 开发设置 - 业务域名」中配置并上传校验文件。
 *  - 开发期可在「微信开发者工具 - 详情 - 本地设置」勾选
 *    「不校验合法域名」，临时使用本地/测试地址调试。
 *  - web-view 组件不支持 localhost/IP，真机调试也必须是已配置的业务域名。
 */
const IS_DEV = false; // 上线前务必改为 false，并填好生产域名

module.exports = {
  // H5 游戏页面地址（套壳目标）
  GAME_URL: IS_DEV
    ? 'https://dev.example.com/pixel-sandbox/index.html'
    : 'https://your-domain.com/pixel-sandbox/index.html',

  // 分享文案与路径（获客核心入口）
  SHARE: {
    title: '像素沙盒 - 挖矿合成打怪，快来一起探索！',
    path: '/pages/web/web',
    timelineTitle: '像素沙盒 - 2D开放世界冒险',
    // 自定义分享封面（建议 5:4，≤128KB）；留空则用 web-view 截图
    imageUrl: '',
  },
};
