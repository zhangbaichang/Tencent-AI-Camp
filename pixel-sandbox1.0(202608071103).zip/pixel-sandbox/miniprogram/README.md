# 像素沙盒 - 微信小程序（WebView 套壳方案）

> 目标：**不改动任何游戏逻辑**，用 `<web-view>` 把现有 H5 沙盒游戏套壳成小程序，快速上线 + 分享获客。

---

## 一、架构总览

```
┌──────────────────────────────────────────────┐
│            微信小程序 (原生壳)                │
│  ┌────────────────────────────────────────┐  │
│  │ pages/web/web                          │  │
│  │   <web-view src="H5游戏URL">           │  │
│  │   ├─ onLoad: 透传启动参数(invite等)    │  │
│  │   ├─ onShareAppMessage: 转发好友/群     │  │
│  │   ├─ onShareTimeline: 转发朋友圈       │  │
│  │   └─ bind:message: 接收 H5 postMessage │  │
│  └────────────────────────────────────────┘  │
│                    │ HTTPS                    │
│                    ▼                          │
│  ┌────────────────────────────────────────┐  │
│  │  H5 游戏 (像素沙盒, 零改动)             │  │
│  │  index.html + css/ + js/               │  │
│  │  • UA 兜底: 微信内强制识别为移动端      │  │
│  │  • 虚拟摇杆/操作按钮自动显示            │  │
│  │  • Canvas 渲染 + 卡牌对战 + 昼夜循环    │  │
│  └────────────────────────────────────────┘  │
└──────────────────────────────────────────────┘
```

**一句话**：小程序只做一个「全屏 web-view 壳 + 分享配置」，游戏全部跑在 H5 里。改动仅 1 处——给游戏加了一行 UA 兜底，保证微信内移动控件一定显示。

---

## 二、目录结构

```
pixel-sandbox/
├── index.html              # H5 游戏（不变）
├── css/style.css           # H5 样式（不变）
├── js/
│   ├── data.js
│   ├── world.js
│   └── game.js             # 仅 init() 触屏检测加 UA 兜底，游戏逻辑零改动
└── miniprogram/            # ← 新增：微信小程序工程
    ├── app.js              # 入口，记录场景/启动参数
    ├── app.json            # 页面路由 + 窗口配置
    ├── app.wxss
    ├── project.config.json # 开发者工具配置（urlCheck=false 便于本地调试）
    ├── sitemap.json        # 搜索收录
    ├── utils/
    │   └── config.js       # ★ 游戏域名 & 分享文案配置（上线前必改）
    └── pages/
        └── web/
            ├── web.js      # web-view 承载 + 分享 + 参数透传 + 接收 H5 消息
            ├── web.json
            ├── web.wxml    # <web-view>
            └── web.wxss
```

整个小程序工程极轻（< 10KB），主包体积远低于 2MB 限制。

---

## 三、为什么这样能解决「UA 要为手机」

游戏原检测（`js/game.js`）：
```js
if ('ontouchstart' in window || navigator.maxTouchPoints > 0) { ... 启用移动控件 }
```
- 微信 web-view 在**真机**上：UA 是手机端 + 有触屏 → 原检测已命中，移动控件本就会显示。
- 边缘环境（开发者工具模拟、个别 WebView）可能延迟触发触屏事件 → 移动控件可能不出现。

**已加 UA 兜底**（不影响任何游戏机制）：
```js
var _isMobileUA = /Mobile|Android|iPhone|iPod|iPad|MicroMessenger/i.test(navigator.userAgent);
if (_isMobileUA || 'ontouchstart' in window || navigator.maxTouchPoints > 0) { ... }
```
> 注意：web-view 的 UA 由微信客户端控制，**无法也不需要**手动改写。只要按上面兜底，手机端表现一定一致。

---

## 四、上线前置条件（请先逐条确认 ⚠️）

| # | 条件 | 说明 |
|---|------|------|
| 1 | **小程序主体类型必须是「企业 / 个体工商户 / 政府…」** | 🔴 **个人主体小程序无法使用 `<web-view>` 组件**，这是平台硬限制。请先确认你的小程序账号是非个人主体。 |
| 2 | 已认证的小程序账号 + AppID | 用于开发者工具登录与发布 |
| 3 | 一个 **HTTPS 域名**（有效证书） | 用于托管 H5 游戏页面，http/IP/localhost 在真机均不可用 |
| 4 | 域名已完成 **ICP 备案** | 微信业务域名要求已备案 |
| 5 | 能在该域名根目录放置**校验文件** | 微信会下发 `MP_verify_xxxx.txt`，需上传到域名根目录 |

> 若第 1 条不满足（个人主体），web-view 套壳方案不可行，需改走「原生重写」或「使用支持个人主体的跨端框架（如 uni-app H5→小程序原生组件）」路线——可另议。

---

## 五、本地调试步骤

1. 用**微信开发者工具**打开 `miniprogram/` 目录。
2. `project.config.json` 已设 `urlCheck: false`（不校验合法域名）。
3. 把 `utils/config.js` 的 `IS_DEV` 改为 `true`，填一个可访问的 HTTPS 测试地址（或临时把 H5 部署到任意 HTTPS 测试域名）。
4. 编译预览。真机调试：点击「真机调试」扫码。
   - 真机**必须**用配置好的业务域名；localhost 真机不可用。

---

## 六、上线部署清单（按顺序做）

1. **托管 H5**：把 `index.html` + `css/` + `js/` 上传到你的 HTTPS 服务器，确认 `https://你的域名/pixel-sandbox/index.html` 可访问。
2. **配业务域名**：登录 [小程序后台](https://mp.weixin.qq.com) → 开发管理 → 开发设置 → 业务域名 → 添加你的域名 → 下载校验文件 `MP_verify_xxxx.txt` → 上传到域名根目录 → 点保存（微信会校验）。
3. **改配置**：`miniprogram/utils/config.js` 把 `IS_DEV=false`，`GAME_URL` 改为生产地址，按需改 `SHARE` 分享文案/封面图。
4. **填 AppID**：`project.config.json` 的 `appid` 改为你的小程序 AppID。
5. **开发者工具上传**：打开 `miniprogram/`，点「上传」→ 填版本号 → 提交。
6. **提审**：后台「版本管理」→ 提交审核。
   - 审核注意：游戏类小程序可能需要**游戏类目资质**（版号等），请按平台要求准备材料，避免被拒。

---

## 七、获客能力（已内置）

- **转发好友/群**：`onShareAppMessage` 已配置，分享卡片点开即进 `/pages/web/web`。
- **转发朋友圈**：`onShareTimeline` 已配置。
- **邀请参数透传**：分享链接可带 `invite`，`onLoad` 会透传给 H5（`?from=mp&invite=xxx`），H5 可据此做邀请奖励。
- 分享封面图：在 `utils/config.js` 的 `SHARE.imageUrl` 配置（建议 5:4，≤128KB）。留空则用 web-view 自动截图。

---

## 八、已知限制与权衡

| 项 | 说明 |
|----|------|
| 导航栏占位 | 默认保留原生导航栏（标题「像素沙盒」+ 胶囊按钮），游戏区在导航栏下方。若要全屏沉浸，可改 `navigationStyle: custom`，但需自行避让右上角胶囊区。 |
| 加载白屏 | 首次加载 H5 需拉取资源，建议在 H5 侧用 loading 画面（游戏已有 `#loading-screen`）。 |
| 分享回流统计 | web-view 无法精确感知分享点击回流，可在 H5 URL 带 `invite` 做粗略统计。 |
| 搜索收录 | web-view 页对微信搜索索引有限，纯 web-view 小程序的「服务直达」能力弱于原生页面。 |
| 性能 | Canvas 游戏在 web-view 内表现取决于微信内置浏览器，中低端机注意帧率（游戏已做 dt 限帧）。 |

---

## 九、未来扩展（需要时再做，不急）

- **原生桥接**：H5 引入微信 JS-SDK（`https://res.wx.qq.com/open/js/jweixin-1.6.0.js`），用 `wx.miniProgram.postMessage` 通知小程序调起**微信支付 / 保存图片到相册 / 复制口令**等原生能力；小程序侧在 `handleMessage` 接收处理。
- **登录态打通**：`onLoad` 调 `wx.login` 拿 code → 后端换 openid → 作为参数拼到 H5 URL，实现免登。
- **订阅消息**：在 H5 关键节点（如建造完成、夜晚来临）用 `wx.miniProgram.subscribeMessage` 引导用户订阅。
- **数据埋点**：在 `app.js onLaunch` 记录 scene，结合 H5 内埋点做完整漏斗。
- **分包**：当前单页无需分包；若后续加原生活动页，再按子包拆分。
