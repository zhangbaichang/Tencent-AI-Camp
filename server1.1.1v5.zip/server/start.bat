@echo off
chcp 65001 >nul
rem 像素沙盒 无头服务端启动器（须 JDK25+，请勿用 JDK8）
cd /d "%~dp0"
set "JAVA="
if exist "C:\Program Files\Java\jdk-25.0.2\bin\java.exe" set "JAVA=C:\Program Files\Java\jdk-25.0.2\bin\java.exe"
if not defined JAVA if exist "C:\Program Files\Java\jdk-26.0.1\bin\java.exe" set "JAVA=C:\Program Files\Java\jdk-26.0.1\bin\java.exe"
if not defined JAVA if exist "%JAVA_HOME%\bin\java.exe" set "JAVA=%JAVA_HOME%\bin\java.exe"
if not defined JAVA set "JAVA=java"
if not exist "%JAVA%" (
    echo 未找到 Java 25/26 运行时。请安装 JDK 25/26 或设置 JAVA_HOME 后重试。
    pause
    exit /b 1
)
"%JAVA%" -Dfile.encoding=UTF-8 --enable-native-access=ALL-UNNAMED -jar PixelSandboxServer.jar %*
if errorlevel 1 pause
