#!/bin/sh
# 像素沙盒 无头服务端启动器（Linux）
cd "$(dirname "$0")"
# 服务端同样须 JDK25+。优先显式路径，回退 JAVA_HOME/PATH。
JAVA=""
[ -x "/usr/lib/jvm/jdk-25/bin/java" ] && JAVA="/usr/lib/jvm/jdk-25/bin/java"
[ -z "$JAVA" ] && [ -x "/opt/jdk-25/bin/java" ] && JAVA="/opt/jdk-25/bin/java"
[ -z "$JAVA" ] && [ -x "/usr/lib/jvm/jdk-26/bin/java" ] && JAVA="/usr/lib/jvm/jdk-26/bin/java"
[ -z "$JAVA" ] && [ -x "$JAVA_HOME/bin/java" ] && JAVA="$JAVA_HOME/bin/java"
[ -z "$JAVA" ] && JAVA="java"
"$JAVA" -Dfile.encoding=UTF-8 -jar PixelSandboxServer.jar "$@"
