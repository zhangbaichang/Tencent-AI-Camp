@echo off
chcp 65001 >nul
rem ============================================
rem  像素沙盒 客户端启动器
rem  请勿直接双击 PixelSandbox.jar，用本文件启动
rem ============================================
cd /d "%~dp0"

set "JAVA="
if exist "C:\Program Files\Java\jdk-25.0.2\bin\java.exe" set "JAVA=C:\Program Files\Java\jdk-25.0.2\bin\java.exe"
if not defined JAVA if exist "C:\Program Files\Java\jdk-26.0.1\bin\java.exe" set "JAVA=C:\Program Files\Java\jdk-26.0.1\bin\java.exe"
if not defined JAVA if exist "%JAVA_HOME%\bin\java.exe" set "JAVA=%JAVA_HOME%\bin\java.exe"
if not defined JAVA set "JAVA=java"

if not exist "%JAVA%" (
    echo [启动器] 未找到 Java 运行时。
    echo 请安装 JDK 25/26，或设置 JAVA_HOME 指向 JDK 25/26 后重试。
    pause
    exit /b 1
)

echo [启动器] 使用 Java: %JAVA%
echo [启动器] 正在启动游戏...
"%JAVA%" -Dfile.encoding=UTF-8 --enable-native-access=ALL-UNNAMED -cp "PixelSandbox.jar;lib/*" com.pixelsandbox.game.PixelSandboxGame > startup.log 2>&1

echo.
echo [启动器] 游戏已退出，退出码: %errorlevel%
echo [启动器] ===== 启动日志 startup.log =====
type startup.log
echo [启动器] ===== 日志结束 =====
echo.
echo [启动器] 若游戏未正常显示，请截图本窗口（含上方日志）反馈。
pause
