#!/bin/sh
# 像素沙盒 客户端启动器（Linux）
cd "$(dirname "$0")"
# 本游戏用 JDK25 编译（class v69），须 JDK25+ 运行。优先显式路径，回退 JAVA_HOME/PATH。
JAVA=""
[ -x "/usr/lib/jvm/jdk-25/bin/java" ] && JAVA="/usr/lib/jvm/jdk-25/bin/java"
[ -z "$JAVA" ] && [ -x "/opt/jdk-25/bin/java" ] && JAVA="/opt/jdk-25/bin/java"
[ -z "$JAVA" ] && [ -x "/usr/lib/jvm/jdk-26/bin/java" ] && JAVA="/usr/lib/jvm/jdk-26/bin/java"
[ -z "$JAVA" ] && [ -x "$JAVA_HOME/bin/java" ] && JAVA="$JAVA_HOME/bin/java"
[ -z "$JAVA" ] && JAVA="java"
if [ ! -x "$JAVA" ] && ! command -v "$JAVA" > /dev/null 2>&1; then
  echo "未找到 Java 25/26 运行时。请安装 JDK 25/26 或设置 JAVA_HOME 后重试。"
  exit 1
fi
"$JAVA" -Dfile.encoding=UTF-8 --enable-native-access=ALL-UNNAMED -cp "PixelSandbox.jar:lib/*" com.pixelsandbox.game.PixelSandboxGame
